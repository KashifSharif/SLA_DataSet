const CRAWLER_REGEX = /bot|crawl|google|spider/i;
const LANG_REGEX = /^\/intl\/\w+/;
const STORAGE = window.localStorage;
const STORAGE_KEY = 'SPLITTER';

class Splitter {
  constructor(dataset) {
    if (this.isCrawler) return;
    this.global = this.parseData(dataset.global);
    this.config = this.parseData(dataset.config);
    this.cache = this.getCache();
    this.cleanup();
    if (!this.config.id) return;
    this.showVariant();
  }

  parseData(value) {
    return JSON.parse(value.replace(/'/g, '"') || '{}');
  }

  getCache() {
    return JSON.parse(STORAGE.getItem(STORAGE_KEY)) || {};
  }

  setCache(cache) {
    STORAGE.setItem(STORAGE_KEY, JSON.stringify(cache));
  }

  cleanup() {
    for (const id in this.cache) {
      if (!this.global.active || !this.global.active.includes(id)) {
        delete this.cache[id];
      }
      this.setCache(this.cache);
    }
  }

  showVariant() {
    if (this.variantId === -1) return;
    if (this.redirectUrl !== location.href) {
      location.replace(this.redirectUrl);
    }
    dataLayer.push({splitter: JSON.stringify(this.cache)});
  }

  get variantId() {
    let id = this.cache[this.config.id];
    if (id === -1 || this.config.variants[id]) {
      return id;
    }
    if (this.isEligible) {
      id = this.weightedRandom;
    } else {
      id = -1;
    }
    this.cache[this.config.id] = id;
    this.setCache(this.cache);
    return id;
  }

  get variantPath() {
    return this.config.variants[this.variantId].path;
  }

  get langPrefix() {
    const langMatch = location.pathname.match(LANG_REGEX);
    return langMatch ? langMatch[0] : '';
  }

  get redirectUrl() {
    return location.origin + this.langPrefix + this.variantPath + location.search;
  }

  get isEligible() {
    return Math.random() < this.config.traffic;
  }

  get weightedRandom() {
    const weights = this.config.variants.map((variant) => variant.weight);
    const totalWeight = weights.reduce((total, weight) => total + weight, 0);
    let random = Math.random() * totalWeight;
    for (const i in weights) {
      if (random < weights[i]) {
        return i;
      }
      random -= weights[i];
    }
    return -1;
  }

  get isCrawler() {
    return navigator.userAgent.match(CRAWLER_REGEX);
  }
}

(() => {
  new Splitter(document.currentScript.dataset);
})();
