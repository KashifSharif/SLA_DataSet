(function (global) {
    if (!global.require) {
        global.require = {
            config: function (config) {
                global.require = config;
            }
        };
    }

    require.config({
        baseUrl: '/Static/Scripts',
        // urlArgs: global.requireUrlArgs,
        paths: {

            // HeaderFooterLinkCorrector
            HeaderFooterLinkCorrector: 'modules/headerfooter-link-corrector',
            LocalizationLoader: 'modules/localization-loader',

            //#Common libray       
            //Azure script libray
            AX: 'lib/azurex',

            //#Components(Our custom component)
            //Common
            Common: 'modules/common',
            //Accordian menu
            AccordianMenu: 'modules/accordian-menu',
            //Documentation left navigation
            DocLeftNav: 'modules/documentation-left-navigation',
            //Documentation right bookmark
            DocRightBookmark: 'modules/documentation-right-bookmark',
            //Layout
            Layout: 'modules/layout',
            //Scroll to fixed
            ScrollToFixed: 'modules/scroll-to-fixed',
            //External link
            IsExternalLink: 'modules/is-external-link',
            //Bread crumb
            BreadCrumb: 'modules/bread-crumb',
            //Screen test
            ScreenTest: 'modules/screen-test',
            //Dialog
            Dialog: 'modules/dialog',
            //Tab
            Tab: 'modules/tab',
            TabDropDown: 'modules/tab-dropdown',
            //Auto scroll
            AutoScroll: 'modules/auto-scroll',
            //Auto height
            AutoHeight: 'modules/auto-height',
            //Table
            Table: 'modules/table',
            //Language switch
            LanguageSwitch: 'modules/language-switch',
            //Temporary Hide
            TemporaryHide: 'modules/temporary-hide',
            //Storage by URL
            StorageByURL: 'modules/storage-by-page',
            //Tab active status
            tabActiveStatus: 'modules/tab-actvie-status',
            //QRcode
            QRcodeGen: 'modules/qrcode',
            //AJAXForm
            AJAXForm: 'modules/ajax-form',
            //Validation
            Validation: 'modules/form-validation',
            //Category
            Category: 'modules/category',
            //Infinite scrolling
            infiniteScrolling: 'modules/infinite-scrolling',
            //Webchat
            Webchat: 'modules/webchat',
            //Banner Exchange
            Banner: 'modules/banner-exchange',
            //Homepage Banner
            HomePageBanner: 'modules/homepage-banner',
            //Tab Control
            TabControl: 'modules/tab-control',
            //Toggle ShowDetail
            ToggleShow: 'modules/toggle-showdetail',
            //List-readmore
            Readmore: 'modules/readmore',
            //SiteSearch
            SiteSearch: 'modules/searchresult',
            //Filter
            FilterData: 'modules/filter-data',
            //FullScroll
            FullScroll: 'modules/full-scroll',
            //Webinar-SignUp
            WebinarsForm: 'modules/webinars-signUp',
            //WebinarFormatter
            WebinarFormatter: "modules/webinar-formatter",
            //Webinar-SignUp-validation
            WebinarsFormValidation: 'modules/webinars-signUp-validation',
            //Webinar-Detail
            WebinarsDetail: 'modules/webinars-download',
            //Media tag
            MediaTag: 'modules/media-tag',

            //#Plugin(AMD standard open source javascript library)
            //JQuery
            jquery: 'lib/jquery-1.12.3.min',
            //Webchat JSSDK
            WebchatJSSDK: 'lib/jweixin-1.0.0',
            //FastClick
            FastClick: 'plugins/fastclick/fastclick',
            //jQuery Easing
            Easing: 'plugins/easing/jquery.easing.1.3',
            //Highlight
            Highlight: 'plugins/highlight/highlight.min',
            //MobileDetect
            MobileDetect: 'plugins/mobile-detect/mobile-detect',
            //Swiper
            Swiper: 'plugins/slideshow/swiper',
            //jQuery Transit
            Transit: 'plugins/transit/jquery.transit',
            VideoJSIE8: 'plugins/videojs/videojs-ie8',
            VideoJS: 'plugins/videojs/video',
            VideoJSWithControlFix: 'plugins/videojs/videojs-with-control-fix',
            VideoPlayerControl: 'plugins/videojs/VideoPlayerControl',
            Monthly: 'plugins/datepicker/monthly',
            Modal: 'plugins/Modal/modal',
            Mask: 'plugins/mask/mask',
            jqueryCookie: 'plugins/cookie/jquery.cookie',
            stringFormat: 'plugins/string-format/string-format',

            //AMP player
            AMPPlayer: 'lib/azuremediaplayer.min',
            MediaPlayer: 'modules/mediaplayer',
            //Calculator
            underscore: 'lib/underscore-min',
            CalculatorUI: 'modules/calculator/calculator-UIRenderer',
            CalculatorSideBar: 'modules/calculator/calculator-sidebar',
            saveAs: 'plugins/file-saver/FileSaver.min',
            jqueryUI: 'plugins/jQueryUI/jquery-ui-1.11.1.min',

            //Content Feedback
            WACNDataTracker: 'modules/WACNDataTracker',
            FeedBack: 'modules/content-feedback',

            //Tracker
            UAParser: 'plugins/ua-parser/ua-parser.min',
            pathToRegexp: 'lib/path-to-regexp.min',
            DataTracker: 'modules/data-tracker',

            //Retina
            retina: 'plugins/retina/retina',

            //Vue
            vue: 'lib/vue',
            smsComponent: "components/sms-component",
            identityAuthErrorCheck: 'components/common-error-check',
            stepsLineComponent: "components/steps-line-component",

        },
        shim: {
            //(Non-AMD standard open source javascript library)
            //jQuery Easing
            'Easing': ['jquery'],
            'Monthly': ['jquery'],
            'jqueryCookie': ['jquery'],
            'Modal': ['jquery'],
            'Mask': ['jquery'],
            'CalculatorUI': ['jquery'],
            'UAParser': ['jquery'],
            'retina': {
                exports: 'retinajs',
            },
        },
        waitSeconds: 0
    });

}(typeof window !== 'undefined' ? window : this));
