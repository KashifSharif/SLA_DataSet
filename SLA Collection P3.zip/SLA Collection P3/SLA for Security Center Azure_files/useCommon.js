function MyPromise (executor) {
    var self = this;
    self.status = 'pending';
    self.resolveValue = null;
    self.rejectReason = null;
    self.ResolveCallBackList = [];
    self.RejectCallBackList = [];

    function resolve (value) {
        if (self.status === 'pending') {
            self.status = 'Fulfilled';
            self.resolveValue = value;
            self.ResolveCallBackList.forEach(function (ele) {
                ele();
            });
        }  
    }

    function reject (reason) {
        if (self.status === 'pending') {
            self.status = 'Rejected';
            self.rejectReason = reason;
            self.RejectCallBackList.forEach(function (ele) {
                ele();
            });            
        }  
    }
    
    try {
        executor(resolve, reject);
    }catch(e) {
        reject(e);
    } 
};

function ResolutionRetrunPromise (nextPromise, returnValue, res, rej) {
    if (returnValue instanceof MyPromise) {
        // Promise 对象
        returnValue.then(function (val) {
            res(val);
        }, function (reason) {
            rej(reason)
        });
    }else {
        res(returnValue);
    }
}

MyPromise.prototype.then = function (onFulfilled, onRejected) {
    if (!onFulfilled) {
        onFulfilled = function (val) {
            return val;
        }
    }
    if (!onRejected) {
        onRejected = function (reason) {
            throw new Error(reason);
        }
    }    
    var self = this;

    var nextPromise = new MyPromise(function (res, rej) {
        if (self.status === 'Fulfilled') {
            setTimeout(function () {
                try {
                    // var nextResolveValue = onFulfilled(self.resolveValue);
                    // res(nextResolveValue);
                    var nextResolveValue = onFulfilled(self.resolveValue);
                    ResolutionRetrunPromise(nextPromise, nextResolveValue, res, rej);
                }catch(e) {
                    rej(e);
                }

            }, 0);
        }
    
        if (self.status === 'Rejected') {
            setTimeout(function () {
                try {
                    var nextRejectValue = onRejected(self.rejectReason);
                    ResolutionRetrunPromise(nextPromise, nextRejectValue, res, rej);
                }catch(e) {
                    rej(e);
                }

            }, 0);
        }
    
        // 
        if (self.status === 'pending') { 
            self.ResolveCallBackList.push(function () {
                try {
                    var nextResolveValue = onFulfilled(self.resolveValue);
                    ResolutionRetrunPromise(nextPromise, nextResolveValue, res, rej);
                }catch(e) {
                    rej(e);
                }
            });
    
            self.RejectCallBackList.push(function () {
                setTimeout(function () {
                    try {
                        var nextRejectValue = onRejected(self.rejectReason);
                        ResolutionRetrunPromise(nextPromise, nextRejectValue, res, rej);
                    }catch(e) {
                        rej(e);
                    }
                }, 0);
            });        
        }
    });
    return nextPromise;
};

MyPromise.prototype.catch = function (onRejected) {
    return this.then(null, onRejected);
};

MyPromise.prototype.finally = function (callback) {
    return this.then(function (data) {
        callback();
        return data;
    }, function (reason) {
        callback();
        throw reason;
    });
};


MyPromise.all = function (promiseArr) {
    return new MyPromise(function (res, rej) {
        var arr = [];
        var times = 0;
        function processResult (index, result) {
            arr[index] = result;
            times++;
            if (times ==  promiseArr.length) {
                res(arr);
            }
        };

        for (var i = 0; i < promiseArr.length; i++) {
           (function(j){
                var oPromise = promiseArr[j];
                if (typeof oPromise.then == 'function') {
                    oPromise.then(function (val) {
                        processResult(j, val)
                    }, function (reason) {
                        rej(reason);
                    })
                }else {
                    processResult(j, oPromise);
                }
           })(i)
        }
    });
};

MyPromise.race = function(promiseArr) {
    return new MyPromise(function (resolve, reject) {
        promiseArr.forEach(function (promise, index) {
           promise.then(resolve, reject);
        });
    });
};

MyPromise.reject = function (reason) {
    return new MyPromise(function (resolve, reject) {
        reject(reason);
    });
};

MyPromise.resolve = function (val) {
    return new MyPromise(function (resolve, reject) {
        resolve(val);
    });
};

var ajaxPromise = function(param){
    return new MyPromise(function(resolve, reject){
        $.ajax({
            "type": param.type || "get",
            "url": param.url,
            "success": function(res){resolve(res)},
            "error": function(err){reject(err)}
        })
    })
}

var CbaseUrl = "https://cnazure.blob.core.chinacloudapi.cn/"
var previewTag = location.host.toLowerCase().includes('cnazurepreview') ? 'cnazurepreview/': '';
// var CheaderUrl = CbaseUrl + "marketing-resource/Content/headerfooter/zh-cn/header.html"
// var CfooterUrl = CbaseUrl + "marketing-resource/Content/headerfooter/zh-cn/footer.html"
var CscriptUrl =  CbaseUrl + "marketing-resource/StaticService/js/jquery-1.12.3.min.js"
var CheaderUrl
var CfooterUrl
if (window.AcnHeaderFooter.CurrentLang === 'zh-cn') {
    CheaderUrl = CbaseUrl + previewTag + "marketing-resource/Content/headerfooter/zh-cn/header.html";
    CfooterUrl = CbaseUrl + previewTag + "marketing-resource/Content/headerfooter/zh-cn/footer.html";
} else {
    CheaderUrl = CbaseUrl + previewTag + "marketing-resource/Content/headerfooter/en-us/header.html";
    CfooterUrl = CbaseUrl + previewTag + "marketing-resource/Content/headerfooter/en-us/footer.html";
}

var getHeader = ajaxPromise({
    url: CheaderUrl
})

var getFooter = ajaxPromise({
    url: CfooterUrl
})

MyPromise.all([getHeader, getFooter]).then(function(result){
    $(".public_headerpage").html($(result[0]));
    var scriptArr = $(result[1]);
    for(var i = 0; i < scriptArr.length; i++) {
        if(scriptArr[i].src === CscriptUrl){
            scriptArr.splice(i, 1);
        }
    }
    $(".public_footerpage").html(scriptArr);
}).catch(function(error){
    console.log(error)
})