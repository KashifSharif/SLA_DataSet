﻿var WACNDataTracker = (function (win, doc, $) {
    "use strict";

    //track campaign id
    var oCampaignTracker = (function () {
        var oConfig = {
            sCampaignIdKey: "wt.mc_id"
        };
        function fSave() {
            //save campaign id
            var sCampaignIdValue = new Utility.oURLHandler(win.location.href).fGetQueryStringByKey(oConfig.sCampaignIdKey);
            if (sCampaignIdValue != undefined) {
                Utility.oCookie.fSet(oConfig.sCampaignIdKey, sCampaignIdValue);
            }
        }
        function fGet() {
            return Utility.oCookie.fGet(oConfig.sCampaignIdKey);
        }
        return {
            fGet: fGet,
            fSave: fSave
        };
    })();

    var oEntryReferrerTracker = (function () {
        var oConfig = {
            sReferrerKey: "mc_referrer",
            aInternalDomain: ["azure.cn", "support.windowsazure.cn", "www.azure.cn", "docs.azure.cn"]
        };
        function fSave() {
            //save entry page referrer url
            var sReferrerValue = doc.referrer;
            var bIsExternalUrl = true;
            oConfig.aInternalDomain.push(win.location.hostname);
            for (var i = 0; i < oConfig.aInternalDomain.length; i++) {
                if (sReferrerValue.indexOf(oConfig.aInternalDomain[i]) != -1) {
                    bIsExternalUrl = false;
                }
            }
            if (sReferrerValue && bIsExternalUrl) {
                Utility.oCookie.fSet(oConfig.sReferrerKey, sReferrerValue);
            }
        }
        function fGet() {
            return Utility.oCookie.fGet(oConfig.sReferrerKey);
        }
        return {
            fGet: fGet,
            fSave: fSave
        };
    })();

    var oABTestTracker = (function () {
        var oConfig = {
            sABTestKey: "v"
        };
        function fSave() {
            var sABTestValue = new Utility.oURLHandler(win.location.href).fGetQueryStringByKey(oConfig.sABTestKey);
            if (sABTestValue != undefined) {
                Utility.oCookie.fSet(oConfig.sABTestKey, sABTestValue);
            }
        }
        function fGet() {
            return Utility.oCookie.fGet(oConfig.sABTestKey);
        }
        return {
            fGet: fGet,
            fSave: fSave
        };
    })();

    return {
        oCampaignTracker: oCampaignTracker,
        oEntryReferrerTracker: oEntryReferrerTracker,
        oABTestTracker: oABTestTracker
    };
})(window, document);

var Utility = (function (win, doc) {
    "use strict";

    var objKeys = function (obj) {
        var result = [];
        for (var key in obj) {
            if (obj.hasOwnProperty(key)) {
                result.push(key);
            }
        }
        return result;
    };

    var oURLHandler = (function () {
        function URLHandler(sUrl) {
            this.sUrl = sUrl;
        }
        URLHandler.prototype.fGetHost = function () {
            return this.fGetLocation().hostname;
        }
        URLHandler.prototype.fGetLocation = function () {
            var oLocation = doc.createElement("a");
            oLocation.href = this.sUrl;
            return dLocation;
        }
        URLHandler.prototype.fGetQueryStringObj = function () {
            var nIndex = this.sUrl.indexOf('?');
            if (nIndex == -1) {
                return {};
            }
            var aQueryStrings = this.sUrl.substring(nIndex + 1).split('&');
            var oQueryString = {};
            for (var i = 0; i < aQueryStrings.length; i++) {
                var keyValuePair = aQueryStrings[i].split('=');
                if (keyValuePair.length != 2) {
                    continue;
                }
                oQueryString[keyValuePair[0]] = keyValuePair[1];
            }
            return oQueryString;
        }
        URLHandler.prototype.fGetQueryStringByKey = function (sKey) {
            var oQueryString = this.fGetQueryStringObj();
            if (objKeys(oQueryString).length == 0) {
                return undefined;
            }
            if (oQueryString[sKey] == undefined) {
                return undefined;
            }
            return oQueryString[sKey];
        }

        return URLHandler;
    })();

    var oSessionStorage = (function () {
        function fSessionStorageSupport() {
            try {
                return !!win.sessionStorage;
            } catch (oError) {
                return false;
            }
        }
        if (!fSessionStorageSupport()) {
            return;
        }
        var oSessionStorage = win.sessionStorage;
        function fSerialize(oData) {
            if (oData == undefined) {
                return undefined;
            }
            return JSON.stringify(oData);
        }
        function fDeserilize(sData) {
            if (sData == undefined) {
                return undefined;
            }
            return JSON.parse(sData);
        }
        function fSet(sKey, oValue) {
            if (sKey == undefined)
                return;
            if (oValue == undefined) {
                oSessionStorage.removeItem(sKey);
                return;
            }
            oSessionStorage.setItem(sKey, fSerialize(oValue));
        }
        function fGet(sKey) {
            return fDeserilize(oSessionStorage.getItem(sKey));
        }
        function fRemove(sKey) {
            oSessionStorage.removeItem(sKey);
        }
        function fClear() {
            oSessionStorage.clear();
        }
        return {
            fSet: fSet,
            fGet: fGet,
            fRemove: fRemove,
            fClear: fClear
        };
    })();

    var oCookie = (function () {
        function fGet(sKey) {
            return $.cookie(sKey);
        }
        function fSet(sKey, oValue) {
            if (sKey == undefined)
                return;
            if (oValue == undefined) {
                $.removeCookie(sKey);
                return;
            }
            $.cookie(sKey, oValue, {
                path: '/',          //The value of the path attribute of the cookie 
                domain: '.azure.cn',  //The value of the domain attribute of the cookie
            });
        }
        return {
            fSet: fSet,
            fGet: fGet
        };
    })();

    return {
        oURLHandler: oURLHandler,
        oSessionStorage: oSessionStorage,
        oCookie: oCookie
    };
})(window, document, jQuery);

(function () {
    WACNDataTracker.oCampaignTracker.fSave();
    WACNDataTracker.oEntryReferrerTracker.fSave();
    WACNDataTracker.oABTestTracker.fSave();
})();
