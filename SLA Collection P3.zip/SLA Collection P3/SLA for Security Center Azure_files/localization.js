if ((window.AcnHeaderFooter && window.AcnHeaderFooter.HideLocaleSwitcher)
    || (window.location.host != "www.azure.cn")
    && (window.location.href!= "https://www.azure.cn/en-us/")
    && (window.location.host != "support.azure.cn")) {
    var selectors = document.querySelectorAll("#locale-selector-section");
    for (var i = 0; i < selectors.length; i++) {
        selectors[i].style.display = "none";
    }
}
else {
    var headTag = document.getElementsByTagName("head")[0];
    var cssTag = document.createElement('link');
    cssTag.rel = 'stylesheet';
    cssTag.href = 'https://cnazure.blob.core.chinacloudapi.cn/marketing-resource/StaticService/css/dropkick.css';
    headTag.appendChild(cssTag);

    var jqTag = document.createElement('script');
    jqTag.type = 'text/javascript';
    jqTag.src = 'https://cnazure.blob.core.chinacloudapi.cn/marketing-resource/StaticService/js/dropkick.js';
    jqTag.onload = function () {
        new Dropkick("#locale-selector", {
            mobile: false,
            initialize: function () {

                // if (window.location.href === "https://www.azure.cn/" || window.location.href === "https://www.azure.cn") {
                //     locale = "zh-CN"
                // } else if (window.location.href.toLowerCase().includes("en-us")) {
                //     locale = "en-US"
                // } else if (window.location.href.toLowerCase().includes("zh-cn")) {
                //     locale = "zh-CN"
                // } else {
                //     locale = "en-US"
                // }
                if(window.location.href.toLowerCase().includes("en-us")){
                    locale="en-US";
                }else{
                    locale="zh-CN";
                }
                this.select(locale);

            },
            change: function () {
                // There is no dk-select element in mobile
                // Get locale value directly from select element
                if (document.getElementsByClassName('dk-select').length == 0) {
                    this.value = document.getElementById("locale-selector").value;
                }

                var Days = 365 * 10; // Ten year expiration          
                var exp = new Date();

                var hostName = window.location.hostname;
                var secondLevelDomain = hostName.substring(hostName.lastIndexOf(".", hostName.lastIndexOf(".") - 1));
                if (window.location.host == "www.azure.cn") {
                    secondLevelDomain = "zh-cn"
                } else {
                    secondLevelDomain = "en-us"
                }

                exp.setTime(exp.getTime() + Days * 24 * 60 * 60 * 1000);
                document.cookie = "acn_selected_locale=" + this.value + ";domain=" + secondLevelDomain + "; path=/;expires=" + exp.toGMTString();

                if (window.AcnHeaderFooter && window.AcnHeaderFooter.OnLangChange && typeof window.AcnHeaderFooter.OnLangChange === "function") {
                    window.AcnHeaderFooter.OnLangChange(this.value);
                }
                
                if (window.location.host == "www.azure.cn" && this.value == "en-US") {
                    window.location.href = window.location.href.replace("www.azure.cn", "www.azure.cn/en-us").replace("index.html", "");
                } else if (window.location.href.toLowerCase().includes("zh-cn") && this.value == "en-US") {
                     window.location.href = window.location.href.replace("zh-cn", "en-us");
                } 
                else if (window.location.href.toLowerCase().includes("en-us") && this.value == "zh-CN") {
                    window.location.href = window.location.href.replace("en-us", "zh-cn");
                }
            },
        });
    }
    headTag.appendChild(jqTag);
}

var currentLang = "zh-cn";
if (window.AcnHeaderFooter) {
    currentLang = window.AcnHeaderFooter.CurrentLang || "zh-cn";
}

if (document.getElementsByClassName("acn-header-service")[0]) {
    document.getElementsByClassName("acn-header-service")[0].className += " " + currentLang.toLowerCase();
}
if (document.getElementsByClassName("acn-footer-service")[0]) {
    document.getElementsByClassName("acn-footer-service")[0].className += " " + currentLang.toLowerCase();
}
