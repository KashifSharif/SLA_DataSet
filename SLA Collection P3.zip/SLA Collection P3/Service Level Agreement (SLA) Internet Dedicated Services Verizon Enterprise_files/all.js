/*
 * jQuery throttle / debounce - v1.1 - 3/7/2010
 * http://benalman.com/projects/jquery-throttle-debounce-plugin/
 * 
 * Copyright (c) 2010 "Cowboy" Ben Alman
 * Dual licensed under the MIT and GPL licenses.
 * http://benalman.com/about/license/
 */
(function(b,c){var $=b.jQuery||b.Cowboy||(b.Cowboy={}),a;$.throttle=a=function(e,f,j,i){var h,d=0;if(typeof f!=="boolean"){i=j;j=f;f=c}function g(){var o=this,m=+new Date()-d,n=arguments;function l(){d=+new Date();j.apply(o,n)}function k(){h=c}if(i&&!h){l()}h&&clearTimeout(h);if(i===c&&m>e){l()}else{if(f!==true){h=setTimeout(i?k:l,i===c?e-m:e)}}}if($.guid){g.guid=j.guid=j.guid||$.guid++}return g};$.debounce=function(d,e,f){return f===c?a(d,e,false):a(d,f,e!==false)}})(this);

/*!
 * jQuery Cookie Plugin v1.4.1
 * https://github.com/carhartl/jquery-cookie
 *
 * Copyright 2006, 2014 Klaus Hartl
 * Released under the MIT license
 */
(function (factory) {
	if (typeof define === 'function' && define.amd) {
		// AMD (Register as an anonymous module)
		define(['jquery'], factory);
	} else if (typeof exports === 'object') {
		// Node/CommonJS
		module.exports = factory(require('jquery'));
	} else {
		// Browser globals
		factory(jQuery);
	}
}(function ($) {

	var pluses = /\+/g;

	function encode(s) {
		return config.raw ? s : encodeURIComponent(s);
	}

	function decode(s) {
		return config.raw ? s : decodeURIComponent(s);
	}

	function stringifyCookieValue(value) {
		return encode(config.json ? JSON.stringify(value) : String(value));
	}

	function parseCookieValue(s) {
		if (s.indexOf('"') === 0) {
			// This is a quoted cookie as according to RFC2068, unescape...
			s = s.slice(1, -1).replace(/\\"/g, '"').replace(/\\\\/g, '\\');
		}

		try {
			// Replace server-side written pluses with spaces.
			// If we can't decode the cookie, ignore it, it's unusable.
			// If we can't parse the cookie, ignore it, it's unusable.
			s = decodeURIComponent(s.replace(pluses, ' '));
			return config.json ? JSON.parse(s) : s;
		} catch(e) {}
	}

	function read(s, converter) {
		var value = config.raw ? s : parseCookieValue(s);
		return $.isFunction(converter) ? converter(value) : value;
	}

	var config = $.cookie = function (key, value, options) {

		// Write

		if (arguments.length > 1 && !$.isFunction(value)) {
			options = $.extend({}, config.defaults, options);

			if (typeof options.expires === 'number') {
				var days = options.expires, t = options.expires = new Date();
				t.setMilliseconds(t.getMilliseconds() + days * 864e+5);
			}

			return (document.cookie = [
				encode(key), '=', stringifyCookieValue(value),
				options.expires ? '; expires=' + options.expires.toUTCString() : '', // use expires attribute, max-age is not supported by IE
				options.path    ? '; path=' + options.path : '',
				options.domain  ? '; domain=' + options.domain : '',
				options.secure  ? '; secure' : ''
			].join(''));
		}

		// Read

		var result = key ? undefined : {},
			// To prevent the for loop in the first place assign an empty array
			// in case there are no cookies at all. Also prevents odd result when
			// calling $.cookie().
			cookies = document.cookie ? document.cookie.split('; ') : [],
			i = 0,
			l = cookies.length;

		for (; i < l; i++) {
			var parts = cookies[i].split('='),
				name = decode(parts.shift()),
				cookie = parts.join('=');

			if (key === name) {
				// If second argument (value) is a function it's a converter...
				result = read(cookie, value);
				break;
			}

			// Prevent storing a cookie that we couldn't decode.
			if (!key && (cookie = read(cookie)) !== undefined) {
				result[name] = cookie;
			}
		}

		return result;
	};

	config.defaults = {};

	$.removeCookie = function (key, options) {
		// Must not alter options, thus extending a fresh object...
		$.cookie(key, '', $.extend({}, options, { expires: -1 }));
		return !$.cookie(key);
	};

}));

/**
 * File: global.js
 * Author: Jeff Simko
 * Copyright: MRM//McCann 2018
 */

(function() {
    
    //For Accessibility Tab Navigation
    var $lastTab = null;

    var global = function(el) {
        this.$ctx = $(el);
        this.setup();
    };


    global.prototype = {

        setup: function() {

            var self = this;

            self.setIsTouch();
            self.setBreakPointClass();
            self.encodeQuotedMarkup();
  
            $(window).on('resize', $.debounce(250, function() {
                self.setBreakPointClass();
            }));
        },

        setIsTouch: function() {
            var $htmlEle = $('html');
            var isTouch =  !!("ontouchstart" in window) || window.navigator.msMaxTouchPoints > 0;

            if(isTouch){
                $htmlEle.addClass('isTouch');
            } else {
                $htmlEle.removeClass('isTouch');
            }
        },

        /*
        Sets Break Point Class for Js conditions.
        Use $('html').hasClass('mobile/tablet/desktop') for true/false bool
        */

        setBreakPointClass: function() {
            var self = this;
            var viewportWidth = $(window).width();
            var viewportHeight = $(window).height();
            var $htmlEle = $('html');

            $htmlEle.removeClass('mobile').removeClass('tablet').removeClass('desktop');

            if (viewportWidth <= 576) {
                $htmlEle.addClass('mobile').trigger('breakPointChange');
            } else if (viewportWidth > 576 && viewportWidth < 768) {
                $htmlEle.addClass('tablet').trigger('breakPointChange');
            } else {
                $htmlEle.addClass('desktop').trigger('breakPointChange');
            }
        },
        encodeQuotedMarkup: function(){
            $('code.html').each(function(count, value){
                var markup = $(value).html();
                $(value).empty();
                $(value).text(markup);
                hljs.highlightBlock(value);
            });

        }

    };

    $(function() {
        $('html').each(function() {
            new global(this);
        });
    });
})(jQuery);
(function($){

    // Setup vzInit. Used for gtm and aims chat icon
    vzInit = new function() {
        var init = this;
        this.onready = [];
        this.onload = [];
        this.onajax = [];
        var doneready = 0;
        var doneload = 0;
        this.add = function(f, d, l, a) { if (typeof(f) == "function") { if (d > 0) { init.onready.push(f) } else if (d < 0) { init.onready.unshift(f) } if (l > 0) { init.onload.push(f); } else if (l < 0) { init.onload.unshift(f); } if (a > 0) { init.onajax.push(f); } else if (a < 0) { init.onajax.unshift(f); } } };
        this.onReady = function(f) {
            if (typeof(f) == "function") {
                (doneready ? f() : init.onready.push(f));
            } else {
                while (init.onready.length) {
                    var f = init.onready.shift();
                    f();
                }
                doneready = 1;
            }
        };
        this.onLoad = function(f) {
            if (typeof(f) == "function") {
                (doneload ? f() : init.onload.push(f));
            } else {
                while (init.onload.length) {
                    var f = init.onload.shift();
                    f();
                }
                doneload = 1;
            }
        };
        this.onAjax = function(f) { if (typeof(f) == "function") { init.onajax.push(f); } else { for (i in init.onajax) { init.onajax[i](f); } } }
    };

    if ($ && typeof($.noop) != "undefined") {
        $(document).ready(function() {
            vzInit.onReady();
            $(window).on('load', vzInit.onLoad);
        });
    }

})(jQuery);

var ves = {};

(function(){
	ves.utils = {};
	ves.breakpoints = {};
})();

$.extend(ves.utils, {
    windowWidth:function () {
        return Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
    },
    insertParam2: function(key,value) {
        key = encodeURIComponent(key); value = encodeURIComponent(value);
        var s = document.location.search;
        var kvp = key+"="+value;
        var r = new RegExp("(&|\\?)"+key+"=[^\&]*");
        if (s.match(r)) {
            s = s.replace(r,"$1"+kvp);
        } else {
            s += (s.length>0 ? '&' : '?') + kvp;
        }

        //document.location.search = s;
    },
	getParameterByName: function(name) {
		name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
		var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
		results = regex.exec(location.search);
		return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
	},
	urlParameters: function(isHash) {

		// This function is anonymous, is executed immediately and 
		// the return value is assigned to QueryString!
		var query_string = {};
		var query = "";
		if (isHash === true) {
			query = window.location.hash.substring(1);
		} else {
			query = window.location.search.substring(1);
		}

		if (query.length === 0) return {};
		
		var vars = query.split("&");
		for (var i=0;i<vars.length;i++) {
			var pair = vars[i].split("=");
			var pairFirst = decodeURIComponent(pair[0]);
			var pairSecond = decodeURIComponent(pair[1]);
				// If first entry with this name
			if (typeof query_string[pairFirst] === "undefined") {
				query_string[pairFirst] = pairSecond;
				// If second entry with this name
			} else if (typeof query_string[pairFirst] === "string") {
				var arr = [ query_string[pairFirst], pairSecond ];
				query_string[pairFirst] = arr;
				// If third or later entry with this name
			} else {
				query_string[pairFirst].push(pairSecond);
			}
		} 
		return query_string;
	},
    toQueryString: function(obj) {
        var parts = [];
        for (var i in obj) {
            if (obj.hasOwnProperty(i)) {
                parts.push(encodeURIComponent(i) + "=" + encodeURIComponent(obj[i]));
            }
        }
        return parts.join("&");
    },
    getObjectSize: function(obj){
        var size = 0, key;
        for (key in obj) {
            if (obj.hasOwnProperty(key)) size++;
        }
        return size;
    },
});

/*
 * ves.breakpoint.desktop 
 * returns breakpoint int values
*/
$.extend(ves.breakpoints, {
	xsmall: 320,
	mobile: 768,
	tablet: 992,
	desktop: 1200,
	xlarge: 1272
});
(function() {

	var $body = $('body');
	var $header = $('header');
    var $secondaryNav = $('div.secondarynav:first');
    var $anchorNav = $('div.anchornav:first');
	var $backToTop = $('div.back-to-top');
	var backToTopHTML = '<div class="back-to-top hide" aria-hidden="true">&uparrow;</div>';

	// scroll values
	var currentTop = 0;
	var previousTop = 0;
	var scrollDelta = 24;
	var scrollOffset = 372; //$header.outerHeight() - 50;
	var initalAnchorPosition = ($anchorNav.length) ? $anchorNav.offset().top : 0;

	if ($secondaryNav.length) $body.addClass('hasSecondaryNav');
	if ($anchorNav.length) $body.addClass('hasAnchorNav');

	/* debounce scroll event to keep count low */
    function _handleScroll() {
  	  $(window).on("scroll", $.throttle(100, function(){

		currentTop = ($(window).scrollTop() || $('body').scrollTop());

		_handlePrimaryNav();
		if ($secondaryNav.length) _handleSecondaryNav();
		if ($anchorNav.length) _handleAnchorNav();

		previousTop = currentTop;

	  }));
	//$(window).trigger("scroll");
    };

	/* handles the "stickyness" and placement of the Primary navigation */
	function _handlePrimaryNav() {
		
		if (previousTop - currentTop > scrollDelta || currentTop < 4) {
	    	//if scrolling up...
	    	$header.removeClass("hide");
	    	$backToTop.addClass("hide");
	    	$body.removeClass('primary-nav-hidden');
	    } else if( currentTop - previousTop > scrollDelta && currentTop > scrollOffset) {
	    	//if scrolling down...
	    	$header.addClass("hide");
	    	$backToTop.removeClass("hide");
	    	$body.addClass('primary-nav-hidden');
	    }
	};

	/* handles the "stickyness" and placement of the Secondary navigation */
	function _handleSecondaryNav() {

		if (currentTop <= 4 || previousTop - currentTop > scrollDelta) {
	    	//if scrolling up...
	    	$secondaryNav.removeClass("fixed");
	    	$body.removeClass('secondary-nav-fixed');
	    } else if( currentTop - previousTop > scrollDelta && currentTop > scrollOffset) {
	    	//if scrolling down...
	    	$secondaryNav.addClass("fixed");
	    	$body.addClass('secondary-nav-fixed');
		} 
	};

	/* handles the "stickyness" and placement of the Anchor navigation */
	function _handleAnchorNav() {

		if (currentTop <= 4 || previousTop - currentTop > scrollDelta) {
	    	//if scrolling up...
	    	$anchorNav.removeClass("fixed");
	    	$anchorNav.find('a').removeClass('selected');
	    	$body.removeClass('anchor-nav-fixed');
	    } else if( currentTop - previousTop > scrollDelta && currentTop > initalAnchorPosition) {
	    	//if scrolling down...
	    	$anchorNav.addClass("fixed");
	    	$body.addClass('anchor-nav-fixed');
	    }
	};

	/* adds the back to top button */
	function _handleBackToTop() {
        scrollOffset = $header.outerHeight() - 50;
		$('body').append(backToTopHTML);
		$backToTop = $('.back-to-top');

		$backToTop.on("click", function(){
			$('html, body').animate({scrollTop:0}, 600);
		});
	};

	// function handleResize(self) {
	// 	$(window).on("resize", function() {
	// 		self.$ctx.find(".overlay").css({
	// 			"top": self.$ctx.find('nav').outerHeight()
	// 		});

	// 		/* close mobile menu if open and resized to tablet */
	// 		if (ves.utils.windowWidth() <= ves.breakpoints.desktop) {
	// 			self.closeMenu();
	// 		}
	// 	});
	// };

    function _complete() {
        $("body").addClass("complete");
    }

	$(document).ready(_handleScroll);
    $(window).on("load.complete",_complete);
    $(document).ready(function() { setTimeout(_complete,2000); });
	$(window).on("load",_handleBackToTop);
})(jQuery);
"use strict";

var ElementStateCookies = {

    name: 'ElementState_Cookie',

    setId: function ($target, id) {
        $target.attr("id", id);
    },

    setValue: function (settings) {
        if (settings === null) {
            return;
        }
        var value = this.parseValue(typeof(sessionStorage)!="undefined" ? sessionStorage.elementState : $.cookie(this.name));

        var cookieObj = {};
        if (settings.hasOwnProperty('id')) {
            cookieObj["id"] = settings.id;
        }
        if (settings.hasOwnProperty('slide')) {
            cookieObj["currentSlide"] = settings.slide;
        }
        if (settings.hasOwnProperty('filter')) {
            cookieObj["filter"] = settings.filter;
        }
        if (settings.hasOwnProperty('sort')) {
            cookieObj["sort"] = settings.sort;
        }
        cookieObj["url"] = (window.location.origin + window.location.pathname)
        value.push(cookieObj);
        //sets a cookie after each slide change
        if (typeof(sessionStorage)!="undefined") {
            sessionStorage.elementState=JSON.stringify(value);
        } else {
        	$.cookie(this.name, value);
        }
        //console.log(this.name, value);
    },

    getValue: function ($target) {
        var value = this.parseValue($.cookie(this.name));
        if (value) {
            for (var i = 0; i < value.length; i++) {
                // carousel data
                if (value[i].url === (window.location.origin + window.location.pathname)) {
                    if (value[i].hasOwnProperty('id') && value[i].id === $target.attr("id")) {
                        return value[i].currentSlide;
                    }
                    // filter and sort data
                    else if ($target === 'filter' && value[i].hasOwnProperty('filter')) {
                        return value[i].filter;
                    } else if ($target === 'sort' && value[i].hasOwnProperty('sort')) {
                        return value[i].sort;
                    }
                }
            }
        }
        return 0;
    },

    parseValue: function (value) {
        if (typeof value === 'string') {
            try {
                return JSON.parse(value);
            } catch (e) {
                return [];
            }
        } else if (!value) {
            return [];
        }
        return value;
    },

    removeElementFromCookie: function ($target) {
        var value = this.parseValue(typeof(sessionStorage)!="undefined" ? sessionStorage.elementState : $.cookie(this.name));

        if (value.length > 0) {
            for (var i = 0; i < value.length; i++) {
                if (value[i].id === $target.attr("id") && value[i].url === (window.location.origin + window.location.pathname)) {
                    value.splice(i, 1);
                    break;
                }
            }
            if (typeof(sessionStorage)) {
                sessionStorage.elementState=JSON.stringify(value);
                if (!value.length) { delete sessionStorage.elementState; }
            } else if (value.length === 0) {
                $.removeCookie(this.name);
            } else {
                $.cookie(this.name, value);

            }
        }
    },

    verifyCarouselValue: function ($target, slide) {
        // don't push any value if state didn't change
        if (slide === 0) {
            this.removeElementFromCookie($target);
            return;
        }

        var value = this.parseValue(typeof(sessionStorage)!="undefined" ? sessionStorage.elementState : $.cookie(this.name));

        // if array is empty then push
        if (value.length === 0) {
            this.setValue({
                "id": $target.attr('id'),
                "slide": slide
            });
        } else {
            //check if value does not exist for current carousel
            var isValueUpdated = false;
            for (var i = 0; i < value.length; i++) {
                if (value[i].hasOwnProperty('id') && value[i].id === $target.attr("id") &&
                    value[i].url === (window.location.origin + window.location.pathname)) {
                    value[i].currentSlide = slide;
                    isValueUpdated = true;
                    if (typeof(sessionStorage)) {
                		sessionStorage.elementState=JSON.stringify(value);
                    } else {
                        $.cookie(this.name, value);
                    }
                    break;
                }
            }
            if (!isValueUpdated) {
                this.setValue({
                    "id": $target.attr('id'),
                    "slide": slide
                });
            }
        }
    },

    verifyCsFilterSortValue: function (options) {
        if (!options) {
            return;
        }
        var value = this.parseValue(typeof(sessionStorage)!="undefined" ? sessionStorage.elementState : $.cookie(this.name));

        var optionProp = this.getOptionProperty(options);
        // if array is empty then push
        if (value.length === 0) {
            this.setValue(optionProp);
        } else {
            //check if value does not exist for current carousel
            var isValueUpdated = false;
            for (var i = 0; i < value.length; i++) {
                if (value[i].url === (window.location.origin + window.location.pathname)) {
                    if (optionProp.hasOwnProperty('filter') && value[i].hasOwnProperty('filter')) {
                        value[i].filter = optionProp.filter;
                        isValueUpdated = true;
                        break;
                    } else if (optionProp.hasOwnProperty('sort') && value[i].hasOwnProperty('sort')) {
                        value[i].sort = optionProp.sort;
                        isValueUpdated = true;
                        break;
                    }
                }
            }
            if (!isValueUpdated) {
                this.setValue(optionProp);
            } else if (typeof(sessionStorage)) {
                sessionStorage.elementState=JSON.stringify(value);
            } else {
                $.cookie(this.name, value);
            }
        }
    },

    getOptionProperty: function (option) {
        if (option.hasOwnProperty('filter')) {
            return {
                "filter": option.filter
            };
        } else if (option.hasOwnProperty('sort')) {
            return {
                "sort": option.sort
            };
        }
        return null;
    }
};
// save business unit
if (!window.location.pathname.indexOf("/business/")) {
    if ((document.cookie||"").indexOf("VZ_ATLAS_SITE_PERS=")<0) {
        var exp=new Date(); exp.setTime(exp.getTime() + 365 * 864e5);
        document.cookie="VZ_ATLAS_SITE_PERS=BusinessUnit=business; domain=.verizon.com;path=/; expires="+exp.toUTCString();
    }
}

/**
 * File: tilegroup.js
 * Author: Jeff Simko
 * Copyright: MRM//McCann 2018
 */

(function() {
    var TileGroup = function(el) {
        this.$ctx = $(el);
        this.$slickTile = $(el).find('.tile-layout.slider');
        this.setup();
		
		
    };
	
	var findFirst = function(el) {
        var $tile = $(el).find('.tile');
        var $imageTile = $(el).find('.imageTile');
		
		$tile.first().addClass("first");
        $imageTile.first().addClass("first");
		
    };
	
	var findFirst = function(el) {
        var $tile = $(el).find('.tile');
        var $imageTile = $(el).find('.imageTile');
		
		$tile.first().addClass("first");
        $imageTile.first().addClass("first");
		
    };

    TileGroup.prototype = {

        setup: function() {
            var self = this;
            self.toggleTileGridSlick();
            self.bindEvents();
			self.lightDarkArrow();
        },

		bindEvents: function() {
            var self = this;

            //Toggle slick orientationchange
            $(window).on("orientationchange breakPointChange", function() {
                self.toggleTileGridSlick();
            });
        },

        toggleTileGridSlick: function() {
            var isMobile = $('html').hasClass('mobile');
            var self = this;
            var isSlickGridInitialized = this.$slickTile.hasClass('slick-initialized');
            var tileLength = this.$slickTile.find('.tile').length;
            if (typeof($.slick)=="undefined") { return; } // slick not installed
          
            //Only Initialize if not already Initialized
            if (!isSlickGridInitialized && isMobile && tileLength > 1) {

                //Setup Slick grid for mobile 576
                this.$slickTile.slick({
                    infinite: true,
                    mobileFirst: true,
                    arrows: true,
                    dots: true,
                    speed: 300,
                    cssEase: 'linear',
					variableWidth: true,
                    responsive: [{
                        breakpoint: 736,
                        settings: "unslick"
                    }]
                });
            }
            this.$slickTile.on('afterChange', function(event, slick, currentSlide, nextSlide){
                self.$slickTile.find('.slick-slide:not(.slick-current) .tile a p').removeClass('fade-in').addClass('fade-out');
                self.$slickTile.find('.slick-current .tile a p').removeClass('fade-out').addClass('fade-in');
            });
            this.$slickTile.trigger('afterChange');

			self.resizeSlick();
        },
		
		lightDarkArrow : function(){
			this.$slickTile.on('afterChange', function(event, slick, currentSlide, nextSlide){
                
			});
		},

		resizeSlick : function(){
			var windowWidth = $(window).width();
			var tileWidth = windowWidth - 40 +'px';
			
			this.$ctx.find('.slick-slide').css('width', tileWidth)
		}
    };

    $(function() {
        $('.tilegroup').each(function() {
            new TileGroup(this);
			
			new findFirst(this);
			
        });
		
    });

})(jQuery);


(function () {
    var ImageVideoOverlay = function (el) {
        this.setup($(el));
    };

    ImageVideoOverlay.prototype = {
        setup:function (bgImg) {
            if (bgImg.length) {
                var mobileImg = bgImg.data('mobileImg');
                var desktopImg = bgImg.data('desktopImg');

                if (desktopImg !== undefined && mobileImg !== undefined) {
                	var viewportWidth = $(window).width();
                    if (viewportWidth < 768) {
                        bgImg.css('background-image', 'url('+mobileImg+')');
                    } else {
                        bgImg.css('background-image', 'url('+desktopImg+')');
                    }
                    $('html').on('breakPointChange', function(){
                        var viewportWidth = $(window).width();
                        if (viewportWidth < 768) {
                            bgImg.css('background-image', 'url('+mobileImg+')');
                        } else {
                            bgImg.css('background-image', 'url('+desktopImg+')');
                        }
                    });
                } else if (desktopImg !== undefined) {
                    bgImg.css('background-image', 'url('+desktopImg+')');
                } else if (mobileImg !== undefined) {
                    bgImg.css('background-image', 'url('+mobileImg+')');
                }

            }

        }
    };

    $(document).ready(function () {
        $('div.imagevideooverlay .bg-image').each(function () {
            new ImageVideoOverlay(this);
        });
    });
})(jQuery);

/**
 * File: tabs.js
 * Author: Yvonne Newsome
 * Copyright: MRM//McCann 2018
 */

var tabbedNavigation = function($) {

    var $tabbedNavigation;
    var html;
    var $selectedDropdown;
    var $selectULOptions;
    var $tabscontainer;

    var _init = function() {
        $tabbedNavigation = $('.tabs');
        $selectedDropdown = $tabbedNavigation.find('.styledSelect');
        $selectULOptions = $selectedDropdown.find('ul');
        $tabscontainer = $tabbedNavigation.find('.tabs-container ul');

        html = $('html');

        html.on('breakPointChange', function() {
            // Run code here, resizing has "stopped"
            _breakPointChange();
        });

        //Hides all containers on start-up
        $tabbedNavigation.find('.tabbed-container li.tab-content').hide();
        _clickEvents();
    };

    var _breakPointChange = function() {
        if (html.hasClass('desktop')) {
            // $tabscontainer.css('display', 'inline')
            $selectedDropdown.closest('.select').removeClass('active');
        } else if (html.hasClass('tablet') || html.hasClass('mobile')) {
            // $tabscontainer.toggle();
        }
    }

    var _clickEvents = function() {

        // $tabbedNavigation.find('.tabbed-content').css('display', '');
        var $tabsNav = $tabbedNavigation.find('.tabs-container li.tab-name');

        $tabsNav.each(function(count, value) {

            //set first element to tab 1
            $($tabsNav.find('a')[0]).addClass('selected');
            $($tabbedNavigation.find('.tab-content')[0]).show();

            //sets the underline under the selected tab
            $(this).find('a').on('click', function(e) {
                e.preventDefault();
                $tabsNav.find('a').removeClass('selected');
                $(this).addClass('selected');

            });

            //Tab - which tab will show with click
            $(value).on('click', function(e) {
                $tabbedNavigation.find('.tab-content').hide();
                $($tabbedNavigation.find('.tab-content')[count]).show();
                var newTextValue = $(this).text();
                $selectedDropdown.text(newTextValue);
                // _breakPointChange();
                $selectedDropdown.closest('.select').toggleClass('active');
            });
        });

        //close dropdowns
        $(document).on('click', function(e) {
            if($('html').hasClass('mobile')){
                // $tabscontainer.css('display', 'none');
                $selectedDropdown.closest('.select').removeClass('active');
            }
        });

        $selectedDropdown.on('click', function(e) {
            e.stopPropagation();
            // $tabscontainer.toggle();
            $(this).closest('.select').toggleClass('active');
        });

        $selectedDropdown.on('keydown', function(e) {
            var key = e.which;

            //Enter or Space Key
            if (key === 13 || key === 32) {
                $(this).closest('.select').toggleClass('active');
                $(this).attr('aria-pressed', true).blur().focus();
                return false;
            }
        });

    };


    // output/public
    return {
        init: _init
    };
}(jQuery);

/* Fire off the doc ready */
jQuery(document).ready(function() {
    tabbedNavigation.init();
});
(function() {


    // wrap ul in larger columns
    $('.linklist').each(function() {

        var $parentGrid = $(this).parent('div'),
            $thisUL = $(this).find('ul.linklist-list'),
            stackLinkList = $(this).find('.stack-linklist');

        if (stackLinkList.length === 0) {
            if ($parentGrid.hasClass('col-sm-12')) {
                $thisUL.addClass('four-column');
            } else if ($parentGrid.hasClass('col-sm-9')) {
                $thisUL.addClass('three-column');
            } else if ($parentGrid.hasClass('col-sm-6')) {
                $thisUL.addClass('two-column');
            }
        }
    });


    // Event to show/hide the linklist-list of a collapsible-linklist:
    $('.collapsible-linklist .linklist-heading, .collapsible-linklist .linklist-heading-plus, .collapsible-linklist .linklist-heading-minus').click(toggleLinkList);

    // Event to redirect to the download link of a download icon:
    //$('.linklist-download-icon').click(redirectToDownloadLink);

    // Event to redirect to the outbound link of a outbound icon:
    //$('.linklist-outbound-icon').click(redirectToOutboundLink);

    // If the window resizes...
    $(window).resize(function() {
        // Window's width:
        var window_width = $(window).width();

        // If breakpoint is 768+...
        if (window_width >= 768) {
            // Show all linklist lists:
            $('.linklist-list').show();
            $('.linklist-heading-minus').addClass('hide');
        } else {
            $('.linklist-heading-minus').removeClass('hide');
        }
    });

    // Shows/Hides a linklist-list.
    function toggleLinkList(event) {

        // If the element clicked was the .linklist-heading:
        if ($(event.target).hasClass('linklist-heading')) {
            // Clicked heading:
            var heading = $(event.target);
            var $plusMinus = $(event.target).find('span');

            $plusMinus.toggleClass("linklist-heading-plus linklist-heading-minus");
        }
        // If the element clicked was the .linklist-heading-plus or .linklist-heading-minus:
        else if ($(event.target).hasClass('linklist-heading-plus') || $(event.target).hasClass('linklist-heading-minus')) {
            // Current heading:
            var heading = $(event.target).parent();

            // Prevent further propagation of the current event in the capturing and bubbling phases:
            event.stopPropagation();
        }

        // Window's width:
        var window_width = $(window).width();

        // If breakpoint is up to 768...
        if (window_width <= 768) {
            // Show/Hide the linklist-list:
            heading.next('.linklist-list').slideToggle();
        }
    }

    // Redirects to a download link.
    // function redirectToDownloadLink(event) {
    // 	if ($(event.target).hasClass('linklist-download-icon')) {
    // 		// Redirect to the download link:
    // 		$(event.target).prev('.linklist-download-link')[0].click();
    // 	}
    // 	else {
    // 		// Redirect to the download link:
    // 		$(event.target).parent().parent().prev('.linklist-download-link')[0].click();
    // 	}
    // }

    // Redirects to an outbound link.
    // function redirectToOutboundLink(event) {
    // 	if ($(event.target).hasClass('linklist-outbound-icon')) {
    // 		// Redirect to the outbound link:
    // 		$(event.target).prev('.linklist-outbound-link')[0].click();
    // 	}
    // 	else {
    // 		// Redirect to the outbound link:
    // 		$(event.target).parent().parent().prev('.linklist-outbound-link')[0].click();
    // 	}
    // }
})(jQuery);
/**
 * File: anchor-navigation.js
 * Author: Yvonne Newsome
 * Copyright: MRM//McCann 2018
 */

var anchornav = function($) {

    var $anchorNavigation;
    var $selectedDropdown;
    var $selectULOptions;
    var $select;
    var navOffset;
    var html = $('html');
    var $scrollLinkHoverBefore;
    var target = window.location.hash;
    var lastTargetTop = 0;

    var _init = function() {
        $anchorNavigation = $('.anchornav');
        $select = $anchorNavigation.find('.select');
        $selectedDropdown = $anchorNavigation.find('.styledSelect');
        $selectULOptions = $anchorNavigation.find('.options');
        $scrollLinkHoverBefore = $anchorNavigation.find('a.scrollLink:before');

        html.on('breakPointChange', function() {
            // Run code here, resizing has "stopped"
            _breakPointChange();
        });

        if (html.hasClass('desktop')) {
            var itemsWidth = 0;
            var containerWidth = $anchorNavigation.find('ul.options').outerWidth();
            $anchorNavigation.find('li').each(function() {
                itemsWidth = itemsWidth + $(this).outerWidth();
            });

            if (itemsWidth > containerWidth) {
                $anchorNavigation.find('.switchAnchorDropDown').addClass('forceAnchorDropDown').removeClass('switchAnchorDropDown');
            }
        }

        //_handleWayPoints();

        _clickEvents(function() {
            if (target && $('a[href$="' + target + '"]').length) {
                $('a[href$="' + target + '"]').delay(500).queue(function() {
                    $(this).trigger('click');
                });
            }
        });
    };

    var _handleWayPoints = function() {
        var anchors = $(".anchor > div");
        var navigation_links = $(".anchor-nav a");

        anchors.each(function(index, item) {
            $(this).waypoint({
                handler: function(direction) {
                    var switchAnchorDropDown = $('.switchAnchorDropDown button span');
                    var anchorId = $(item).data('anchor-id');
                    var navLink = $(".anchor-nav a[href$='#" + anchorId + "']");
                    var navText = navLink.text();

                    navigation_links.removeClass('selected');
                    navLink.addClass('selected');
                    switchAnchorDropDown.text(navText);
                },
                offset: '25%'
            });
        })
    };

    var _breakPointChange = function() {
        if (html.hasClass('desktop') && $anchorNavigation.find('.forceAnchorDropDown').length === 0) {
            $selectULOptions.css('display', 'flex');
        } else if (html.hasClass('tablet') || html.hasClass('mobile')) {
            $selectULOptions.css('display', 'none');
            $select.removeClass('active');
        }
    }

    var _clickEvents = function(callback) {

        $("a.scrollLink").click(function(event) {
            event.preventDefault();

            var headerHeight = $('header').height();
            var secNavHeight = ($('.secondarynav').length) ? $('.secondarynav').height() : 0;
            var anchorNavHeight = ($('.anchornav').length) ? $('.anchornav').height() : 0;
            var navOffset = secNavHeight + anchorNavHeight + 20;
            var windowTop = $(window).scrollTop();
            var targetId = $(this).attr("href").replace('#', '');
            var targetTop = $("div[data-anchor-id='" + targetId + "'],a[name='"+targetId+"']").offset().top;
            var targetDirection = targetTop > lastTargetTop ? 'down' : 'up';

            if (targetDirection == 'up') {
                $("html, body").animate({ scrollTop: (targetTop - (headerHeight + secNavHeight + 20)) }, 500);
            } else {
                $("html, body").animate({ scrollTop: targetTop - navOffset }, 500);
            }

            if (html.hasClass('desktop')) {
                $scrollLinkHoverBefore.css('border-top', '4px solid transparent');
            } else {
                $selectULOptions.css('display', 'none');
            }
                $select.removeClass('active');
            

            lastTargetTop = targetTop;
            window.location.hash = $(this).attr("href");
        });

        $selectedDropdown.on('click', function(e) {
            $selectULOptions.toggle();
            $(this).closest('.select').toggleClass('active');
        });

        $selectedDropdown.on('keydown', function(e) {
            var key = e.which;

            //Enter or Space Key
            if (key === 13 || key === 32) {
                $(this).closest('.select').toggleClass('active');
                $(this).attr('aria-pressed', true).blur().focus();
                return false;
            }
        });

        callback();
    };


    // output/public
    return {
        init: _init
    };
}(jQuery);

/* Fire off the doc ready */
jQuery(document).ready(function() {
    anchornav.init();
});
(function($) {
	'use strict';
	var Accordion = function(element) {
		var self = this;
		self.$ctx = $(element);

		// Event to show/hide the accordion's content:
		self.$ctx.find('.accordion-title').click(toggleAccordionContent);

		// Event to show/hide the accordion's content (handles the click on the interior spans):
		self.$ctx.find('.accordion-title span').click(function(event) {
			$(event.target).parent().trigger('click');
		});

		// Shows/Hides the accordion's content.
		function toggleAccordionContent(event) {
			// Accordion-title clicked:
			var accordion_title = self.$ctx.find(event.target);

			// Accordion-content:
			var accordion_content = accordion_title.next('.accordion-content');

			// Show/Hide the accordion's content:
			accordion_content.slideToggle('fast');

			// Accordion-plus-minus:
			var accordion_plus_minus = self.$ctx.find(event.target).find('.accordion-plus-minus');

			// Change the plus-minus symbol:
			if (accordion_plus_minus.html() == '\u002B' ) { // plus to minus.
				accordion_plus_minus.html('\u2212');
			}
			else if (accordion_plus_minus.html() == '\u2212' ) { // minus to plus.
				accordion_plus_minus.text('\u002B');
			}
		}
	};
	$('.accordion').each(function() {
		new Accordion(this);
	});
})(jQuery);
(function() {

    function is_touch_device() {
      return 'ontouchstart' in window;
    }
    
    $('.tooltip-btn').each(function() {

        if ($(this).hasClass('tooltip-hover')){
            var $hoverTip = $(this);
        }

        $hoverTip.on('click', function(e) {
            e.stopPropagation();
            e.preventDefault();
            $(this).toggleClass("click active");            
        });
        
        $hoverTip.hover(function(e){
           if(!is_touch_device()){
            $(this).toggleClass("hover");
           }
        });
    });
		
})(jQuery);
$(function() {
	$('.link-share').on('click', 'li a', function(e) {
		e.preventDefault();
		const platform = $(this).data('platform');

		if (platform == 'copy') {
			const tempCopy = document.createElement('input');
			document.body.appendChild(tempCopy);
			tempCopy.value = window.location.href;
			tempCopy.select();
			document.execCommand('copy');
			document.body.removeChild(tempCopy);
		} else if (platform == 'email') {
			window.location.href = 'mailto:?subject=' + document.title + ' &body=' + window.location.href;
		} else {
			var url = encodeURIComponent(window.location.href);
			switch(platform) {
				case 'linkedin':
					url = 'https://www.linkedin.com/sharing/share-offsite/?url=' + url;
					break;
				case 'twitter':
					url = 'https://twitter.com/intent/tweet?url=' + url;
					break;
				case 'facebook':
					url = 'https://www.facebook.com/sharer/sharer.php?u=' + url;
					break;
			}
			
			window.open(url, '_blank');
		}
	});
});
var imagevideo = imagevideo || {};
~ (function ($) {
    $.extend( imagevideo, {
        windowWidth: $(window).width(),
        mobileWidth: 768,
        init: function(mod) {
            var self = this,
                $mod = $(mod),
                $img = "",
                videoId = "";

            //check for video option first, then image if video doesn't exist
            $mod.each(function() {
                if($(this).find("img").length) { //image was authored
                    $img = $(this).find("img");
                    //swap assets between mobile/desktop (on page load and window resize)
                    self.swapAssets($(this), $img);
                    
                    $(window).resize(function() {
                      self.windowWidth = $(window).width();
                      self.swapAssets($(this), $img);
                    });
                } 
                if ($(this).find('.video-poster')) { //if video with custom poster
                    $(this).find('.video-poster .play').click(self.handlePlay.bind(this));
                }
            });
        },
        swapAssets: function($mod, $img) {
            var self = this,
                imgSrc = "";

            if(self.windowWidth <= self.mobileWidth) { //mobile
                imgSrc = $img.data("mobile-img");
            } else { //desktop
                imgSrc = $img.data("desktop-img");
            }
            $img.attr("src",imgSrc);
            var imgAltText = $img.data("alt-text-img");
            $img.attr("alt", imgAltText);
        },
        handlePlay: function (e) {
            var $iframe = $(this).find('iframe');
            $(this).find('.iframe-wrapper').addClass('fade-to-back');
            $(this).find('.iframe-wrapper button').attr('aria-hidden', true);
            $iframe.addClass('fade-to-front');
            $iframe.attr('src', $iframe.data('src'));
            
        }
    });

    $(document).ready(function(){imagevideo.init("div.imagevideo")});

})(jQuery);
/**
 * File: supportcountries.js
 * Author: Greg Lewis
 * Copyright: MRM//McCann 2018
 */

(function($) {
    'use strict';
    var SupportCountries = function(element) {
        this.$ctx = $(element);
        this.setup();
    };

    SupportCountries.prototype = {

        setup: function() {
            this.addEvents();
        },

        addEvents: function() {

            //close dropdowns
            $(document).on('click', function(e) {
                $(this).find('.drop-down-nav').removeClass('turn');
            });

            this.$ctx.find('button').on('click', function(e) {
                e.stopPropagation();
                $(this).parents('.drop-down-nav').toggleClass('turn');
            });
        }

    };

    $('.supportcountries .drop-down-nav').each(function() {
        new SupportCountries(this);
    });

})(jQuery);
/**
 * File: tracking.js
 * Author: Jeff Simko
 * Copyright: MRM//McCann 2018
 */

var tracking = function($) {

    var _init = function() {
        _trackRTELinks();
    };

    var _trackRTELinks = function() {

        //Find all text links in titletext (RTE) component and add class and closest data-loc
        $('.titletext a').each(function(index, link) {
            var dataLoc = $(link).closest('[data-loc]').data('loc');
            $(link).addClass('vz-text-link');

            if (dataLoc) {
                $(link).attr('data-loc', dataLoc)
            }
        });
    }

    // output/public
    return {
        init: _init
    };

}(jQuery);

/* Fire off the doc ready */
jQuery(document).ready(function() {
    tracking.init();
});
(function($) {
    'use strict';
    var Stats = function(element) {
        this.$ctx = $(element);
        this.init();
    };

    Stats.prototype = {

        init: function() {
            var $output = this.$ctx.find('.stats-number');
            var statStart = 0;
            var statEnd = parseInt(this.$ctx.find('.stats-number').text());
            var isUp = statEnd > statStart;

            if (isUp) {
                $output.css('width', $output.outerWidth());
                $output.text(statStart);

                this.$ctx.waypoint({
                    handler: function(direction) {
                        $({ Counter: statStart }).animate({ Counter: statEnd }, {
                            duration: 1500,
                            easing: 'swing',
                            step: function() {
                                $output.text(Math.ceil(this.Counter));
                            }
                        });

                        this.destroy();
                    },
                    offset: '80%'
                });
            }
        },
    };

    // New instance of component for every appearance on the page
    $('.stats .stats-animate').each(function() {
        new Stats(this);
    });
})(jQuery);
(function ($) {
    'use strict';
    var NavLinkList = function (element) {
        var self = this;
        self.$ctx = $(element);
        var winWidth = $(window).width();
        var timer = null;

        // Event to show/hide the accordion's content:
        self.$ctx.find('.accordion-title').click(toggleMobileAccordionContent);

        $(window).on("resize", function () {
            clearTimeout(timer);
            timer = setTimeout(function () {
                winWidth = $(window).width();
                var listWrapper = self.$ctx.find('.linklist-wrapper');
                if (winWidth >= 768) {                    
                    if (listWrapper.css('display') === 'none') {
                        listWrapper.css('display', 'block');
                    }
                } else {
                    listWrapper.css('display', 'none');
                    if (self.$ctx.find('.accordion-title').find('.toggle').html() == '\u2212') { // minnus to plus
                        toggleIcon();
                    }                    
                }
            }, 150);
        });

        $(window).trigger('resize');

        // Shows/Hides the accordion's content.
        function toggleMobileAccordionContent() {
            if (winWidth < 768) {

                var accordion_content = self.$ctx.find('.linklist-wrapper');

                // Show/Hide the accordion's content:
                accordion_content.slideToggle('fast');

                // Accordion-plus-minus:
                toggleIcon();
            }
        }

        function toggleIcon() {
            var accordion_toggle = self.$ctx.find('.accordion-title').find('.toggle');

            if (accordion_toggle.html() == '\u002B') { // plus to minus.
                accordion_toggle.html('\u2212');
            } else if (accordion_toggle.html() == '\u2212') { // minus to plus.
                accordion_toggle.text('\u002B');
            }
        }
    };
    $('.nav-linklist').each(function () {
        new NavLinkList(this);
    });
})(jQuery);
(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.ejs = f()}})(function(){var define,module,exports;return (function(){function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s}return e})()({1:[function(require,module,exports){
    /*
     * EJS Embedded JavaScript templates
     * Copyright 2112 Matthew Eernisse (mde@fleegix.org)
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *         http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     *
    */
    
    'use strict';
    
    /**
     * @file Embedded JavaScript templating engine. {@link http://ejs.co}
     * @author Matthew Eernisse <mde@fleegix.org>
     * @author Tiancheng "Timothy" Gu <timothygu99@gmail.com>
     * @project EJS
     * @license {@link http://www.apache.org/licenses/LICENSE-2.0 Apache License, Version 2.0}
     */
    
    /**
     * EJS internal functions.
     *
     * Technically this "module" lies in the same file as {@link module:ejs}, for
     * the sake of organization all the private functions re grouped into this
     * module.
     *
     * @module ejs-internal
     * @private
     */
    
    /**
     * Embedded JavaScript templating engine.
     *
     * @module ejs
     * @public
     */
    
    var fs = require('fs');
    var path = require('path');
    var utils = require('./utils');
    
    var scopeOptionWarned = false;
    var _VERSION_STRING = require('../package.json').version;
    var _DEFAULT_DELIMITER = '%';
    var _DEFAULT_LOCALS_NAME = 'locals';
    var _NAME = 'ejs';
    var _REGEX_STRING = '(<%%|%%>|<%=|<%-|<%_|<%#|<%|%>|-%>|_%>)';
    var _OPTS = ['delimiter', 'scope', 'context', 'debug', 'compileDebug',
      'client', '_with', 'rmWhitespace', 'strict', 'filename'];
    // We don't allow 'cache' option to be passed in the data obj
    // for the normal `render` call, but this is where Express puts it
    // so we make an exception for `renderFile`
    var _OPTS_EXPRESS = _OPTS.concat('cache');
    var _BOM = /^\uFEFF/;
    
    /**
     * EJS template function cache. This can be a LRU object from lru-cache NPM
     * module. By default, it is {@link module:utils.cache}, a simple in-process
     * cache that grows continuously.
     *
     * @type {Cache}
     */
    
    exports.cache = utils.cache;
    
    /**
     * Custom file loader. Useful for template preprocessing or restricting access
     * to a certain part of the filesystem.
     *
     * @type {fileLoader}
     */
    
    exports.fileLoader = fs.readFileSync;
    
    /**
     * Name of the object containing the locals.
     *
     * This variable is overridden by {@link Options}`.localsName` if it is not
     * `undefined`.
     *
     * @type {String}
     * @public
     */
    
    exports.localsName = _DEFAULT_LOCALS_NAME;
    
    /**
     * Promise implementation -- defaults to the native implementation if available
     * This is mostly just for testability
     *
     * @type {Function}
     * @public
     */
    
    exports.promiseImpl = (new Function('return this;'))().Promise;
    
    /**
     * Get the path to the included file from the parent file path and the
     * specified path.
     *
     * @param {String}  name     specified path
     * @param {String}  filename parent file path
     * @param {Boolean} isDir    parent file path whether is directory
     * @return {String}
     */
    exports.resolveInclude = function(name, filename, isDir) {
      var dirname = path.dirname;
      var extname = path.extname;
      var resolve = path.resolve;
      var includePath = resolve(isDir ? filename : dirname(filename), name);
      var ext = extname(name);
      if (!ext) {
        includePath += '.ejs';
      }
      return includePath;
    };
    
    /**
     * Get the path to the included file by Options
     *
     * @param  {String}  path    specified path
     * @param  {Options} options compilation options
     * @return {String}
     */
    function getIncludePath(path, options) {
      var includePath;
      var filePath;
      var views = options.views;
    
      // Abs path
      if (path.charAt(0) == '/') {
        includePath = exports.resolveInclude(path.replace(/^\/*/,''), options.root || '/', true);
      }
      // Relative paths
      else {
        // Look relative to a passed filename first
        if (options.filename) {
          filePath = exports.resolveInclude(path, options.filename);
          if (fs.existsSync(filePath)) {
            includePath = filePath;
          }
        }
        // Then look in any views directories
        if (!includePath) {
          if (Array.isArray(views) && views.some(function (v) {
            filePath = exports.resolveInclude(path, v, true);
            return fs.existsSync(filePath);
          })) {
            includePath = filePath;
          }
        }
        if (!includePath) {
          throw new Error('Could not find the include file "' +
              options.escapeFunction(path) + '"');
        }
      }
      return includePath;
    }
    
    /**
     * Get the template from a string or a file, either compiled on-the-fly or
     * read from cache (if enabled), and cache the template if needed.
     *
     * If `template` is not set, the file specified in `options.filename` will be
     * read.
     *
     * If `options.cache` is true, this function reads the file from
     * `options.filename` so it must be set prior to calling this function.
     *
     * @memberof module:ejs-internal
     * @param {Options} options   compilation options
     * @param {String} [template] template source
     * @return {(TemplateFunction|ClientFunction)}
     * Depending on the value of `options.client`, either type might be returned.
     * @static
     */
    
    function handleCache(options, template) {
      var func;
      var filename = options.filename;
      var hasTemplate = arguments.length > 1;
    
      if (options.cache) {
        if (!filename) {
          throw new Error('cache option requires a filename');
        }
        func = exports.cache.get(filename);
        if (func) {
          return func;
        }
        if (!hasTemplate) {
          template = fileLoader(filename).toString().replace(_BOM, '');
        }
      }
      else if (!hasTemplate) {
        // istanbul ignore if: should not happen at all
        if (!filename) {
          throw new Error('Internal EJS error: no file name or template '
                        + 'provided');
        }
        template = fileLoader(filename).toString().replace(_BOM, '');
      }
      func = exports.compile(template, options);
      if (options.cache) {
        exports.cache.set(filename, func);
      }
      return func;
    }
    
    /**
     * Try calling handleCache with the given options and data and call the
     * callback with the result. If an error occurs, call the callback with
     * the error. Used by renderFile().
     *
     * @memberof module:ejs-internal
     * @param {Options} options    compilation options
     * @param {Object} data        template data
     * @param {RenderFileCallback} cb callback
     * @static
     */
    
    function tryHandleCache(options, data, cb) {
      var result;
      if (!cb) {
        if (typeof exports.promiseImpl == 'function') {
          return new exports.promiseImpl(function (resolve, reject) {
            try {
              result = handleCache(options)(data);
              resolve(result);
            }
            catch (err) {
              reject(err);
            }
          });
        }
        else {
          throw new Error('Please provide a callback function');
        }
      }
      else {
        try {
          result = handleCache(options)(data);
        }
        catch (err) {
          return cb(err);
        }
    
        cb(null, result);
      }
    }
    
    /**
     * fileLoader is independent
     *
     * @param {String} filePath ejs file path.
     * @return {String} The contents of the specified file.
     * @static
     */
    
    function fileLoader(filePath){
      return exports.fileLoader(filePath);
    }
    
    /**
     * Get the template function.
     *
     * If `options.cache` is `true`, then the template is cached.
     *
     * @memberof module:ejs-internal
     * @param {String}  path    path for the specified file
     * @param {Options} options compilation options
     * @return {(TemplateFunction|ClientFunction)}
     * Depending on the value of `options.client`, either type might be returned
     * @static
     */
    
    function includeFile(path, options) {
      var opts = utils.shallowCopy({}, options);
      opts.filename = getIncludePath(path, opts);
      return handleCache(opts);
    }
    
    /**
     * Get the JavaScript source of an included file.
     *
     * @memberof module:ejs-internal
     * @param {String}  path    path for the specified file
     * @param {Options} options compilation options
     * @return {Object}
     * @static
     */
    
    function includeSource(path, options) {
      var opts = utils.shallowCopy({}, options);
      var includePath;
      var template;
      includePath = getIncludePath(path, opts);
      template = fileLoader(includePath).toString().replace(_BOM, '');
      opts.filename = includePath;
      var templ = new Template(template, opts);
      templ.generateSource();
      return {
        source: templ.source,
        filename: includePath,
        template: template
      };
    }
    
    /**
     * Re-throw the given `err` in context to the `str` of ejs, `filename`, and
     * `lineno`.
     *
     * @implements RethrowCallback
     * @memberof module:ejs-internal
     * @param {Error}  err      Error object
     * @param {String} str      EJS source
     * @param {String} filename file name of the EJS file
     * @param {String} lineno   line number of the error
     * @static
     */
    
    function rethrow(err, str, flnm, lineno, esc){
      var lines = str.split('\n');
      var start = Math.max(lineno - 3, 0);
      var end = Math.min(lines.length, lineno + 3);
      var filename = esc(flnm); // eslint-disable-line
      // Error context
      var context = lines.slice(start, end).map(function (line, i){
        var curr = i + start + 1;
        return (curr == lineno ? ' >> ' : '    ')
          + curr
          + '| '
          + line;
      }).join('\n');
    
      // Alter exception message
      err.path = filename;
      err.message = (filename || 'ejs') + ':'
        + lineno + '\n'
        + context + '\n\n'
        + err.message;
    
      throw err;
    }
    
    function stripSemi(str){
      return str.replace(/;(\s*$)/, '$1');
    }
    
    /**
     * Compile the given `str` of ejs into a template function.
     *
     * @param {String}  template EJS template
     *
     * @param {Options} opts     compilation options
     *
     * @return {(TemplateFunction|ClientFunction)}
     * Depending on the value of `opts.client`, either type might be returned.
     * @public
     */
    
    exports.compile = function compile(template, opts) {
      var templ;
    
      // v1 compat
      // 'scope' is 'context'
      // FIXME: Remove this in a future version
      if (opts && opts.scope) {
        if (!scopeOptionWarned){
          console.warn('`scope` option is deprecated and will be removed in EJS 3');
          scopeOptionWarned = true;
        }
        if (!opts.context) {
          opts.context = opts.scope;
        }
        delete opts.scope;
      }
      templ = new Template(template, opts);
      return templ.compile();
    };
    
    /**
     * Render the given `template` of ejs.
     *
     * If you would like to include options but not data, you need to explicitly
     * call this function with `data` being an empty object or `null`.
     *
     * @param {String}   template EJS template
     * @param {Object}  [data={}] template data
     * @param {Options} [opts={}] compilation and rendering options
     * @return {String}
     * @public
     */
    
    exports.render = function (template, d, o) {
      var data = d || {};
      var opts = o || {};
    
      // No options object -- if there are optiony names
      // in the data, copy them to options
      if (arguments.length == 2) {
        utils.shallowCopyFromList(opts, data, _OPTS);
      }
    
      return handleCache(opts, template)(data);
    };
    
    /**
     * Render an EJS file at the given `path` and callback `cb(err, str)`.
     *
     * If you would like to include options but not data, you need to explicitly
     * call this function with `data` being an empty object or `null`.
     *
     * @param {String}             path     path to the EJS file
     * @param {Object}            [data={}] template data
     * @param {Options}           [opts={}] compilation and rendering options
     * @param {RenderFileCallback} cb callback
     * @public
     */
    
    exports.renderFile = function () {
      var args = Array.prototype.slice.call(arguments);
      var filename = args.shift();
      var cb;
      var opts = {filename: filename};
      var data;
    
      // Do we have a callback?
      if (typeof arguments[arguments.length - 1] == 'function') {
        cb = args.pop();
      }
      // Do we have data/opts?
      if (args.length) {
        // Should always have data obj
        data = args.shift();
        // Normal passed opts (data obj + opts obj)
        if (args.length) {
          // Use shallowCopy so we don't pollute passed in opts obj with new vals
          utils.shallowCopy(opts, args.pop());
        }
        // Special casing for Express (opts-in-data)
        else {
          // Express 4
          if (data.settings) {
            if (data.settings.views) {
              opts.views = data.settings.views;
            }
            if (data.settings['view cache']) {
              opts.cache = true;
            }
          }
          // Express 3 and lower
          else {
            utils.shallowCopyFromList(opts, data, _OPTS_EXPRESS);
          }
        }
        opts.filename = filename;
      }
      else {
        data = {};
      }
    
      return tryHandleCache(opts, data, cb);
    };
    
    /**
     * Clear intermediate JavaScript cache. Calls {@link Cache#reset}.
     * @public
     */
    
    exports.clearCache = function () {
      exports.cache.reset();
    };
    
    function Template(text, opts) {
      opts = opts || {};
      var options = {};
      this.templateText = text;
      this.mode = null;
      this.truncate = false;
      this.currentLine = 1;
      this.source = '';
      this.dependencies = [];
      options.client = opts.client || false;
      options.escapeFunction = opts.escape || utils.escapeXML;
      options.compileDebug = opts.compileDebug !== false;
      options.debug = !!opts.debug;
      options.filename = opts.filename;
      options.delimiter = opts.delimiter || exports.delimiter || _DEFAULT_DELIMITER;
      options.strict = opts.strict || false;
      options.context = opts.context;
      options.cache = opts.cache || false;
      options.rmWhitespace = opts.rmWhitespace;
      options.root = opts.root;
      options.localsName = opts.localsName || exports.localsName || _DEFAULT_LOCALS_NAME;
      options.views = opts.views;
    
      if (options.strict) {
        options._with = false;
      }
      else {
        options._with = typeof opts._with != 'undefined' ? opts._with : true;
      }
    
      this.opts = options;
    
      this.regex = this.createRegex();
    }
    
    Template.modes = {
      EVAL: 'eval',
      ESCAPED: 'escaped',
      RAW: 'raw',
      COMMENT: 'comment',
      LITERAL: 'literal'
    };
    
    Template.prototype = {
      createRegex: function () {
        var str = _REGEX_STRING;
        var delim = utils.escapeRegExpChars(this.opts.delimiter);
        str = str.replace(/%/g, delim);
        return new RegExp(str);
      },
    
      compile: function () {
        var src;
        var fn;
        var opts = this.opts;
        var prepended = '';
        var appended = '';
        var escapeFn = opts.escapeFunction;
    
        if (!this.source) {
          this.generateSource();
          prepended += '  var __output = [], __append = __output.push.bind(__output);' + '\n';
          if (opts._with !== false) {
            prepended +=  '  with (' + opts.localsName + ' || {}) {' + '\n';
            appended += '  }' + '\n';
          }
          appended += '  return __output.join("");' + '\n';
          this.source = prepended + this.source + appended;
        }
    
        if (opts.compileDebug) {
          src = 'var __line = 1' + '\n'
            + '  , __lines = ' + JSON.stringify(this.templateText) + '\n'
            + '  , __filename = ' + (opts.filename ?
            JSON.stringify(opts.filename) : 'undefined') + ';' + '\n'
            + 'try {' + '\n'
            + this.source
            + '} catch (e) {' + '\n'
            + '  rethrow(e, __lines, __filename, __line, escapeFn);' + '\n'
            + '}' + '\n';
        }
        else {
          src = this.source;
        }
    
        if (opts.client) {
          src = 'escapeFn = escapeFn || ' + escapeFn.toString() + ';' + '\n' + src;
          if (opts.compileDebug) {
            src = 'rethrow = rethrow || ' + rethrow.toString() + ';' + '\n' + src;
          }
        }
    
        if (opts.strict) {
          src = '"use strict";\n' + src;
        }
        if (opts.debug) {
          console.log(src);
        }
    
        try {
          fn = new Function(opts.localsName + ', escapeFn, include, rethrow', src);
        }
        catch(e) {
          // istanbul ignore else
          if (e instanceof SyntaxError) {
            if (opts.filename) {
              e.message += ' in ' + opts.filename;
            }
            e.message += ' while compiling ejs\n\n';
            e.message += 'If the above error is not helpful, you may want to try EJS-Lint:\n';
            e.message += 'https://github.com/RyanZim/EJS-Lint';
          }
          throw e;
        }
    
        if (opts.client) {
          fn.dependencies = this.dependencies;
          return fn;
        }
    
        // Return a callable function which will execute the function
        // created by the source-code, with the passed data as locals
        // Adds a local `include` function which allows full recursive include
        var returnedFn = function (data) {
          var include = function (path, includeData) {
            var d = utils.shallowCopy({}, data);
            if (includeData) {
              d = utils.shallowCopy(d, includeData);
            }
            return includeFile(path, opts)(d);
          };
          return fn.apply(opts.context, [data || {}, escapeFn, include, rethrow]);
        };
        returnedFn.dependencies = this.dependencies;
        return returnedFn;
      },
    
      generateSource: function () {
        var opts = this.opts;
    
        if (opts.rmWhitespace) {
          // Have to use two separate replace here as `^` and `$` operators don't
          // work well with `\r`.
          this.templateText =
            this.templateText.replace(/\r/g, '').replace(/^\s+|\s+$/gm, '');
        }
    
        // Slurp spaces and tabs before <%_ and after _%>
        this.templateText =
          this.templateText.replace(/[ \t]*<%_/gm, '<%_').replace(/_%>[ \t]*/gm, '_%>');
    
        var self = this;
        var matches = this.parseTemplateText();
        var d = this.opts.delimiter;
    
        if (matches && matches.length) {
          matches.forEach(function (line, index) {
            var opening;
            var closing;
            var include;
            var includeOpts;
            var includeObj;
            var includeSrc;
            // If this is an opening tag, check for closing tags
            // FIXME: May end up with some false positives here
            // Better to store modes as k/v with '<' + delimiter as key
            // Then this can simply check against the map
            if ( line.indexOf('<' + d) === 0        // If it is a tag
              && line.indexOf('<' + d + d) !== 0) { // and is not escaped
              closing = matches[index + 2];
              if (!(closing == d + '>' || closing == '-' + d + '>' || closing == '_' + d + '>')) {
                throw new Error('Could not find matching close tag for "' + line + '".');
              }
            }
            // HACK: backward-compat `include` preprocessor directives
            if ((include = line.match(/^\s*include\s+(\S+)/))) {
              opening = matches[index - 1];
              // Must be in EVAL or RAW mode
              if (opening && (opening == '<' + d || opening == '<' + d + '-' || opening == '<' + d + '_')) {
                includeOpts = utils.shallowCopy({}, self.opts);
                includeObj = includeSource(include[1], includeOpts);
                if (self.opts.compileDebug) {
                  includeSrc =
                      '    ; (function(){' + '\n'
                      + '      var __line = 1' + '\n'
                      + '      , __lines = ' + JSON.stringify(includeObj.template) + '\n'
                      + '      , __filename = ' + JSON.stringify(includeObj.filename) + ';' + '\n'
                      + '      try {' + '\n'
                      + includeObj.source
                      + '      } catch (e) {' + '\n'
                      + '        rethrow(e, __lines, __filename, __line, escapeFn);' + '\n'
                      + '      }' + '\n'
                      + '    ; }).call(this)' + '\n';
                }else{
                  includeSrc = '    ; (function(){' + '\n' + includeObj.source +
                      '    ; }).call(this)' + '\n';
                }
                self.source += includeSrc;
                self.dependencies.push(exports.resolveInclude(include[1],
                  includeOpts.filename));
                return;
              }
            }
            self.scanLine(line);
          });
        }
    
      },
    
      parseTemplateText: function () {
        var str = this.templateText;
        var pat = this.regex;
        var result = pat.exec(str);
        var arr = [];
        var firstPos;
    
        while (result) {
          firstPos = result.index;
    
          if (firstPos !== 0) {
            arr.push(str.substring(0, firstPos));
            str = str.slice(firstPos);
          }
    
          arr.push(result[0]);
          str = str.slice(result[0].length);
          result = pat.exec(str);
        }
    
        if (str) {
          arr.push(str);
        }
    
        return arr;
      },
    
      _addOutput: function (line) {
        if (this.truncate) {
          // Only replace single leading linebreak in the line after
          // -%> tag -- this is the single, trailing linebreak
          // after the tag that the truncation mode replaces
          // Handle Win / Unix / old Mac linebreaks -- do the \r\n
          // combo first in the regex-or
          line = line.replace(/^(?:\r\n|\r|\n)/, '');
          this.truncate = false;
        }
        else if (this.opts.rmWhitespace) {
          // rmWhitespace has already removed trailing spaces, just need
          // to remove linebreaks
          line = line.replace(/^\n/, '');
        }
        if (!line) {
          return line;
        }
    
        // Preserve literal slashes
        line = line.replace(/\\/g, '\\\\');
    
        // Convert linebreaks
        line = line.replace(/\n/g, '\\n');
        line = line.replace(/\r/g, '\\r');
    
        // Escape double-quotes
        // - this will be the delimiter during execution
        line = line.replace(/"/g, '\\"');
        this.source += '    ; __append("' + line + '")' + '\n';
      },
    
      scanLine: function (line) {
        var self = this;
        var d = this.opts.delimiter;
        var newLineCount = 0;
    
        newLineCount = (line.split('\n').length - 1);
    
        switch (line) {
        case '<' + d:
        case '<' + d + '_':
          this.mode = Template.modes.EVAL;
          break;
        case '<' + d + '=':
          this.mode = Template.modes.ESCAPED;
          break;
        case '<' + d + '-':
          this.mode = Template.modes.RAW;
          break;
        case '<' + d + '#':
          this.mode = Template.modes.COMMENT;
          break;
        case '<' + d + d:
          this.mode = Template.modes.LITERAL;
          this.source += '    ; __append("' + line.replace('<' + d + d, '<' + d) + '")' + '\n';
          break;
        case d + d + '>':
          this.mode = Template.modes.LITERAL;
          this.source += '    ; __append("' + line.replace(d + d + '>', d + '>') + '")' + '\n';
          break;
        case d + '>':
        case '-' + d + '>':
        case '_' + d + '>':
          if (this.mode == Template.modes.LITERAL) {
            this._addOutput(line);
          }
    
          this.mode = null;
          this.truncate = line.indexOf('-') === 0 || line.indexOf('_') === 0;
          break;
        default:
          // In script mode, depends on type of tag
          if (this.mode) {
            // If '//' is found without a line break, add a line break.
            switch (this.mode) {
            case Template.modes.EVAL:
            case Template.modes.ESCAPED:
            case Template.modes.RAW:
              if (line.lastIndexOf('//') > line.lastIndexOf('\n')) {
                line += '\n';
              }
            }
            switch (this.mode) {
            // Just executing code
            case Template.modes.EVAL:
              this.source += '    ; ' + line + '\n';
              break;
              // Exec, esc, and output
            case Template.modes.ESCAPED:
              this.source += '    ; __append(escapeFn(' + stripSemi(line) + '))' + '\n';
              break;
              // Exec and output
            case Template.modes.RAW:
              this.source += '    ; __append(' + stripSemi(line) + ')' + '\n';
              break;
            case Template.modes.COMMENT:
              // Do nothing
              break;
              // Literal <%% mode, append as raw output
            case Template.modes.LITERAL:
              this._addOutput(line);
              break;
            }
          }
          // In string mode, just add the output
          else {
            this._addOutput(line);
          }
        }
    
        if (self.opts.compileDebug && newLineCount) {
          this.currentLine += newLineCount;
          this.source += '    ; __line = ' + this.currentLine + '\n';
        }
      }
    };
    
    /**
     * Escape characters reserved in XML.
     *
     * This is simply an export of {@link module:utils.escapeXML}.
     *
     * If `markup` is `undefined` or `null`, the empty string is returned.
     *
     * @param {String} markup Input string
     * @return {String} Escaped string
     * @public
     * @func
     * */
    exports.escapeXML = utils.escapeXML;
    
    /**
     * Express.js support.
     *
     * This is an alias for {@link module:ejs.renderFile}, in order to support
     * Express.js out-of-the-box.
     *
     * @func
     */
    
    exports.__express = exports.renderFile;
    
    // Add require support
    /* istanbul ignore else */
    if (require.extensions) {
      require.extensions['.ejs'] = function (module, flnm) {
        var filename = flnm || /* istanbul ignore next */ module.filename;
        var options = {
          filename: filename,
          client: true
        };
        var template = fileLoader(filename).toString();
        var fn = exports.compile(template, options);
        module._compile('module.exports = ' + fn.toString() + ';', filename);
      };
    }
    
    /**
     * Version of EJS.
     *
     * @readonly
     * @type {String}
     * @public
     */
    
    exports.VERSION = _VERSION_STRING;
    
    /**
     * Name for detection of EJS.
     *
     * @readonly
     * @type {String}
     * @public
     */
    
    exports.name = _NAME;
    
    /* istanbul ignore if */
    if (typeof window != 'undefined') {
      window.ejs = exports;
    }
    
    },{"../package.json":6,"./utils":2,"fs":3,"path":4}],2:[function(require,module,exports){
    /*
     * EJS Embedded JavaScript templates
     * Copyright 2112 Matthew Eernisse (mde@fleegix.org)
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *         http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     *
    */
    
    /**
     * Private utility functions
     * @module utils
     * @private
     */
    
    'use strict';
    
    var regExpChars = /[|\\{}()[\]^$+*?.]/g;
    
    /**
     * Escape characters reserved in regular expressions.
     *
     * If `string` is `undefined` or `null`, the empty string is returned.
     *
     * @param {String} string Input string
     * @return {String} Escaped string
     * @static
     * @private
     */
    exports.escapeRegExpChars = function (string) {
      // istanbul ignore if
      if (!string) {
        return '';
      }
      return String(string).replace(regExpChars, '\\$&');
    };
    
    var _ENCODE_HTML_RULES = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&#34;',
      "'": '&#39;'
    };
    var _MATCH_HTML = /[&<>'"]/g;
    
    function encode_char(c) {
      return _ENCODE_HTML_RULES[c] || c;
    }
    
    /**
     * Stringified version of constants used by {@link module:utils.escapeXML}.
     *
     * It is used in the process of generating {@link ClientFunction}s.
     *
     * @readonly
     * @type {String}
     */
    
    var escapeFuncStr =
      'var _ENCODE_HTML_RULES = {\n'
    + '      "&": "&amp;"\n'
    + '    , "<": "&lt;"\n'
    + '    , ">": "&gt;"\n'
    + '    , \'"\': "&#34;"\n'
    + '    , "\'": "&#39;"\n'
    + '    }\n'
    + '  , _MATCH_HTML = /[&<>\'"]/g;\n'
    + 'function encode_char(c) {\n'
    + '  return _ENCODE_HTML_RULES[c] || c;\n'
    + '};\n';
    
    /**
     * Escape characters reserved in XML.
     *
     * If `markup` is `undefined` or `null`, the empty string is returned.
     *
     * @implements {EscapeCallback}
     * @param {String} markup Input string
     * @return {String} Escaped string
     * @static
     * @private
     */
    
    exports.escapeXML = function (markup) {
      return markup == undefined
        ? ''
        : String(markup)
          .replace(_MATCH_HTML, encode_char);
    };
    exports.escapeXML.toString = function () {
      return Function.prototype.toString.call(this) + ';\n' + escapeFuncStr;
    };
    
    /**
     * Naive copy of properties from one object to another.
     * Does not recurse into non-scalar properties
     * Does not check to see if the property has a value before copying
     *
     * @param  {Object} to   Destination object
     * @param  {Object} from Source object
     * @return {Object}      Destination object
     * @static
     * @private
     */
    exports.shallowCopy = function (to, from) {
      from = from || {};
      for (var p in from) {
        to[p] = from[p];
      }
      return to;
    };
    
    /**
     * Naive copy of a list of key names, from one object to another.
     * Only copies property if it is actually defined
     * Does not recurse into non-scalar properties
     *
     * @param  {Object} to   Destination object
     * @param  {Object} from Source object
     * @param  {Array} list List of properties to copy
     * @return {Object}      Destination object
     * @static
     * @private
     */
    exports.shallowCopyFromList = function (to, from, list) {
      for (var i = 0; i < list.length; i++) {
        var p = list[i];
        if (typeof from[p] != 'undefined') {
          to[p] = from[p];
        }
      }
      return to;
    };
    
    /**
     * Simple in-process cache implementation. Does not implement limits of any
     * sort.
     *
     * @implements Cache
     * @static
     * @private
     */
    exports.cache = {
      _data: {},
      set: function (key, val) {
        this._data[key] = val;
      },
      get: function (key) {
        return this._data[key];
      },
      reset: function () {
        this._data = {};
      }
    };
    
    },{}],3:[function(require,module,exports){
    
    },{}],4:[function(require,module,exports){
    (function (process){
    // Copyright Joyent, Inc. and other Node contributors.
    //
    // Permission is hereby granted, free of charge, to any person obtaining a
    // copy of this software and associated documentation files (the
    // "Software"), to deal in the Software without restriction, including
    // without limitation the rights to use, copy, modify, merge, publish,
    // distribute, sublicense, and/or sell copies of the Software, and to permit
    // persons to whom the Software is furnished to do so, subject to the
    // following conditions:
    //
    // The above copyright notice and this permission notice shall be included
    // in all copies or substantial portions of the Software.
    //
    // THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
    // OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
    // MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
    // NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
    // DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
    // OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
    // USE OR OTHER DEALINGS IN THE SOFTWARE.
    
    // resolves . and .. elements in a path array with directory names there
    // must be no slashes, empty elements, or device names (c:\) in the array
    // (so also no leading and trailing slashes - it does not distinguish
    // relative and absolute paths)
    function normalizeArray(parts, allowAboveRoot) {
      // if the path tries to go above the root, `up` ends up > 0
      var up = 0;
      for (var i = parts.length - 1; i >= 0; i--) {
        var last = parts[i];
        if (last === '.') {
          parts.splice(i, 1);
        } else if (last === '..') {
          parts.splice(i, 1);
          up++;
        } else if (up) {
          parts.splice(i, 1);
          up--;
        }
      }
    
      // if the path is allowed to go above the root, restore leading ..s
      if (allowAboveRoot) {
        for (; up--; up) {
          parts.unshift('..');
        }
      }
    
      return parts;
    }
    
    // Split a filename into [root, dir, basename, ext], unix version
    // 'root' is just a slash, or nothing.
    var splitPathRe =
        /^(\/?|)([\s\S]*?)((?:\.{1,2}|[^\/]+?|)(\.[^.\/]*|))(?:[\/]*)$/;
    var splitPath = function(filename) {
      return splitPathRe.exec(filename).slice(1);
    };
    
    // path.resolve([from ...], to)
    // posix version
    exports.resolve = function() {
      var resolvedPath = '',
          resolvedAbsolute = false;
    
      for (var i = arguments.length - 1; i >= -1 && !resolvedAbsolute; i--) {
        var path = (i >= 0) ? arguments[i] : process.cwd();
    
        // Skip empty and invalid entries
        if (typeof path !== 'string') {
          throw new TypeError('Arguments to path.resolve must be strings');
        } else if (!path) {
          continue;
        }
    
        resolvedPath = path + '/' + resolvedPath;
        resolvedAbsolute = path.charAt(0) === '/';
      }
    
      // At this point the path should be resolved to a full absolute path, but
      // handle relative paths to be safe (might happen when process.cwd() fails)
    
      // Normalize the path
      resolvedPath = normalizeArray(filter(resolvedPath.split('/'), function(p) {
        return !!p;
      }), !resolvedAbsolute).join('/');
    
      return ((resolvedAbsolute ? '/' : '') + resolvedPath) || '.';
    };
    
    // path.normalize(path)
    // posix version
    exports.normalize = function(path) {
      var isAbsolute = exports.isAbsolute(path),
          trailingSlash = substr(path, -1) === '/';
    
      // Normalize the path
      path = normalizeArray(filter(path.split('/'), function(p) {
        return !!p;
      }), !isAbsolute).join('/');
    
      if (!path && !isAbsolute) {
        path = '.';
      }
      if (path && trailingSlash) {
        path += '/';
      }
    
      return (isAbsolute ? '/' : '') + path;
    };
    
    // posix version
    exports.isAbsolute = function(path) {
      return path.charAt(0) === '/';
    };
    
    // posix version
    exports.join = function() {
      var paths = Array.prototype.slice.call(arguments, 0);
      return exports.normalize(filter(paths, function(p, index) {
        if (typeof p !== 'string') {
          throw new TypeError('Arguments to path.join must be strings');
        }
        return p;
      }).join('/'));
    };
    
    
    // path.relative(from, to)
    // posix version
    exports.relative = function(from, to) {
      from = exports.resolve(from).substr(1);
      to = exports.resolve(to).substr(1);
    
      function trim(arr) {
        var start = 0;
        for (; start < arr.length; start++) {
          if (arr[start] !== '') break;
        }
    
        var end = arr.length - 1;
        for (; end >= 0; end--) {
          if (arr[end] !== '') break;
        }
    
        if (start > end) return [];
        return arr.slice(start, end - start + 1);
      }
    
      var fromParts = trim(from.split('/'));
      var toParts = trim(to.split('/'));
    
      var length = Math.min(fromParts.length, toParts.length);
      var samePartsLength = length;
      for (var i = 0; i < length; i++) {
        if (fromParts[i] !== toParts[i]) {
          samePartsLength = i;
          break;
        }
      }
    
      var outputParts = [];
      for (var i = samePartsLength; i < fromParts.length; i++) {
        outputParts.push('..');
      }
    
      outputParts = outputParts.concat(toParts.slice(samePartsLength));
    
      return outputParts.join('/');
    };
    
    exports.sep = '/';
    exports.delimiter = ':';
    
    exports.dirname = function(path) {
      var result = splitPath(path),
          root = result[0],
          dir = result[1];
    
      if (!root && !dir) {
        // No dirname whatsoever
        return '.';
      }
    
      if (dir) {
        // It has a dirname, strip trailing slash
        dir = dir.substr(0, dir.length - 1);
      }
    
      return root + dir;
    };
    
    
    exports.basename = function(path, ext) {
      var f = splitPath(path)[2];
      // TODO: make this comparison case-insensitive on windows?
      if (ext && f.substr(-1 * ext.length) === ext) {
        f = f.substr(0, f.length - ext.length);
      }
      return f;
    };
    
    
    exports.extname = function(path) {
      return splitPath(path)[3];
    };
    
    function filter (xs, f) {
        if (xs.filter) return xs.filter(f);
        var res = [];
        for (var i = 0; i < xs.length; i++) {
            if (f(xs[i], i, xs)) res.push(xs[i]);
        }
        return res;
    }
    
    // String.prototype.substr - negative index don't work in IE8
    var substr = 'ab'.substr(-1) === 'b'
        ? function (str, start, len) { return str.substr(start, len) }
        : function (str, start, len) {
            if (start < 0) start = str.length + start;
            return str.substr(start, len);
        }
    ;
    
    }).call(this,require('_process'))
    },{"_process":5}],5:[function(require,module,exports){
    // shim for using process in browser
    var process = module.exports = {};
    
    // cached from whatever global is present so that test runners that stub it
    // don't break things.  But we need to wrap it in a try catch in case it is
    // wrapped in strict mode code which doesn't define any globals.  It's inside a
    // function because try/catches deoptimize in certain engines.
    
    var cachedSetTimeout;
    var cachedClearTimeout;
    
    function defaultSetTimout() {
        throw new Error('setTimeout has not been defined');
    }
    function defaultClearTimeout () {
        throw new Error('clearTimeout has not been defined');
    }
    (function () {
        try {
            if (typeof setTimeout === 'function') {
                cachedSetTimeout = setTimeout;
            } else {
                cachedSetTimeout = defaultSetTimout;
            }
        } catch (e) {
            cachedSetTimeout = defaultSetTimout;
        }
        try {
            if (typeof clearTimeout === 'function') {
                cachedClearTimeout = clearTimeout;
            } else {
                cachedClearTimeout = defaultClearTimeout;
            }
        } catch (e) {
            cachedClearTimeout = defaultClearTimeout;
        }
    } ())
    function runTimeout(fun) {
        if (cachedSetTimeout === setTimeout) {
            //normal enviroments in sane situations
            return setTimeout(fun, 0);
        }
        // if setTimeout wasn't available but was latter defined
        if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
            cachedSetTimeout = setTimeout;
            return setTimeout(fun, 0);
        }
        try {
            // when when somebody has screwed with setTimeout but no I.E. maddness
            return cachedSetTimeout(fun, 0);
        } catch(e){
            try {
                // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
                return cachedSetTimeout.call(null, fun, 0);
            } catch(e){
                // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
                return cachedSetTimeout.call(this, fun, 0);
            }
        }
    
    
    }
    function runClearTimeout(marker) {
        if (cachedClearTimeout === clearTimeout) {
            //normal enviroments in sane situations
            return clearTimeout(marker);
        }
        // if clearTimeout wasn't available but was latter defined
        if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
            cachedClearTimeout = clearTimeout;
            return clearTimeout(marker);
        }
        try {
            // when when somebody has screwed with setTimeout but no I.E. maddness
            return cachedClearTimeout(marker);
        } catch (e){
            try {
                // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
                return cachedClearTimeout.call(null, marker);
            } catch (e){
                // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
                // Some versions of I.E. have different rules for clearTimeout vs setTimeout
                return cachedClearTimeout.call(this, marker);
            }
        }
    
    
    
    }
    var queue = [];
    var draining = false;
    var currentQueue;
    var queueIndex = -1;
    
    function cleanUpNextTick() {
        if (!draining || !currentQueue) {
            return;
        }
        draining = false;
        if (currentQueue.length) {
            queue = currentQueue.concat(queue);
        } else {
            queueIndex = -1;
        }
        if (queue.length) {
            drainQueue();
        }
    }
    
    function drainQueue() {
        if (draining) {
            return;
        }
        var timeout = runTimeout(cleanUpNextTick);
        draining = true;
    
        var len = queue.length;
        while(len) {
            currentQueue = queue;
            queue = [];
            while (++queueIndex < len) {
                if (currentQueue) {
                    currentQueue[queueIndex].run();
                }
            }
            queueIndex = -1;
            len = queue.length;
        }
        currentQueue = null;
        draining = false;
        runClearTimeout(timeout);
    }
    
    process.nextTick = function (fun) {
        var args = new Array(arguments.length - 1);
        if (arguments.length > 1) {
            for (var i = 1; i < arguments.length; i++) {
                args[i - 1] = arguments[i];
            }
        }
        queue.push(new Item(fun, args));
        if (queue.length === 1 && !draining) {
            runTimeout(drainQueue);
        }
    };
    
    // v8 likes predictible objects
    function Item(fun, array) {
        this.fun = fun;
        this.array = array;
    }
    Item.prototype.run = function () {
        this.fun.apply(null, this.array);
    };
    process.title = 'browser';
    process.browser = true;
    process.env = {};
    process.argv = [];
    process.version = ''; // empty string to avoid regexp issues
    process.versions = {};
    
    function noop() {}
    
    process.on = noop;
    process.addListener = noop;
    process.once = noop;
    process.off = noop;
    process.removeListener = noop;
    process.removeAllListeners = noop;
    process.emit = noop;
    process.prependListener = noop;
    process.prependOnceListener = noop;
    
    process.listeners = function (name) { return [] }
    
    process.binding = function (name) {
        throw new Error('process.binding is not supported');
    };
    
    process.cwd = function () { return '/' };
    process.chdir = function (dir) {
        throw new Error('process.chdir is not supported');
    };
    process.umask = function() { return 0; };
    
    },{}],6:[function(require,module,exports){
    module.exports={
      "name": "ejs",
      "description": "Embedded JavaScript templates",
      "keywords": [
        "template",
        "engine",
        "ejs"
      ],
      "version": "2.5.7",
      "author": "Matthew Eernisse <mde@fleegix.org> (http://fleegix.org)",
      "contributors": [
        "Timothy Gu <timothygu99@gmail.com> (https://timothygu.github.io)"
      ],
      "license": "Apache-2.0",
      "main": "./lib/ejs.js",
      "repository": {
        "type": "git",
        "url": "git://github.com/mde/ejs.git"
      },
      "bugs": "https://github.com/mde/ejs/issues",
      "homepage": "https://github.com/mde/ejs",
      "dependencies": {},
      "devDependencies": {
        "browserify": "^13.0.1",
        "eslint": "^4.14.0",
        "git-directory-deploy": "^1.5.1",
        "istanbul": "~0.4.3",
        "jake": "^8.0.0",
        "jsdoc": "^3.4.0",
        "lru-cache": "^4.0.1",
        "mocha": "^3.0.2",
        "uglify-js": "^2.6.2"
      },
      "engines": {
        "node": ">=0.10.0"
      },
      "scripts": {
        "test": "jake test",
        "lint": "eslint \"**/*.js\" Jakefile",
        "coverage": "istanbul cover node_modules/mocha/business/bin/_mocha",
        "doc": "jake doc",
        "devdoc": "jake doc[dev]"
      }
    }
    
    },{}]},{},[1])(1)
    });
    
(function() {
    CloudSearch = {
        components: {},
        util: {},
        init: function(name, selector, _constructor){
            this.components[name] = _constructor;
            $(selector).each(function() {
                new _constructor(this);
            });
        }
    };
})();
(function($) {
    $.extend(CloudSearch.util, {
        winWidth: function () {
            return Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
        }
    });
})($);

/**
 * File: filterable-list.js
 * Author: Tony Herford
 * Copyright: MRM//McCann 2018
 */
(function($, undefined) {
    var Filter = function() {
        this.$ctx = $('[data-cmp-list-filter]');
        this.$ctx.data('filter_obj', this);
        this.setup();
        this.bind_events();

    };

    Filter.prototype = {
        setup: function() {
            this.last_width = 0;
            this.level1_height = $('.level1 ul', this.$ctx).outerHeight();
            this.$target = $();
            this.isMobile = CloudSearch.util.winWidth() < 768;
            this.isDesktop = CloudSearch.util.winWidth() >= 768;
        },
        set_data: function (data) {
            var templ = ejs.compile($('#filters_template', this.$ctx).html());
            var output = templ(data);
            $('.level1').html(output);
            this.setup();
            this.bind_events();
        },
        bind_events: function() {
            $('.level1 .arrow-btn', this.$ctx).off('click').on('click', this.open_filter.bind(this));
            $('.level2 ul li a', this.$ctx).off('click').on('click', this.check_filter.bind(this));
            $('.pills .remove-all', this.$ctx).off('click').on('click', this.clear_all.bind(this));
            $('.pills', this.$ctx).off('click').on('click', 'a.pill', this.clear_filter.bind(this));
            $('.back-btn', this.$ctx).off('click').on('click', this.mobile_back_btn.bind(this));
            $('a.filter-label', this.$ctx).off('click').on('click', this.toggle_mobile_filter.bind(this));
            $(window).off('resize.basf_filter').on('resize.basf_filter', this.resize_handler.bind(this));
        },
        resize_handler: function(e) {
            var winWidth = CloudSearch.util.winWidth();
            if(this.last_width !== winWidth){
                this.last_width = winWidth;
                this.level1_height = $('.level1 ul', this.$ctx).outerHeight();
                this.move_pills();
                if(winWidth < 768 && !this.isMobile) {
                    $('[style]', this.$ctx).removeAttr('style');
                    $('.active', this.$ctx).removeClass('active');
                    this.isMobile = true;
                    this.isDesktop = false;
                }else if(winWidth >= 768 && !this.isDesktop){
                    $('[style]', this.$ctx).removeAttr('style');
                    $('.active', this.$ctx).removeClass('active');
                    $('.level1.open', this.$ctx).removeClass('open');
                    $('.filter-open', this.$ctx).removeClass('filter-open');
                    this.isMobile = false;
                    this.isDesktop = true;
                }
            }
        },
        toggle_mobile_filter: function (e) {
            if(e.type) e.preventDefault();

            var $target = (e && e.currentTarget) ? $(e.currentTarget) : $('.filter-open', this.$ctx);
            if($target.is('.filter-open') || ($target.length && e === 'close')){
                $target.removeClass('filter-open');
                $('.wrapper', this.$ctx).slideUp();
            }else{
                $target.addClass('filter-open');
                $('.wrapper', this.$ctx).slideDown();
            }
            this.move_pills();
        },
        open_filter: function(e) {
            if(e.type) e.preventDefault();
            var $target = this.$target = (e && e.currentTarget) ? $(e.currentTarget).parent() : $('.level1 > ul > li.active', this.$ctx);
            if(CloudSearch.util.winWidth() >= 768) {
                if($target.is('.active') || e === 'close') {
                    $target.removeClass('active');
                    this.slide_up($target.find('.level2  ul'));
                    this.move_pills(0);
                } else {
                    if($target.siblings('.active').length) {
                        var $current_active = $target.siblings('.active');
                        $current_active.removeClass('active');
                        this.slide_up($current_active.find('.level2  ul'), 'fast', this.toggle_next_down);
                    } else {
                        this.move_pills($target.find('.level2  ul').outerHeight());
                        this.slide_down($target.find('.level2  ul'));
                        $target.addClass('active');
                    }
                }
            } else {
                $target.removeClass('.active');
                $('.level2.active', this.$ctx).removeClass('active');
                $target.find('.level2').addClass('active');
                $target.closest('.level1').addClass('open');
                this.move_pills($target.find('.level2').outerHeight(), true);
            }
        },
        mobile_back_btn: function(e) {
            if(e && e.type) e.preventDefault();
            var $level1 = $('.level1', this.$ctx);
            $level1.removeClass('open');
            // $('.level2', this.$ctx).removeClass('active');
            this.move_pills($level1.find('ul').outerHeight(), true);
        },
        toggle_next_down: function() {
            this.move_pills(this.$target.find('.level2  ul').outerHeight());
            this.$target.find('.level2  ul').slideDown();
            this.$target.addClass('active');
        },
        slide_down: function($element, speed, onComplete) {
            speed = speed || 400;
            var options = {
                duration: speed
            };
            if(onComplete) {
                options.complete = onComplete.bind(this);
            }
            $element.slideDown(options);
        },
        slide_up: function($element, speed, onComplete) {
            speed = speed || 400;
            var options = {
                duration: speed
            };
            if(onComplete) {
                options.complete = onComplete.bind(this);
            }
            $element.slideUp(options);
        },
        move_pills: function(height, noLevel1) {
            var $my_parent = $('.level1 > ul .active', this.$ctx);
            if (!$my_parent.is('.level2')) $my_parent = $my_parent.find('.level2 ul');
            height = $.isNumeric(height) ? height : $my_parent.outerHeight();

            if(!noLevel1) {
                height += this.level1_height;
            }
            $('.level1', this.$ctx).css({
                'height': height || 'auto'
            });
        },
        check_filter: function(e) {
            e.preventDefault();
            $target = $(e.currentTarget);
            if($target.is('[aria-checked=true]')) {
                $target.removeAttr('aria-checked');
                this.remove_pill($target.attr('data-value'));
            } else {
                $target.attr('aria-checked', 'true');
                this.add_pill($target.text(), $target.attr('data-value'));
            }
            this.set_filters();

            // if(CloudSearch.util.winWidth() >= 768) {
                setTimeout(this.move_pills.bind(this), 200);
            // }
        },
        set_filters: function() {
            var filters = $('[aria-checked=true]', this.$ctx).map(function(i, e) {
                return $(e).data('value');
            }).get();
            this.$ctx.prop('filters', filters);
            this.$ctx.trigger('filter_change', [filters]);
        },
        add_pill: function(label, value) {
            var aria_label = '';
            var pill = '<a class="pill" href="#" role="button" data-value="' + value + '" aria-label="' + aria_label + '">' + label + '</a>';
            $('.pills .remove-all', this.$ctx).before(pill);
        },
        remove_pill: function(value) {
            $('.pills [data-value="' + value + '"]').remove();
        },
        clear_filter: function(e, t) {
            var $target = t ? $(t) : $(e.currentTarget);
            var trigger_event = t === undefined;
            if(e.type) {
                e.preventDefault();
            }
            var value = $target.attr('data-value');
            $target.remove();
            $('a[data-value="' + value + '"]').removeAttr('aria-checked');
            if(trigger_event) {
                this.set_filters();
            }
        },
        clear_all: function(e) {
            $('.pills .pill', this.$ctx).each(this.clear_filter.bind(this));
            this.toggle_mobile_filter('close');
            this.mobile_back_btn();

            this.open_filter('close');

            this.set_filters();
        }

    };
    CloudSearch.components.Filter = Filter;
    // CloudSearch.init('filter', '', Filter);
})(jQuery);

(function () {

    var SearchConfig = function(el){
        // List out all search object properties
        var urlParams = window.location.search.substring(1);
        urlParams = urlParams.length > 0 ? JSON.parse('{"' + decodeURI(urlParams.replace(/&/g, "\",\"").replace(/=/g,"\":\"")) + '"}') : {};

        // var obj = JSON.parse(el.attr("data-searchproperties"));
        var obj = {};
        this.searchEndpoint = el.find('.cs_search-results').attr("data-searchendpoint");
        this.loadDefaultResults = el.find('.cs_search-results').attr("data-loadDefaultResults");
        this.resultsDisplayFormat = el.find('.cs_search-results').attr('data-resultsdisplayformat');
        this.customTemplateColumnCount = el.find('.cs_search-results-area').attr('data-numberofresultsperrow');
        this.resultTemplate = typeof(el.find('.cs_search-results-area').attr('data-template')) !== 'undefined' ? el.find('.cs_search-results-area').attr('data-template') : "";
        this.facets = typeof(el.find('.cs_search-filter').attr("data-facet")) !== 'undefined' ? el.find('.cs_search-filter').attr("data-facet").split(",") : "";
        this.defaultNumberOfResults = typeof(el.find('.cs_search-results').attr("data-defaultnumberofresults")) !== 'undefined' ? el.find('.cs_search-results').attr("data-defaultnumberofresults") : "";
        this.filterLookup = obj.hasOwnProperty("filterLookup") ? obj.filterLookup : "";
        this.resultsCountLookup = typeof(el.find('.cs_search-results').attr("data-defaultnumberofresults")) !== 'undefined' ? el.find('.cs_search-results').attr("data-defaultnumberofresults") : "";
        this.resultFields = typeof(el.find('.cs_search-results').attr("data-indexs")) !== 'undefined' && el.find('.cs_search-results').attr("data-indexs") !== false ? el.find('.cs_search-results').attr("data-indexs") : "";
        this.site_name = urlParams.hasOwnProperty("cs_site_name") ? urlParams.cs_site_name.split(",") : typeof(el.find('.cs_search-results').attr("data-sitename")) !== 'undefined' && el.find('.cs_search-results').attr("data-sitename") !== false ? el.find('.cs_search-results').attr("data-sitename").split(",") : "";
        this.paginationType = typeof(el.find('.cs_search-component-pagenation').attr("data-paginationType")) !== 'undefined' && el.find('.cs_search-component-pagenation').attr("data-paginationType") !== false ? el.find('.cs_search-component-pagenation').attr("data-paginationType") : "";
        this.locale = typeof(document.head.querySelector("[name=locale]")) !== 'undefined' ? document.head.querySelector("[name=locale]").content.replace('-', '_').toLowerCase() : "";
        this.page = urlParams.hasOwnProperty("page") ? parseInt(urlParams.page) : "";
        this.contentType = typeof(el.find('.cs_search-results').attr("data-contenttype")) !== 'undefined' && el.find('.cs_search-results').attr("data-contenttype") !== false ? el.find('.cs_search-results').attr("data-contenttype").split(',') : "";
        this.showMoreLabel = typeof(el.find('.cs_search-component-pagenation').attr("data-loadmorelabel")) !== 'undefined' && el.find('.cs_search-component-pagenation').attr("data-loadmorelabel") !== false ? el.find('.cs_search-component-pagenation').attr("data-loadmorelabel") : "Please author a show more label to be shown here";

        this.showRecentsearches = obj.hasOwnProperty("showRecentsearches") ? obj.showRecentsearches : "";
        this.loadNumberOfResults = obj.hasOwnProperty("loadNumberOfResults") ? obj.loadNumberOfResults : "";
        this.q = obj.hasOwnProperty("q") && obj.q.length > 0 ? obj.q : urlParams.hasOwnProperty("cs_query") ? urlParams.cs_query : "";
        this.noResultsLabel = typeof(el.find('.cs_search-results').attr("data-noResultsLabel")) !== 'undefined' && el.find('.cs_search-results').attr("data-noResultsLabel") !== false ? el.find('.cs_search-results').attr("data-noResultsLabel") : "Please author a no results label to be shown here";
        console.log(this);
    };

    CloudSearch.components.SearchConfig = SearchConfig;

})();
(function () {
    var SearchQuery = function(options, cb){
        this.createUrl(options, cb);
    };

    SearchQuery.prototype = {
        createUrl: function(options, cb){
            var url = "";
            // build url using provided options
            url += options.hasOwnProperty("searchEndpoint") ? options.searchEndpoint + '?' : '';
            url += options.hasOwnProperty("defaultNumberOfResults") ? 'size=' + options.defaultNumberOfResults : 'size=20';
            url += options.hasOwnProperty("start") ? '&start=' + options.start : '&start=0';
            url += options.hasOwnProperty("qparser") ? '&q.parser=' + options.qparser : '&q.parser=structured';
            url += options.hasOwnProperty("q") && options.q.length > 0 ? '&q=%27' + options.q + '%27' : '&q=matchall';
            url += options.hasOwnProperty("resultFields") && options.resultFields.length > 0 ? '&return=' + options.resultFields : '&return=_all_fields';
            if (options.hasOwnProperty("getFacets") && options.getFacets && options.hasOwnProperty("facets") && options.facets.length > 0){
                url += '&facet=%7B';
                for (var f=0; f<options.facets.length; f++){
                    facetKey = options.facets[f].split("|");
                    url += '%22' + facetKey[1] + '%22%3A%7B%22sort%22%3A%22count%22%7D';
                    url += (f + 1 !== options.facets.length) ? '%2C' : '';
                }
                url += '%7D';
            }
            if ((options.hasOwnProperty("site_name") && options.site_name.length > 0) || (options.hasOwnProperty("locale") && options.locale.length > 0) || (options.hasOwnProperty("content_type") && options.content_type.length > 0) || (options.hasOwnProperty("selected_filters") && options.selected_filters.length > 0)){
                url += '&fq=%28and';
                if (options.hasOwnProperty("site_name") && options.site_name.length > 0){
                    url += '%20%28or';
                    for (var n=0; n<options.site_name.length; n++){
                        url += '%20site:\'' + options.site_name[n] + '\'';
                    }
                    url += '%29';
                }
                if (options.hasOwnProperty("locale") && options.locale.length > 0){
                    url += '%20%28or%20locale:\'' + options.locale + '\'%29';
                }
                if (options.hasOwnProperty("contentType") && options.contentType.length > 0){
                    url += '%20%28or';
                    for (var t=0; t<options.contentType.length; t++){
                        url += '%20content_type:\'' + options.contentType[t] + '\'';
                    }
                    url += '%29';
                }
                if (options.hasOwnProperty("selected_filters") && typeof(options.selected_filters) !== "string" && Object.keys(options.selected_filters).length !== 0){
                    var selectedFilter = "";
                    url += '%20%28or';
                    for (prop in options.selected_filters){
                        selectedFilter = options.selected_filters[prop];
                        for (var s=0; s<selectedFilter.length; s++){
                            url += '%20'+prop+':\'' + selectedFilter[s] + '\'';
                        }
                    }
                    url += '%29';
                }
                url += '%29';
            }
            url += options.hasOwnProperty('sortby') ? options.sortby : "&sort=last_replicated%20desc";
            // return completed url
            return cb(url);
        }
    };

    CloudSearch.components.SearchQuery = SearchQuery;
})();

(function () {
    var Pagination = function(options){
        this.options = options;
        this.numberOfPages = Math.ceil(this.options.data.hits.found / this.options.resultsPerPage);

        this.init();
    };

    Pagination.prototype = {
        init: function(){
            if (this.options.searchObj.config.paginationType === "showMore"){
                this.createShowMore();
            } else {
                this.createPagination();
            }
        },
        createShowMore: function(){
            if (this.options.activePageNumber !== this.numberOfPages){
                var showMoreLabel ="";
                var pageLink = "";
                var showMoreLabel = this.options.searchObj.config.showMoreLabel;
                pageLink = '<li><a class="cs_pagination-link showMoreLink" data-forward="true" href="#">'+showMoreLabel+'</a></li>';
                this.options.target.html(pageLink);
                this.addPaginationLinkHandler();
            } else {
                this.options.target.html("");
            }
        },
        createPagination: function(){
            this.options.target.empty();
            var resultsNumber = this.options.data.hits.found;
            var pageLink = "";
            var lowLimit = "";
            var highLimit = "";
            var isActive = "";
            if (resultsNumber > this.options.resultsPerPage){
                
                if (this.options.activePageNumber !== 1){
                    pageLink = '<li><a class="cs_pagination-link back-link" href="#"><i class="fa fa-chevron-left" aria-hidden="true"></i></a></li>';
                    this.options.target.append(pageLink);
                }
                if (this.numberOfPages > 10){
                    isActive = (this.options.activePageNumber === 1) ? " active-page" : "";
                    pageLink = '<li><a class="cs_pagination-link'+isActive+'" data-link-number="0" href="#">1</a></li>';
                    this.options.target.append(pageLink);
                    if (this.options.activePageNumber > 5){
                        this.options.target.append("<li>...</li>");
                        lowLimit = this.options.activePageNumber - 2;
                        highLimit = this.options.activePageNumber + 3;
                        for (var i=lowLimit; i<highLimit; i++){
                            isActive = (this.options.activePageNumber === i) ? " active-page" : "";
                            pageLink = '<li><a class="cs_pagination-link'+isActive+'" data-link-number="'+i+'" href="#">'+i+'</a></li>';
                            this.options.target.append(pageLink);
                        }
                    } else {
                        for (var i=2; i<6; i++){
                            isActive = (this.options.activePageNumber === i) ? " active-page" : "";
                            pageLink = '<li><a class="cs_pagination-link'+isActive+'" data-link-number="'+i+'" href="#">'+i+'</a></li>';
                            this.options.target.append(pageLink);
                        }
                    }
                    
                    this.options.target.append("<li>...</li>");
                    pageLink = '<li><a class="cs_pagination-link" data-link-number="'+this.numberOfPages+'" href="#">'+this.numberOfPages+'</a></li>';
                    this.options.target.append(pageLink);
                } else {
                    for (var i=1; i<=this.numberOfPages; i++){
                        pageLink = '<li><a class="cs_pagination-link" data-link-number="'+i+'" href="#">'+i+'</a></li>';
                        this.options.target.append(pageLink);
                    }
                }
                if (this.options.activePageNumber !== this.numberOfPages){
                    pageLink = '<li><a class="cs_pagination-link forward-link" data-forward="true" href="#"><i class="fa fa-chevron-right" aria-hidden="true"></i></a></li>';
                    this.options.target.append(pageLink);
                }
                this.addPaginationLinkHandler();
            }
        },
        addPaginationLinkHandler: function(){
            $('.cs_pagination-link').click(function(e){
                if (this.options.searchObj.config.paginationType === "showMore"){
                    this.options.searchObj.config.persistResults = true;
                }
                var clickedLink = $(e.currentTarget);
                var resultsPerPage = parseInt(this.options.resultsPerPage);
                e.preventDefault();
                if (clickedLink.attr('data-link-number')){
                    this.options.searchObj.config.page = parseInt(clickedLink.attr('data-link-number'));
                    this.options.start = parseInt(clickedLink.attr('data-link-number') - 1) * resultsPerPage;
                } else {
                    if (clickedLink.hasClass('back-link')){
                        if (this.options.searchObj.page !== 1){
                            this.options.start = (this.options.searchObj.config.page - 2) * resultsPerPage;
                            this.options.searchObj.config.page -= 1;
                        }
                    } else {
                        this.options.start = this.options.searchObj.config.page * resultsPerPage;
                        this.options.searchObj.config.page += 1;
                    }
                }
                console.log(this.options.start);
                var newSearchOptions = this.options.searchObj.config;
                newSearchOptions.start = parseInt(this.options.start);
                new CloudSearch.components.SearchQuery(newSearchOptions, function(url){
                    this.options.searchObj.loadResults(url);
                }.bind(this));
            }.bind(this));
        }
    };

    CloudSearch.components.Pagination = Pagination;
})();

(function () {
    // Constructor
    var SearchRequest = function(options, cb){
        this.options = options;
        this.cb = cb;
        this.makeRequest();
    };

    SearchRequest.prototype = {
        makeRequest: function(){
            var self = this;
            var requestURL = "";
            var requestMethod = "";
            var requestDataType = "";

            requestURL = this.options.hasOwnProperty("requestURL") && this.options.requestURL.length > 0 ? this.options.requestURL : "";
            requestMethod = this.options.hasOwnProperty("http_method") ? this.options.http_method : "GET";
            requestDataType = this.options.hasOwnProperty("data_type") ? this.options.data_type : "json";
            // I probably should provide a way to pass any other params in here that are necessary for a call to be made.

            $.ajax({
                url: requestURL,
                method: requestMethod,
                dataType: requestDataType
            }).done( function(response){
                self.handleSuccess(response);
            }).fail( function(msg){
                self.handleError(msg);
            });
        },
        handleSuccess: function(data){
            return this.cb(data);
        },
        handleError: function(data){
            return this.cb("error! " + data);
        }

    };

    CloudSearch.components.SearchRequest = SearchRequest;
})();
(function () {
    var SearchResult = function(data, target){
        this.$target = target;
        this.config = data;
        this.init(data);
    };

    SearchResult.prototype = {
        init: function(data){
            switch(data.resultType) {
                case "standard":
                    this.generateRowResult(data.resultData);
                    break;
                case "custom":
                    this.generateBoxResult(data.resultData);
                    break;
                case "table":
                    this.generateTableResult(data.resultData);
                    break;
                default:
                    this.generateRowResult(data.resultData);
            }
        },
        generateBoxResult: function(data){
            var resultHtml = '';
            var val = "";
            var classes = "";
            var template = "";
            template = JSON.parse(this.config.template);
            resultHtml += '<a class="cs_result-link" href="'+data.path+'">';
            resultHtml += '<div class="cs_box-result aem-Grid aem-Grid--12 aem-Grid--default--12 column-'+this.config.columns+'">';
            for (var t=0; t<template.length; t++){

                classes = template[t].class;
                field = template[t].field;
                if (data.hasOwnProperty(field)){
                    val = data[field];
                    if (field === 'image'){
                        resultHtml += '<img class="cs_result-field-'+field+' '+classes+'" src="'+val+'" />';
                    } else if (field === 'path') {

                    } else {
                        resultHtml += '<div class="cs_result-field-'+field+' '+classes+'">'+val+'</div>';
                    }
                } 
            }
            resultHtml += '</div>';
            resultHtml += '</a>';
            this.returnHtml(resultHtml);
        },
        generateRowResult: function(data){
            var resultHtml = '';
            resultHtml += '<div class="cs_row-result"><a class="cs_result-link" href="'+data.path+'">';
            for (prop in data){
                if (prop !== "path"){
                    if (prop === 'image'){
                        resultHtml += '<div class="cs_result-field-'+prop+'"><img src="'+data[prop]+'"></div>';
                    } else {
                        resultHtml += '<div class="cs_result-field-'+prop+'">'+data[prop]+'</div>';
                    } 
                }
            }
            resultHtml += '</a></div>';
            this.returnHtml(resultHtml);
        },
        generateTableResult: function(data){
            var resultHtml = '';
            resultHtml += '<tr class="cs_table-row-result">';
            for (prop in data){
                if (prop === 'image'){
                    resultHtml += '<td class="cs_result-field-'+prop+'"><img src="'+data[prop]+'"></td>';
                } else {
                    resultHtml += '<td class="cs_result-field-'+prop+'">'+data[prop]+'</td>';
                }
            }
            resultHtml += '</tr>';
            this.returnHtml(resultHtml);
        },
        returnHtml: function(html){
            this.$target.append(html);
        }
    };

    CloudSearch.components.SearchResult = SearchResult;
})();

(function () {
    // Constructor
    var SearchSort = function(){
        this.initHandlers();
    };

    SearchSort.prototype = {
        initHandlers: function(){
            $('dd').click(function(){
                $('dd').removeClass('selected');
                $(this).addClass('selected');
            });
        }
    };

    CloudSearch.components.SearchSort = SearchSort;

    $(document).ready(function(){
        $('.cs_search-sort-search-results').each(function(index,el){
            new SearchSort(el);
        });
    });

})();
(function () {
    var CloudSearchComponent = function(el){
        this.$ctx = $(el);
        this.config = new CloudSearch.components.SearchConfig(this.$ctx);

        // HTML Elements
        this.$resultsArea = this.$ctx.find(".cs_search-results-area");
        this.$searchBox = this.$ctx.find('.cs_search-string');
        this.$searchSubmit = this.$ctx.find('.cs_search-submit');
        this.$currentlyShowing = this.$ctx.find('.cs_currently-showing');
        this.$totalResults = this.$ctx.find('.cs_total-results');
        this.$searchTerm = this.$ctx.find('.cs_search-term');
        this.$resultsCountString = this.$ctx.find('.cs_search-term-string');
        this.$filter = $('[data-cmp-list-filter]').data('filter_obj');
        this.$resultsCountLabel = this.$ctx.find('.cs_results-count');
        this.$pagination = this.$ctx.find('.cs_pagination-links');

        // Flags
        this.isInitialSearch = true;
        this.loadResultsInitially = true;

        // Init handlers, load initial data including facets for filter
        this.initHandlers();
        this.setPageNumber();
        this.getInitialData();
    };

    CloudSearchComponent.prototype = {
        initHandlers: function(){
            // Handle search submit button click
            this.$searchSubmit.click(function(e){
                e.preventDefault();
                this.newUserSearch();
            }.bind(this));

            // Handle filter add/remove
            $('[data-cmp-list-filter]').on('filter_change', function(e, filters){
                this.getFilterValues(filters);
                this.config.persistResults = false;
                var options = this.config;
                options.getFacets = false;
                options.start = 0;

                new CloudSearch.components.SearchQuery(options, function(url){
                    this.loadResults(url);
                }.bind(this));
            }.bind(this));
            
            $('.cs_sort-options dd').click(function(){
                this.getSortOption();
            }.bind(this));

        },
        getSortOption: function(){
            var sort = $('.cs_search-sort-search-results').find('.selected').attr('data-sortby');
            var sotrStr = "";
            if (sort === 'relevance'){
                sortStr = "&q.options=%7Bfields%3A%5B%27tags%5E20%27%2C%27site%5E15%27%2C%27title%5E2%27%2C%27short_title%5E1.2%27%5D%7D";
            } else if(sort === 'alphabetical'){
                sortStr = '&sort=title%20asc';
            } else {
                sortStr = '&sort=last_replicated%20desc';
            }
            this.config.sortby = sortStr;
            this.config.persistResults = false;
            var options = this.config;
            options.getFacets = false;
            options.start = 0;
            new CloudSearch.components.SearchQuery(options, function(url){
                this.loadResults(url);
            }.bind(this));
        },
        getFilterValues: function(data){
            console.log(data);
            var selected_filters = {};
            var filter = "";
            for (var f=0; f<data.length; f++){
                var thisFilter = data[f];
                thisFilter = thisFilter.split("|");
                filter = thisFilter[0];
                if (!selected_filters.hasOwnProperty(filter)){
                    selected_filters[filter] = [];
                }
                selected_filters[filter].push(thisFilter[1]);
            }
            this.config.selected_filters = selected_filters;
        },
        getInitialData: function(){
            var options = this.config;
            this.config.persistResults = false;
            options.getFacets = true;
            options.start = 0;
            options.qparser = 'structured';
            new CloudSearch.components.SearchQuery(options, function(url){
                if (this.config.loadDefaultResults){
                    this.loadResults(url);
                }
            }.bind(this));
        },
        setPageNumber: function(){
            if (!window.location.search.includes("page=")){
                var url = "";
                if (this.config.page.length > 0){
                    pageParam = "page="+String(this.config.page);
                    url = window.location.href.toString();
                    url = url.replace(/page=([^&]*)/, pageParam);
                } else {
                    this.config.page = 1;
                    if (window.location.href.includes('?')){
                        url = window.location.href + '&page=1';
                    } else {
                        url = window.location.href + '?page=1';
                    }
                }
                if (history.pushState){
                    history.pushState({},"",url);
                }
            }
        },
        newUserSearch: function(){
            var options = this.config;
            this.config.persistResults = false;
            options.getFacets = false;
            options.start = 0;
            options.q = this.$searchBox.val();

            new CloudSearch.components.SearchQuery(options, function(url){
                this.loadResults(url);
            }.bind(this));

        },
        loadResults: function(url){
            var options = {};

            options.requestURL = url;

            new CloudSearch.components.SearchRequest(options, function(data){
                if (data.hits.found !== 0) {
                    if (this.isInitialSearch){
                        // Load up filters if this is the initial page load
                        this.generateFilters(data);

                        // Turn flag off for loading filters so they aren't re-loaded every time we load new results
                        this.isInitialSearch = false;

                        // Exit method early if actual results are not supposed to be shown until enters a search term or interacts with filter
                        if (!this.config.loadDefaultResults){
                            return;
                        }
                    }
                    // Set result count label
                    this.setResultCountLabel(data);

                    // Load up set of results onto page
                    this.generateResultHtml(data);

                    // Create pagination based on result set
                    this.generatePagination(data);
                } else {
                    this.showNoResults();
                }

            }.bind(this));
        },
        showNoResults: function(){
            this.$resultsCountLabel.hide();
            this.$resultsArea.html(this.config.noResultsLabel);
        },
        createShowMoreResultsCount: function(data){
            this.startShowing = 1;
            if ((this.startShowing + parseInt(this.config.defaultNumberOfResults) + data.hits.start) <= data.hits.found){
                this.maxShown = data.hits.start + parseInt(this.config.defaultNumberOfResults);
            } else {
                this.maxShown = data.hits.found;
            }
        },
        createNumbersResultsCount: function(data){
            this.startShowing = parseInt(data.hits.start);
            if ((this.startShowing + parseInt(this.config.defaultNumberOfResults)) < data.hits.found){
                this.maxShown = this.startShowing + parseInt(this.config.defaultNumberOfResults);
            } else {
                this.maxShown = data.hits.found;
            }
            this.startShowing = this.startShowing + 1;
        },
        setShowingForLabel: function(){
            if (!this.config.q.length > 0){
                this.$resultsCountString.hide();
            } else {
                this.$resultsCountString.show();
                this.$searchTerm.html(this.config.q);
            }
            this.$resultsCountLabel.show();
        },
        setResultCount: function(data){
            this.$currentlyShowing.html(this.startShowing + ' - ' + this.maxShown);
            this.$totalResults.html(data.hits.found);
            this.setShowingForLabel();
        },
        setResultCountLabel: function(data){
            if (this.config.paginationType === "showMore"){
                this.createShowMoreResultsCount(data);
            } else {
                this.createNumbersResultsCount(data);
            }
            this.setResultCount(data);
        },
        generateFilters: function(data){
            if (data.hasOwnProperty('facets')){
                var Filter = new CloudSearch.components.Filter();

                var thisFacet = "";
                var facetLabels = {};
                for (var d=0; d<this.config.facets.length; d++){
                    thisFacet = this.config.facets[d].split("|");
                    key = thisFacet[1];
                    value = thisFacet[0];
                    facetLabels[key] = value;
                }                
                var facetData = "";
                facetData = data;
                for (facet in facetData.facets){
                    facetData.facets[facet].label = facetLabels[facet];
                }
                Filter.set_data(facetData);
            }
        },
        generateResultHtml: function(data){
            console.log(data);

            var resultObj = {};
            var result = "";
            var results = "";
            resultObj.columns = this.config.customTemplateColumnCount;
            resultObj.template = this.config.resultTemplate;
            resultObj.resultType = this.config.resultsDisplayFormat;
            results = data.hits.hit;
            if (!this.config.persistResults){
                this.$resultsArea.empty();
            }

            for (var i=0; i<results.length; i++){
                resultObj.resultData = results[i].fields;
                new CloudSearch.components.SearchResult(resultObj, this.$resultsArea);
            }
        },
        generatePagination: function(data){
            var options = {};
            options.searchObj = this;
            options.data = data;
            options.activePageNumber = this.config.page;
            options.resultsPerPage = this.config.defaultNumberOfResults;
            options.target = this.$pagination;
            new CloudSearch.components.Pagination(options);
        }
    };

    CloudSearch.components.SearchComponent = CloudSearchComponent;

    $(function() {
        $('.cs_search-component').each(function(index, el) {
            console.log('create search component');
            new CloudSearchComponent(el);
        });
    });
})();
// oi.js Verizon Gating System
window.VZoptin = new function() {
 var optin=this;
 var $=window.$;
 this.debug=(window.location.search.indexOf('debug')>0 || window.location.hostname.indexOf('v')<0 ? 1 : 0);
 var path="/business/resources/opt-in/";
 var sales="/business/contact/request-consultation/"; ///content/verizonenterprise/us/en/index/support/sales/";
 var form;
 var lang = "";
 var ctry = "";
 var dataclose;
 var thanksfile;
 var thankspath="";
 var cookie='HBRregister';
 var opencount='OIo';
 var type='Opt In';
 var softURL; // URL of soft gated link
 this.done=0; // form completed
 var token=""; // gate token
 var csrf=""; // csrf token
    var gdpr={at:1,be:1,bg:1,hr:1,cy:1,cz:1,dk:1,ee:1,fi:1,fr:1,de:1,gb:1,gr:1,hu:1,is:1,ie:1,it:1,lv:1,lu:1,lt:1,mt:1,nl:1,pl:1,ro:1,sk:1,es:1,se:1,uk:1};

    // marketo shadow form IDs
       var shadow={
            "ent":{host:"//app-ab21.marketo.com",acct:"157-IPW-846",id:5748},
            "en":{host:"//app-ab21.marketo.com",acct:"157-IPW-846",id:5748},
            "fr":{host:"//app-ab21.marketo.com",acct:"157-IPW-846",id:4161},
            "de":{host:"//app-ab21.marketo.com",acct:"157-IPW-846",id:4160},
            "ja":{host:"//app-ab21.marketo.com",acct:"157-IPW-846",id:6274},
            "pub":{host:"//info.public.solution.verizon.com",acct:"836-KDI-147",id:1118},
            "vzw":{host:"//app-ab10.marketo.com",acct:"324-BZD-350",id:1640},
            "fios":{host:"//info.business.solution.verizon.com",act:"422-QGQ-523",id:1496}
        };


 // cookie handling
 var readCookie=function(name) {
	var nameEQ = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0; i < ca.length; i++) {
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1,c.length);
		if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
	}
	return null;
 }

 // add lightbox handler to gated links
 this.handler=function() {
  if (typeof($.fancybox)!="undefined") {
    $('body').on('click','a.gating_soft,a.gating_hard',optin.gate);
    //$('.gating_softgate>audio,.gating_hardgate>audio').on('play',optin.gateMedia); 
      if (typeof(Demandbase)=="undefined" && $(".gating_soft,.gating_hard").length) {
          $.ajax({url:"https://scripts.demandbase.com/IhQvrt1O.min.js",dataType:"script",cache:true});
      }
  } else if (optin.debug) { console.log("No fancybox"); }
     if (window.location.port > 4000) {
         path="/content/verizonenterprise/us/en/index/resources/opt-in/";
     }
     var ml=$('head meta[name=\"language\"]').attr("content") || $('html').attr("lang");
     if (ml && (ml=='fr' || ml=='de' || ml=='ja')) { lang="."+ml; }
     if ($('.gatePoint #mktoGate').length) {
         if ($("#mktoGate a.nothanks").length) { type="Soft Gate"; }
         if (optin.show()) {
            optin.setURL($("#mktoGate a.register"));
             if ($("#mktoGate form.shadow").length) {
                 optin.shadowHandler();
             } else {
 				optin.mktoGate();
             }
			$(".gatePoint").nextAll("div").hide();
             $(".gatePoint .nothanks").click(function(e) {
                 e.preventDefault();
                 $(".gatePoint").addClass('closed').nextAll("div").show();
                 var top=$(".gatePoint").offset().top;
                 if ($(window).scrollTop() > top) {
                     $(window).scrollTop(top - 128);
                 }
                 // tmp cookie
                 var expire=new Date();
      			 expire.setTime(expire.getTime()+(1200*1000));
   				 document.cookie=opencount+"=5; path=/; expires="+expire.toGMTString();
             });
         } else {
             $(".gatePoint").hide();
             if (window.location.search.indexOf("mkt_tok")>0 && $("#mktoGate .confirm").length) {
                 $.fancybox.open({src:"#mktoGate .confirm"});
             }
         }
     }
 }


 // should a gate by shown
 this.show=function() {
     if (!optin.debug && readCookie(cookie) != null) { return false; }
     if (window.location.search.indexOf("mkt_tok")>0) { return false; }
     else if (document.referrer.indexOf("go.verizon")>0) { return false; }
     else if (document.referrer.indexOf("info.verizon")>0) { return false; }
     try { if (document.referrer.indexOf(softURL.attr("href").replace(/.+\/(.+\..{3,4})/,"$1"))>0) { return false; }} catch(e) {}
     try { if (type=="Soft Gate" && readCookie(opencount) > 2) { return false; } } catch (e) {}
     return true;
 }

 // get token
 this.getToken=function(cb) {
     var link=$(softURL).attr("href");
     var path=link.replace(/.*?c[e3]s\/([adefijprt]{2}\/|).*/,"$1T0/");
     $.ajax({url:"/business/bin/get/asset.json/resources/"+path+$(softURL).attr("data-uid"),dataType:"json",cache:true,timeout:5000,success:function(data){
         if (data.token) {
             token=data.token;
         }
         if (typeof(cb)=="function") { cb(token); }
     },error:function(xhr,msg) {
         console.log("Token error: "+msg);
         if (typeof(cb)=="function") { cb(token); }
     }});
 }

// onclick of gated link
 this.gate=function(e) {
  var link=this;
  type=($(link).hasClass('gating_hard') ? 'Hard Gate' : $(link).hasClass('gating_soft') ? 'Soft Gate' : 'Opt In');
  var fm=($(link).attr('href') || "").match(/\/(.*\.pdf)/);
  var file=(fm && fm[1] ? fm[1] : $(link).text())
  var urlid=$(link).attr('data-urlid') || $(link).attr('urlid') || null;
  softURL=link;
     // skip form if known and (US or SoftGate)
  if (!optin.debug && readCookie(cookie) != null) { // already got one
      optin.mktoKnown();
   // LOG INSIDER
      if (typeof(dataLayer)!="undefined") {
   dataLayer.push({
    'event': 'softgate',
    'hascookie': '1',
    'optinform': 'already opted in'
   });
      }
   return true;
  } else if (typeof(Bert) != "undefined" && Bert.SG == 'Mkto') { // known visitor
   // LOG MARKETO
      if (typeof(dataLayer)!="undefined") {
   dataLayer.push({
    'event': 'softgate',
    'optinform': 'marketo skipped'
   });
      }
   return true;
  }
  if (!optin.debug && readCookie(opencount) > 6) { // give up asking
   return true;
  }

     if (type=="Hard Gate" || type=="Soft Gate") {// use new system
		if (typeof(window.URL)!="undefined") {
         var lh=new URL($(link).attr("href"),window.location.origin).hostname;
            if (lh==window.location.hostname || lh.indexOf(".verizon.com")>0 || lh.indexOf("vzbtest")>0) { return true; } // was enterprise
        } else { return true; }
     }
  if (e) { e.preventDefault(); e.stopImmediatePropagation(); }
  // open the gate
  $.fancybox.open({src:path+"gate-form"+lang+".html",type:"ajax",opts:{afterLoad:optin.mktoGate,beforeClose:optin.closed}});
  //$.ajax({url:"/business/libs/granite/csrf/token.json",dataType:"json",success:function(t){csrf=t.token}});
 }

 // set to given link
 this.setURL=function(link) {
     softURL=link;
     type=($(link).hasClass('gating_hard') || $(link).attr('data-gate')=="hard" ? 'Hard Gate' : $(link).hasClass('gating_soft') || $(link).attr('data-gate')=="soft" ? 'Soft Gate' : 'Opt In');
  }

 // load optin form into div
 this.loadForm=function(div) {
     if (div) {
      softURL=div;
     var ml=$('head meta[name=\"language\"]').attr("content") || $('html').attr("lang");
     if (ml && (ml=='fr' || ml=='de' || ml=='ja')) { lang="."+ml; }
      div.load(path+"gate-form"+lang+".html",optin.mktoGate);
     }
 }

 // load asset meta info
 this.loadMeta=function(form,cb) {
     var href=$(softURL).attr('href').match(/(\/resources.+\.pdf)/);
     if (href) {
         $.ajax({url:"/business/bin/get/asset.json"+href[1],dataType:"json",cache:true,timeout:15000,success:function(data){
                 var val={};
                if (data.title) { val['mktoformlastAssetTitle']=data.title; }
                if (data.img) { val['mktoformlastAssetImage']=window.location.origin+data.img; }
                if (data.type) { val['mktoformlastAssetType']=data.type; }
                if (data.solution) { val['mktoformlastAssetProduct']=data.solution; }
                 form.setValues(val);
		         if (typeof(cb)=="function") { cb(); }
     },error:function() {
		         if (typeof(cb)=="function") { cb(); }
     }});
     } else if (typeof(cb)=="function") { cb(); }
 }

 // setup for marketo form
 this.mktoGate=function(n) {
  var c=readCookie('GeoCountry') || readCookie('SetCountry');
  if (!c) { try { c=(Demandbase.IP.CompanyProfile.country || Demandbase.IP.CompanyProfile.registry_country_code).toLowerCase(); } catch(e) {} }
  ctry=ctry || c;
  var title=$(softURL).attr('data-title');
  if (title) { $('#mktoGate h2:first').html(title); }
  if (gdpr[c] || window.location.search.indexOf("=eu")>0) {
      //if (type=="Hard Gate") { type="Soft Gate"; }
      if (type=="Soft Gate") {
      if ($('#mktoGate .softeu').show().length) { $('#mktoGate .soft').hide(); $('#mktoGate #showForm').addClass('enabled'); }
      }
  }
  if ($(softURL).attr('data-intro')) { $('#mktoGate .soft').text($(softURL).attr('data-intro')); $('#mktoGate .hard').remove(); }
  else if (type=='Hard Gate') { $('#mktoGate .soft').hide(); }
  else { $('#mktoGate .hard').remove();
  }
  $('#mktoGate a.register, #mktoGate button.register, #mktoGate a.nothanks').attr('href',$(softURL).attr('href'));
  var mktoID=($('#mktoGate form[id]').attr('id') || "").substr(9);
  var mktoA=$('#mktoGate form[id]').attr('data-mkto') || "157-IPW-846" ; //377-QWM-451;
  var mktoAp=(mktoA.indexOf("BZD")>0 ? 10 : 21);
  if (typeof(MktoForms2)!="undefined") {
   MktoForms2.loadForm("//app-ab"+mktoAp+".marketo.com",mktoA,mktoID, optin.mktoForm);
  } else if (typeof(n)=="number" && n>0) {
   optin.mktoSubmit(); // follow link on error
  } else {
   $.ajax({url:"//app-ab"+mktoAp+".marketo.com/js/forms2/js/forms2.min.js",dataType:"script",cache:true,success:function(){optin.mktoGate(1)},error:function(xh,m){
    optin.mktoSubmit(); // follow link on error
   }});
  }
  //$(window).on('unload.optin',function(){optin.closed('unload')});
 }

 // set to 2 columns
 this.twoCols=function() {
     if ($('#mktoGate div.mktoFormRow').length > 20) {
     	$('#mktoGate div.mktoFormRow:gt(3)').wrapAll("<li/>");
     	$('#mktoGate div.mktoFormRow:lt(4)').wrapAll("<li/>");
     } else {
     	$('#mktoGate div.mktoFormRow:gt(2)').wrapAll("<li/>");
     	$('#mktoGate div.mktoFormRow:lt(3)').wrapAll("<li/>");
     }
     $('#mktoGate form>li').wrapAll("<ul class='c2 wide'/>");
 }

 // set hidden fields
 this.mktoFormVal=function(form) {
     var href=$(softURL).attr('href');
     var hhref=href;
     try {
         hhref=new URL(href,window.location.origin).href;
     } catch (e) {
         if (href.indexOf("//")<0) {
             hhref=window.location.origin+href; }
     }
     hhref=hhref.replace(/^https?\:\/\//,'');
     var val={'mktoformoriginalPAGE':document.location.pathname,'mktoformoriginalASSET':href,'mktofromlastAssetURL':hhref};
  try { val['mktoformoriginalSOURCE']=Bert.profile.utm.source } catch(e) {}
  try { val['mktoformoriginalMEDIUM']=Bert.profile.utm.medium } catch(e) {}
  try { val['mktoformlastSOURCE']=Bert.profile.utm.source } catch(e) {}
  try { val['mktoformlastMEDIUM']=Bert.profile.utm.medium } catch(e) {}
  try { val['mktoformlastCAMPAIGN']=Bert.profile.utm.campaign } catch(e) {}
  try { val['mktoformlastCONTENT']=Bert.profile.utm.content } catch(e) {}
  val['mktoformlastAssetTitle']=$(softURL).attr('data-title');
  if ($(softURL).attr('data-img')) { val['mktoformlastAssetImage']=window.location.origin+$(softURL).attr('data-img'); }
  val['mktoformlastAssetType']=$(softURL).attr('data-type');
  val['mktoformlastAssetProduct']=$(softURL).attr('data-product');
  try { val['mktoformlastAssetDateTime']=new Date().toDateString().substr(4,20);} catch(e) {}
  if (form) {
  	form.setValues(val)
  }
 }

  // marketo form setup
 this.mktoForm=function(form) {
  optin.mktoFormVal(form);
  if (!$(softURL).attr('data-title')) { optin.loadMeta(form); }
     if ($('.gatePoint').length) { optin.twoCols(); }

  var href=$(softURL).attr('href');
  var embed=$(softURL).attr('data-fancybox-href');
  $('#mktoGate select#Country').addClass('__db_country').on('change',optin.gdpr);
  $('#mktoGate input[name="Company"]').addClass('_db_company');
  $('#mktoGate input[name="Industry"]').attr('id','_db_industry');
  if ($(softURL).attr('data-cta')) { $('#mktoGate .mktoButton:first, #mktoGate a.register').text($(softURL).attr('data-cta')) }
  $("#mktoGate form+.cta").appendTo($("#mktoGate form:first")); // move CTAs
  $('#mktoGate a.register, #mktoGate button.register').show().on('click',function(e) {
   if (form.validate()) {
    $('#mktoGate a.register, #mktoGate button.register').addClass('loading');
    form.submit();
    if (embed || (href && href.indexOf(".pdf")>0) || $(".gatePoint #mktoGate").length) { e.preventDefault(); } // will open on submit
   } else { e.preventDefault(); }
  });
  if (type=='Soft Gate') {
   var nt=$('#mktoGate a.nothanks').show().on('click.optin',function(){optin.closed('skip')}); //.appendTo('#mktoGate .mktoButtonRow:first');
   if (embed || (href && href.indexOf(".xpdf")>0)) {
    nt.addClass('fancybox').attr('data-fancybox-href',embed || href).attr('data-fancybox-type',$(softURL).attr('data-fancybox-type') || 'iframe').on(
     'click',function(e){e.preventDefault(); setTimeout("VZoptin.iframeFallback()",750);});
   }
  }
  $('#mktoGate input:visible:first').focus();
  form.onSubmit(optin.mktoCheck);
  form.onSuccess(optin.mktoSubmit);
  if (typeof(Demandbase)!="undefined") {
    Demandbase.Config.isFormPage=function(){return true;};
    if (typeof(Demandbase.utils.loadFormModule)!="undefined"){ Demandbase.utils.loadFormModule(); }
    // if (Demandbase["FormsLoader"]) {Demandbase.FormsLoader.initializeWebForm(); }
    setTimeout('if ($.fn.jquery=="1.7.1") { $.noConflict(true); }',200);
  }
  // country test
  try {
    var c=""; //Demandbase.IP.CompanyProfile.country_name;
 	if (Demandbase.IP.CompanyProfile.country == 'US' || Demandbase.IP.CompanyProfile.registry_country_code=='US') { c='USA'; }
     if ($('#mktoGate select#Country option').filter("[value='"+c+"']").length) {
      $('#mktoGate select#Country').val(c);
    }
 } catch (e) {}
}

 // marketo known user
 this.mktoKnown=function(n) {
   if (typeof(MktoForms2)!="undefined") {
       if ($('#mktoForm_5779').length) { optin.mktoKnownForm(MktoForm2.getForm(5779)); }
       else {
             $('body').append('<form id="mktoForm_5779" style="display:none;"></form>');
       		 MktoForms2.loadForm("//app-ab21.marketo.com","157-IPW-846","5779", optin.mktoKnownForm);
            }
  } else if (!n) {
   $.ajax({url:"//app-ab21.marketo.com/js/forms2/js/forms2.min.js",dataType:"script",cache:true,success:function(){optin.mktoKnown(1)}
   });
  }
 }
 this.mktoKnownForm=function(form) {
  optin.mktoFormVal(form);
  form.onSuccess(function(v,u) { return false; });
  if (!$(softURL).attr('data-title')) { optin.loadMeta(form,form.submit); }
  else { form.submit() };
 }


 // open contact us
 this.contact = function(topic) {
     var ss=JSON.parse(sessionStorage["contact"] || "{}");
     $("#mktoGate .fields input[name],#mktoGate .fields select[name]").each(function(i,v) {
        if ($(v).val()) {
			ss[$(v).attr("name").toLowerCase()]=$(v).val();
        }
     });
     ss["additional"]="Gated Document: "+$(softURL).attr('data-title');
     sessionStorage["contact"]=JSON.stringify(ss);
     setTimeout("window.location=\""+sales+"\"",750);
     return true;
 }

 // shadow form submitted
 this.shadowDone = function(val) {
     $("#mktoGate button.loading").removeClass("loading");
     if (!optin.debug || window.confirm("good to go?")) {
         if (val) {
            var expire=new Date();
            expire.setTime(expire.getTime()+(window.location.hostname.indexOf('w.verizon')>=0 ? 30 : 0.02)*864e5);
            document.cookie=cookie+"="+escape($("#mktoGate form:first").attr("data-uid"))+"/"+$("#mktoGate select.country").val()+"; path=/; expires="+expire.toGMTString();
         }
         var aoi=$("#mktoGate label.cu input:checked").val();
         if (aoi) {
             optin.contact();
             window.open($("#mktoGate form:first").attr("action"));
         }
         else if ($('.gatePoint #mktoGate').length) {
         	$(".gatePoint").addClass('closed').nextAll("div").show();
         } else {
         	window.location.replace($("#mktoGate form:first").attr("action"));
         }
     }
     return false;
 }

 // shadow form loaded, set values and submit
 this.shadowLoad = function(form) {
	    var val={};
        $("#mktoGate form:first [name]").each(function(i,v) {
        	if ($(v).is(":checked,:not(:checkbox):not(:radio)")) {
            	var d=$(v).val();
                if (d.match(/[一-龠]+|[ぁ-ゔ]+|[ァ-ヴー]+/) && $(v).attr("data-xg")) {
                	val[$(v).attr("data-xg")]=d;
                } else { val[$(v).attr("name")]=d; }
            } else if (!val[$(v).attr("name")]) {
                    val[$(v).attr("name")]="";
            }
	    });
        if (val.privacy || val.Country=="us") {
        	val.mktoFormOptIn="yes";
            val["mktoCheckbox_83405_0"]="yes";
            val["mktoCheckbox_12736_0"]="yes";
            if (!val.zCSMKTOGDPROptIn) { val.zCSMKTOGDPROptIn="Yes"; }
        }
        val.Country=($("#mktoGate select.country option:selected").attr("data-name")||"USA").replace(/United States$/,"USA");
        val.zCSMKTOGDPROptInStatus=val.zCSMKTOGDPROptIn;
     	val["mktoformoriginalASSET"]=$(softURL).attr("href").replace(/\/T[0-9a-f]{1,4}\//,"/");
     	val["mktofromlastAssetURL"]="www.verizon.com"+$(softURL).attr("href").replace(/\/T[0-9a-f]{1,4}\//,"/");
     	val['mktoformlastAssetTitle']=$(softURL).attr('data-title');
     	val['mktoformlastAssetType']=$(softURL).attr('data-type');
  	 	val['mktoformlastAssetProduct']=$(softURL).attr('data-product');
        if ($(softURL).attr('data-img')) { val['mktoformlastAssetImage']=window.location.origin+$(softURL).attr('data-img'); }
      	try { val['mktoformlastAssetDateTime']=new Date().toDateString().substr(4,20);} catch(e) {}
     	try {
         var utm = Bert.profile.utm || {};
         if (utm.source) { val['mktoformlastSOURCE']=utm.source; }
         if (utm.medium) { val['mktoformlastMEDIUM']=utm.medium; }
         if (utm.campaign) { val['mktoformlastCAMPAIGN']=utm.campaign; }
         if (utm.content) { val['mktoformlastCONTENT']=utm.content; }
            if (utm.sid) { val['zCSSID']=utm.sid; }
            if (utm) { val['zCSCMP'] = Bert.cmp(); }
     	} catch (e) {}
    	form.setValues(val);
        form.onSuccess(optin.shadowDone);
        setTimeout(optin.shadowDone,8000); // if submit fails
	    optin.vzboptin(val);
        form.submit();
	}

 // setup shadown form handlers
 this.shadowHandler = function() {
    $("#mktoGate select.country").on("change.gate",function(e) {
		var c=$(this).val();
        if (c=='us') {
        	$("#mktoGate span.privacy").removeClass("gdpr").addClass("us");
            $("#mktoGate span.privacy input,#mktoGate span.privacy select").prop("required",false);
        } else if (gdpr[c]) {
        	$("#mktoGate span.privacy").removeClass("us").addClass("gdpr");
            $("#mktoGate span.privacy input,#mktoGate span.privacy select").prop("required",true);
        } else {
        	$("#mktoGate span.privacy").removeClass("us gdpr");
            $("#mktoGate span.privacy input,#mktoGate span.privacy select").prop("required",true);
        }
      }).trigger("change.gate");
     $("#mktoGate input.email:first").on("change.gate",function(e){
		var d = ($(this).val() || "").replace(/.+@/,"");
         if (d.endsWith(".edu") || d.endsWith(".gov") || d.endsWith(".mil")) {
             $("#mktoGate form:first label.ps input").prop("checked",true);
             $("#mktoGate form:first label.ps select").val("pub");
         }
     });
    $("#mktoGate form:first").off("submit.gate").on("submit.gate",function(e) {
        e.preventDefault();
        var type=$("#mktoGate form:first label.ps select").val() || $(this).attr("data-lang") || "ent";
        if ($("#mktoGate form:first label.ps input:checked").length) { type="pub"; }
        if (type=="vzw" && $("#mktoGate select.country").val()!="us") { type="ent"; } // smb us only
		var shad=$("#mktoGate form.shadow").empty();
        shad.attr("data-mkto",shadow[type].acct).attr("id","mktoForm_"+shadow[type].id);
		$("#mktoGate .ctas button:first").addClass("loading");
        MktoForms2.loadForm(shadow[type].host,shadow[type].acct,shadow[type].id, optin.shadowLoad);
        if (optin.debug) { shad.show(); }
        setTimeout(optin.shadowDone,12000); // what if it never loads
    });
    var aoi=$("#mktoGate label.cu input").val();
     if (aoi && typeof(Bert)!=null) {
         Bert.addInterest("topic",aoi);
	     $("#mktoGate a.nothanks").on("click.gate",optin.contact);
     }
 }

 // if iframe PDF didn't open
 this.iframeFallback=function() {
  if ($('.fancybox-loading, .fancybox-iframe').length) {
   $.fancybox.close();
   if ($(softURL).attr('href')) {
    window.location = $(softURL).attr('href');
   }
  }
 }

 // pre-submission check
 this.mktoCheck=function(form) {
     if (!$(".mktoForm input[name='mktoFormOptIn']").length) { form.addHiddenFields({"mktoFormOptIn":"yes"}); }
     if (!$("#zCSMKTOGDPROptIn").length) { form.addHiddenFields({"zCSMKTOGDPROptIn":"Yes"}); }
 }

 // marketo submited
 this.mktoSubmit=function(val,url) {
  var cb; // callback
  var href=$(softURL).attr('href');
  var embed=$(softURL).attr('data-fancybox-href') || $('#mktoGate a.register').attr('data-fancybox-href');
  optin.done=1;
  if (val) {
   var expire=new Date(); expire.setTime(expire.getTime()+(180*24*60*60*1000));
   document.cookie="mkt_form="+($('#mktoGate form').attr('id').substr(9) || true)+"; path=/; expires="+expire.toGMTString();
  }
  if ($('#mktoGate div.thanks').length && type=="Hard Gate") {
     $('#mktoGate').addClass("done"); // show message
  }
  else if (embed) {
   $.fancybox.close(); $.fancybox.open({src:embed,type:$(softURL).attr('data-fancybox-type') || "ajax"});
  } else if ($('#mktoGate .thanks').length) { // gate page, just show message
	$(".gatePoint").addClass('closed').nextAll("div").show();
      if ($(".gatePoint .confirm").length) { $.fancybox.open({src:"#mktoGate .confirm"}); setTimeout("$.fancybox.close()",5000); }
  } else if (href && href.indexOf(".pdf")>0) {
   $.fancybox.close(); $.fancybox.open({src:href,type:"iframe",padding:0});
   cb=optin.iframeFallback;
  } else {
   //cb=function() { window.location = $(softURL).attr('href'); }
  }
  if (val) {
   form=$('#mktoGate form');
   val.formid=1172;
   thankspath="fancybox";
   optin.vzboptin(val,cb);
   if (typeof(_satellite)!="undefined") {
       _satellite.track((type=="Hard Gate" ? "hardGate" : "softGate"),{formName:type+" Form",pdfFilePath:href});
   }
  } else if (cb) { cb(); }
  return false;
 }

 // submit to vz
 this.vzboptin=function(data,callback) {
     var vzdata={Country:data["Country"],Industry:data["Industry"],type:type,asset:$(softURL).attr('href'),page:window.location.pathname,referrer:document.referrer};
     try {
         if (Bert.profile.utm.source) { vzdata.source=Bert.profile.utm.source; }
         if (Bert.profile.utm.medium) { vzdata.medium=Bert.profile.utm.medium; }
         if (Bert.profile.utm.campaign) { vzdata.campaign=Bert.profile.utm.campaign; }
     }	catch (e) {}
     if (data["Country"]=="USA") { ctry="us"; } else { ctry = ctry || "xg"; }
     var consent=(data["zCSMKTOGDPROptIn"]=="Yes" || data["zCSMKTOGDPROptInStatus"]=="Yes" ? true : false);
     $.ajax({url:["",(window.location.pathname.indexOf("/business") ? "bin" : "business/bin"),"submit","optin",""].join("/"),type:"POST",data:vzdata,dataType:"json",cache:false,timeout:15000,success:function(data) { // headers:{"CSRF-Token":csrf}
        optin.success(data.submitted || data.response,consent);
    	if (typeof(callback)=="function") { callback(data.response); }
   },error:function(req,status,msg){
    if (typeof(callback)=="function") { callback(false); }
     $('#mktoGate a.loading').removeClass('loading');
     $('#mktoGate').addClass("done error");
   }
  });
 }


  // submit callback
 this.success=function(i,c) {
  if (i) {
   var expire=new Date();
      expire.setTime(expire.getTime()+(c ? 2*365*86400 : 120)*1000);
   document.cookie=cookie+"="+escape(i)+"/"+ctry+"; path=/; "+(window.location.hostname.indexOf('verizon')>=0 ? "expires="+expire.toGMTString() : "");
  }
  if (optin.debug) { console.log("Success "+i); }
  optin.done=2;
  $('#mktoGate a.loading').removeClass('loading');
     $('#mktoGate').addClass("done");
     $('#mktoGate>ul.c2').addClass("c3").removeClass("c2");
     if ($('#mktoGate div.thanks').length) {
         // just show message
     }
  else if (typeof($.fancybox)!="undefined") {
   if ($(softURL).hasClass('fancybox') || thankspath=="fancybox") { // already opened
   } else {
    if (thankspath && thankspath.indexOf(".xml") > 0 ) {thanksfile = thankspath} else {thanksfile = path+"thanks.html"+lang;}
    $.fancybox.close(); $.fancybox.open({type:"ajax",src:thanksfile});
    if (dataclose == 0) {
    } else {
     setTimeout("$.fancybox.close()",10000);
    }
   }
  }
  if (typeof(vztrackevent)!="undefined") { vztrackevent(vzb.section,'Formdata',vzb.subsection,type,'Opted In'); }
  //if (type == 'Soft Gate') { optin.softlink() }
  //else if (type == 'Media' && media) { $(media).get()[0].play(); }
 }

 // window closed
 this.closed=function(res) {
  $(window).off('.optin');
  if (optin.done) { return true; }
  // log closed
  optin.done=-1;
  return true;
 }


 if (typeof($.noop)!="undefined") {
  $(document).ready(optin.handler);
 } else if (optin.debug) { console.log("No jQuery"); }
 return optin;
};
// ==================================================
// fancyBox v3.5.7
//
// Licensed GPLv3 for open source use
// or fancyBox Commercial License for commercial use
//
// http://fancyapps.com/fancybox/
// Copyright 2019 fancyApps
//
// ==================================================
!function(t,e,n,o){"use strict";function i(t,e){var o,i,a,s=[],r=0;t&&t.isDefaultPrevented()||(t.preventDefault(),e=e||{},t&&t.data&&(e=h(t.data.options,e)),o=e.$target||n(t.currentTarget).trigger("blur"),(a=n.fancybox.getInstance())&&a.$trigger&&a.$trigger.is(o)||(e.selector?s=n(e.selector):(i=o.attr("data-fancybox")||"",i?(s=t.data?t.data.items:[],s=s.length?s.filter('[data-fancybox="'+i+'"]'):n('[data-fancybox="'+i+'"]')):s=[o]),r=n(s).index(o),r<0&&(r=0),a=n.fancybox.open(s,e,r),a.$trigger=o))}if(t.console=t.console||{info:function(t){}},n){if(n.fn.fancybox)return void console.info("fancyBox already initialized");var a={closeExisting:!1,loop:!1,gutter:50,keyboard:!0,preventCaptionOverlap:!0,arrows:!0,infobar:!0,smallBtn:"auto",toolbar:"auto",buttons:["zoom","slideShow","thumbs","close"],idleTime:3,protect:!1,modal:!1,image:{preload:!1},ajax:{settings:{data:{fancybox:!0}}},iframe:{tpl:'<iframe id="fancybox-frame{rnd}" name="fancybox-frame{rnd}" class="fancybox-iframe" allowfullscreen="allowfullscreen" allow="autoplay; fullscreen" src=""></iframe>',preload:!0,css:{},attr:{scrolling:"auto"}},video:{tpl:'<video class="fancybox-video" controls controlsList="nodownload" poster="{{poster}}"><source src="{{src}}" type="{{format}}" />Sorry, your browser doesn\'t support embedded videos, <a href="{{src}}">download</a> and watch with your favorite video player!</video>',format:"",autoStart:!0},defaultType:"image",animationEffect:"zoom",animationDuration:366,zoomOpacity:"auto",transitionEffect:"fade",transitionDuration:366,slideClass:"",baseClass:"",baseTpl:'<div class="fancybox-container" role="dialog" tabindex="-1"><div class="fancybox-bg"></div><div class="fancybox-inner"><div class="fancybox-infobar"><span data-fancybox-index></span>&nbsp;/&nbsp;<span data-fancybox-count></span></div><div class="fancybox-toolbar">{{buttons}}</div><div class="fancybox-navigation">{{arrows}}</div><div class="fancybox-stage"></div><div class="fancybox-caption"><div class="fancybox-caption__body"></div></div></div></div>',spinnerTpl:'<div class="fancybox-loading"></div>',errorTpl:'<div class="fancybox-error"><p>{{ERROR}}</p></div>',btnTpl:{download:'<a download data-fancybox-download class="fancybox-button fancybox-button--download" title="{{DOWNLOAD}}" href="javascript:;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M18.62 17.09V19H5.38v-1.91zm-2.97-6.96L17 11.45l-5 4.87-5-4.87 1.36-1.32 2.68 2.64V5h1.92v7.77z"/></svg></a>',zoom:'<button data-fancybox-zoom class="fancybox-button fancybox-button--zoom" title="{{ZOOM}}"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M18.7 17.3l-3-3a5.9 5.9 0 0 0-.6-7.6 5.9 5.9 0 0 0-8.4 0 5.9 5.9 0 0 0 0 8.4 5.9 5.9 0 0 0 7.7.7l3 3a1 1 0 0 0 1.3 0c.4-.5.4-1 0-1.5zM8.1 13.8a4 4 0 0 1 0-5.7 4 4 0 0 1 5.7 0 4 4 0 0 1 0 5.7 4 4 0 0 1-5.7 0z"/></svg></button>',close:'<button data-fancybox-close class="fancybox-button fancybox-button--close" title="{{CLOSE}}"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12 10.6L6.6 5.2 5.2 6.6l5.4 5.4-5.4 5.4 1.4 1.4 5.4-5.4 5.4 5.4 1.4-1.4-5.4-5.4 5.4-5.4-1.4-1.4-5.4 5.4z"/></svg></button>',arrowLeft:'<button data-fancybox-prev class="fancybox-button fancybox-button--arrow_left" title="{{PREV}}"><div><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M11.28 15.7l-1.34 1.37L5 12l4.94-5.07 1.34 1.38-2.68 2.72H19v1.94H8.6z"/></svg></div></button>',arrowRight:'<button data-fancybox-next class="fancybox-button fancybox-button--arrow_right" title="{{NEXT}}"><div><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M15.4 12.97l-2.68 2.72 1.34 1.38L19 12l-4.94-5.07-1.34 1.38 2.68 2.72H5v1.94z"/></svg></div></button>',smallBtn:'<button type="button" data-fancybox-close class="fancybox-button fancybox-close-small" title="{{CLOSE}}"><svg xmlns="http://www.w3.org/2000/svg" version="1" viewBox="0 0 24 24"><path d="M13 12l5-5-1-1-5 5-5-5-1 1 5 5-5 5 1 1 5-5 5 5 1-1z"/></svg></button>'},parentEl:"body",hideScrollbar:!0,autoFocus:!0,backFocus:!0,trapFocus:!0,fullScreen:{autoStart:!1},touch:{vertical:!0,momentum:!0},hash:null,media:{},slideShow:{autoStart:!1,speed:3e3},thumbs:{autoStart:!1,hideOnClose:!0,parentEl:".fancybox-container",axis:"y"},wheel:"auto",onInit:n.noop,beforeLoad:n.noop,afterLoad:n.noop,beforeShow:n.noop,afterShow:n.noop,beforeClose:n.noop,afterClose:n.noop,onActivate:n.noop,onDeactivate:n.noop,clickContent:function(t,e){return"image"===t.type&&"zoom"},clickSlide:"close",clickOutside:"close",dblclickContent:!1,dblclickSlide:!1,dblclickOutside:!1,mobile:{preventCaptionOverlap:!1,idleTime:!1,clickContent:function(t,e){return"image"===t.type&&"toggleControls"},clickSlide:function(t,e){return"image"===t.type?"toggleControls":"close"},dblclickContent:function(t,e){return"image"===t.type&&"zoom"},dblclickSlide:function(t,e){return"image"===t.type&&"zoom"}},lang:"en",i18n:{en:{CLOSE:"Close",NEXT:"Next",PREV:"Previous",ERROR:"The requested content cannot be loaded. <br/> Please try again later.",PLAY_START:"Start slideshow",PLAY_STOP:"Pause slideshow",FULL_SCREEN:"Full screen",THUMBS:"Thumbnails",DOWNLOAD:"Download",SHARE:"Share",ZOOM:"Zoom"},de:{CLOSE:"Schlie&szlig;en",NEXT:"Weiter",PREV:"Zur&uuml;ck",ERROR:"Die angeforderten Daten konnten nicht geladen werden. <br/> Bitte versuchen Sie es sp&auml;ter nochmal.",PLAY_START:"Diaschau starten",PLAY_STOP:"Diaschau beenden",FULL_SCREEN:"Vollbild",THUMBS:"Vorschaubilder",DOWNLOAD:"Herunterladen",SHARE:"Teilen",ZOOM:"Vergr&ouml;&szlig;ern"}}},s=n(t),r=n(e),c=0,l=function(t){return t&&t.hasOwnProperty&&t instanceof n},d=function(){return t.requestAnimationFrame||t.webkitRequestAnimationFrame||t.mozRequestAnimationFrame||t.oRequestAnimationFrame||function(e){return t.setTimeout(e,1e3/60)}}(),u=function(){return t.cancelAnimationFrame||t.webkitCancelAnimationFrame||t.mozCancelAnimationFrame||t.oCancelAnimationFrame||function(e){t.clearTimeout(e)}}(),f=function(){var t,n=e.createElement("fakeelement"),o={transition:"transitionend",OTransition:"oTransitionEnd",MozTransition:"transitionend",WebkitTransition:"webkitTransitionEnd"};for(t in o)if(void 0!==n.style[t])return o[t];return"transitionend"}(),p=function(t){return t&&t.length&&t[0].offsetHeight},h=function(t,e){var o=n.extend(!0,{},t,e);return n.each(e,function(t,e){n.isArray(e)&&(o[t]=e)}),o},g=function(t){var o,i;return!(!t||t.ownerDocument!==e)&&(n(".fancybox-container").css("pointer-events","none"),o={x:t.getBoundingClientRect().left+t.offsetWidth/2,y:t.getBoundingClientRect().top+t.offsetHeight/2},i=e.elementFromPoint(o.x,o.y)===t,n(".fancybox-container").css("pointer-events",""),i)},b=function(t,e,o){var i=this;i.opts=h({index:o},n.fancybox.defaults),n.isPlainObject(e)&&(i.opts=h(i.opts,e)),n.fancybox.isMobile&&(i.opts=h(i.opts,i.opts.mobile)),i.id=i.opts.id||++c,i.currIndex=parseInt(i.opts.index,10)||0,i.prevIndex=null,i.prevPos=null,i.currPos=0,i.firstRun=!0,i.group=[],i.slides={},i.addContent(t),i.group.length&&i.init()};n.extend(b.prototype,{init:function(){var o,i,a=this,s=a.group[a.currIndex],r=s.opts;r.closeExisting&&n.fancybox.close(!0),n("body").addClass("fancybox-active"),!n.fancybox.getInstance()&&!1!==r.hideScrollbar&&!n.fancybox.isMobile&&e.body.scrollHeight>t.innerHeight&&(n("head").append('<style id="fancybox-style-noscroll" type="text/css">.compensate-for-scrollbar{margin-right:'+(t.innerWidth-e.documentElement.clientWidth)+"px;}</style>"),n("body").addClass("compensate-for-scrollbar")),i="",n.each(r.buttons,function(t,e){i+=r.btnTpl[e]||""}),o=n(a.translate(a,r.baseTpl.replace("{{buttons}}",i).replace("{{arrows}}",r.btnTpl.arrowLeft+r.btnTpl.arrowRight))).attr("id","fancybox-container-"+a.id).addClass(r.baseClass).data("FancyBox",a).appendTo(r.parentEl),a.$refs={container:o},["bg","inner","infobar","toolbar","stage","caption","navigation"].forEach(function(t){a.$refs[t]=o.find(".fancybox-"+t)}),a.trigger("onInit"),a.activate(),a.jumpTo(a.currIndex)},translate:function(t,e){var n=t.opts.i18n[t.opts.lang]||t.opts.i18n.en;return e.replace(/\{\{(\w+)\}\}/g,function(t,e){return void 0===n[e]?t:n[e]})},addContent:function(t){var e,o=this,i=n.makeArray(t);n.each(i,function(t,e){var i,a,s,r,c,l={},d={};n.isPlainObject(e)?(l=e,d=e.opts||e):"object"===n.type(e)&&n(e).length?(i=n(e),d=i.data()||{},d=n.extend(!0,{},d,d.options),d.$orig=i,l.src=o.opts.src||d.src||i.attr("href"),l.type||l.src||(l.type="inline",l.src=e)):l={type:"html",src:e+""},l.opts=n.extend(!0,{},o.opts,d),n.isArray(d.buttons)&&(l.opts.buttons=d.buttons),n.fancybox.isMobile&&l.opts.mobile&&(l.opts=h(l.opts,l.opts.mobile)),a=l.type||l.opts.type,r=l.src||"",!a&&r&&((s=r.match(/\.(mp4|mov|ogv|webm)((\?|#).*)?$/i))?(a="video",l.opts.video.format||(l.opts.video.format="video/"+("ogv"===s[1]?"ogg":s[1]))):r.match(/(^data:image\/[a-z0-9+\/=]*,)|(\.(jp(e|g|eg)|gif|png|bmp|webp|svg|ico)((\?|#).*)?$)/i)?a="image":r.match(/\.(pdf)((\?|#).*)?$/i)?(a="iframe",l=n.extend(!0,l,{contentType:"pdf",opts:{iframe:{preload:!1}}})):"#"===r.charAt(0)&&(a="inline")),a?l.type=a:o.trigger("objectNeedsType",l),l.contentType||(l.contentType=n.inArray(l.type,["html","inline","ajax"])>-1?"html":l.type),l.index=o.group.length,"auto"==l.opts.smallBtn&&(l.opts.smallBtn=n.inArray(l.type,["html","inline","ajax"])>-1),"auto"===l.opts.toolbar&&(l.opts.toolbar=!l.opts.smallBtn),l.$thumb=l.opts.$thumb||null,l.opts.$trigger&&l.index===o.opts.index&&(l.$thumb=l.opts.$trigger.find("img:first"),l.$thumb.length&&(l.opts.$orig=l.opts.$trigger)),l.$thumb&&l.$thumb.length||!l.opts.$orig||(l.$thumb=l.opts.$orig.find("img:first")),l.$thumb&&!l.$thumb.length&&(l.$thumb=null),l.thumb=l.opts.thumb||(l.$thumb?l.$thumb[0].src:null),"function"===n.type(l.opts.caption)&&(l.opts.caption=l.opts.caption.apply(e,[o,l])),"function"===n.type(o.opts.caption)&&(l.opts.caption=o.opts.caption.apply(e,[o,l])),l.opts.caption instanceof n||(l.opts.caption=void 0===l.opts.caption?"":l.opts.caption+""),"ajax"===l.type&&(c=r.split(/\s+/,2),c.length>1&&(l.src=c.shift(),l.opts.filter=c.shift())),l.opts.modal&&(l.opts=n.extend(!0,l.opts,{trapFocus:!0,infobar:0,toolbar:0,smallBtn:0,keyboard:0,slideShow:0,fullScreen:0,thumbs:0,touch:0,clickContent:!1,clickSlide:!1,clickOutside:!1,dblclickContent:!1,dblclickSlide:!1,dblclickOutside:!1})),o.group.push(l)}),Object.keys(o.slides).length&&(o.updateControls(),(e=o.Thumbs)&&e.isActive&&(e.create(),e.focus()))},addEvents:function(){var e=this;e.removeEvents(),e.$refs.container.on("click.fb-close","[data-fancybox-close]",function(t){t.stopPropagation(),t.preventDefault(),e.close(t)}).on("touchstart.fb-prev click.fb-prev","[data-fancybox-prev]",function(t){t.stopPropagation(),t.preventDefault(),e.previous()}).on("touchstart.fb-next click.fb-next","[data-fancybox-next]",function(t){t.stopPropagation(),t.preventDefault(),e.next()}).on("click.fb","[data-fancybox-zoom]",function(t){e[e.isScaledDown()?"scaleToActual":"scaleToFit"]()}),s.on("orientationchange.fb resize.fb",function(t){t&&t.originalEvent&&"resize"===t.originalEvent.type?(e.requestId&&u(e.requestId),e.requestId=d(function(){e.update(t)})):(e.current&&"iframe"===e.current.type&&e.$refs.stage.hide(),setTimeout(function(){e.$refs.stage.show(),e.update(t)},n.fancybox.isMobile?600:250))}),r.on("keydown.fb",function(t){var o=n.fancybox?n.fancybox.getInstance():null,i=o.current,a=t.keyCode||t.which;if(9==a)return void(i.opts.trapFocus&&e.focus(t));if(!(!i.opts.keyboard||t.ctrlKey||t.altKey||t.shiftKey||n(t.target).is("input,textarea,video,audio,select")))return 8===a||27===a?(t.preventDefault(),void e.close(t)):37===a||38===a?(t.preventDefault(),void e.previous()):39===a||40===a?(t.preventDefault(),void e.next()):void e.trigger("afterKeydown",t,a)}),e.group[e.currIndex].opts.idleTime&&(e.idleSecondsCounter=0,r.on("mousemove.fb-idle mouseleave.fb-idle mousedown.fb-idle touchstart.fb-idle touchmove.fb-idle scroll.fb-idle keydown.fb-idle",function(t){e.idleSecondsCounter=0,e.isIdle&&e.showControls(),e.isIdle=!1}),e.idleInterval=t.setInterval(function(){++e.idleSecondsCounter>=e.group[e.currIndex].opts.idleTime&&!e.isDragging&&(e.isIdle=!0,e.idleSecondsCounter=0,e.hideControls())},1e3))},removeEvents:function(){var e=this;s.off("orientationchange.fb resize.fb"),r.off("keydown.fb .fb-idle"),this.$refs.container.off(".fb-close .fb-prev .fb-next"),e.idleInterval&&(t.clearInterval(e.idleInterval),e.idleInterval=null)},previous:function(t){return this.jumpTo(this.currPos-1,t)},next:function(t){return this.jumpTo(this.currPos+1,t)},jumpTo:function(t,e){var o,i,a,s,r,c,l,d,u,f=this,h=f.group.length;if(!(f.isDragging||f.isClosing||f.isAnimating&&f.firstRun)){if(t=parseInt(t,10),!(a=f.current?f.current.opts.loop:f.opts.loop)&&(t<0||t>=h))return!1;if(o=f.firstRun=!Object.keys(f.slides).length,r=f.current,f.prevIndex=f.currIndex,f.prevPos=f.currPos,s=f.createSlide(t),h>1&&((a||s.index<h-1)&&f.createSlide(t+1),(a||s.index>0)&&f.createSlide(t-1)),f.current=s,f.currIndex=s.index,f.currPos=s.pos,f.trigger("beforeShow",o),f.updateControls(),s.forcedDuration=void 0,n.isNumeric(e)?s.forcedDuration=e:e=s.opts[o?"animationDuration":"transitionDuration"],e=parseInt(e,10),i=f.isMoved(s),s.$slide.addClass("fancybox-slide--current"),o)return s.opts.animationEffect&&e&&f.$refs.container.css("transition-duration",e+"ms"),f.$refs.container.addClass("fancybox-is-open").trigger("focus"),f.loadSlide(s),void f.preload("image");c=n.fancybox.getTranslate(r.$slide),l=n.fancybox.getTranslate(f.$refs.stage),n.each(f.slides,function(t,e){n.fancybox.stop(e.$slide,!0)}),r.pos!==s.pos&&(r.isComplete=!1),r.$slide.removeClass("fancybox-slide--complete fancybox-slide--current"),i?(u=c.left-(r.pos*c.width+r.pos*r.opts.gutter),n.each(f.slides,function(t,o){o.$slide.removeClass("fancybox-animated").removeClass(function(t,e){return(e.match(/(^|\s)fancybox-fx-\S+/g)||[]).join(" ")});var i=o.pos*c.width+o.pos*o.opts.gutter;n.fancybox.setTranslate(o.$slide,{top:0,left:i-l.left+u}),o.pos!==s.pos&&o.$slide.addClass("fancybox-slide--"+(o.pos>s.pos?"next":"previous")),p(o.$slide),n.fancybox.animate(o.$slide,{top:0,left:(o.pos-s.pos)*c.width+(o.pos-s.pos)*o.opts.gutter},e,function(){o.$slide.css({transform:"",opacity:""}).removeClass("fancybox-slide--next fancybox-slide--previous"),o.pos===f.currPos&&f.complete()})})):e&&s.opts.transitionEffect&&(d="fancybox-animated fancybox-fx-"+s.opts.transitionEffect,r.$slide.addClass("fancybox-slide--"+(r.pos>s.pos?"next":"previous")),n.fancybox.animate(r.$slide,d,e,function(){r.$slide.removeClass(d).removeClass("fancybox-slide--next fancybox-slide--previous")},!1)),s.isLoaded?f.revealContent(s):f.loadSlide(s),f.preload("image")}},createSlide:function(t){var e,o,i=this;return o=t%i.group.length,o=o<0?i.group.length+o:o,!i.slides[t]&&i.group[o]&&(e=n('<div class="fancybox-slide"></div>').appendTo(i.$refs.stage),i.slides[t]=n.extend(!0,{},i.group[o],{pos:t,$slide:e,isLoaded:!1}),i.updateSlide(i.slides[t])),i.slides[t]},scaleToActual:function(t,e,o){var i,a,s,r,c,l=this,d=l.current,u=d.$content,f=n.fancybox.getTranslate(d.$slide).width,p=n.fancybox.getTranslate(d.$slide).height,h=d.width,g=d.height;l.isAnimating||l.isMoved()||!u||"image"!=d.type||!d.isLoaded||d.hasError||(l.isAnimating=!0,n.fancybox.stop(u),t=void 0===t?.5*f:t,e=void 0===e?.5*p:e,i=n.fancybox.getTranslate(u),i.top-=n.fancybox.getTranslate(d.$slide).top,i.left-=n.fancybox.getTranslate(d.$slide).left,r=h/i.width,c=g/i.height,a=.5*f-.5*h,s=.5*p-.5*g,h>f&&(a=i.left*r-(t*r-t),a>0&&(a=0),a<f-h&&(a=f-h)),g>p&&(s=i.top*c-(e*c-e),s>0&&(s=0),s<p-g&&(s=p-g)),l.updateCursor(h,g),n.fancybox.animate(u,{top:s,left:a,scaleX:r,scaleY:c},o||366,function(){l.isAnimating=!1}),l.SlideShow&&l.SlideShow.isActive&&l.SlideShow.stop())},scaleToFit:function(t){var e,o=this,i=o.current,a=i.$content;o.isAnimating||o.isMoved()||!a||"image"!=i.type||!i.isLoaded||i.hasError||(o.isAnimating=!0,n.fancybox.stop(a),e=o.getFitPos(i),o.updateCursor(e.width,e.height),n.fancybox.animate(a,{top:e.top,left:e.left,scaleX:e.width/a.width(),scaleY:e.height/a.height()},t||366,function(){o.isAnimating=!1}))},getFitPos:function(t){var e,o,i,a,s=this,r=t.$content,c=t.$slide,l=t.width||t.opts.width,d=t.height||t.opts.height,u={};return!!(t.isLoaded&&r&&r.length)&&(e=n.fancybox.getTranslate(s.$refs.stage).width,o=n.fancybox.getTranslate(s.$refs.stage).height,e-=parseFloat(c.css("paddingLeft"))+parseFloat(c.css("paddingRight"))+parseFloat(r.css("marginLeft"))+parseFloat(r.css("marginRight")),o-=parseFloat(c.css("paddingTop"))+parseFloat(c.css("paddingBottom"))+parseFloat(r.css("marginTop"))+parseFloat(r.css("marginBottom")),l&&d||(l=e,d=o),i=Math.min(1,e/l,o/d),l*=i,d*=i,l>e-.5&&(l=e),d>o-.5&&(d=o),"image"===t.type?(u.top=Math.floor(.5*(o-d))+parseFloat(c.css("paddingTop")),u.left=Math.floor(.5*(e-l))+parseFloat(c.css("paddingLeft"))):"video"===t.contentType&&(a=t.opts.width&&t.opts.height?l/d:t.opts.ratio||16/9,d>l/a?d=l/a:l>d*a&&(l=d*a)),u.width=l,u.height=d,u)},update:function(t){var e=this;n.each(e.slides,function(n,o){e.updateSlide(o,t)})},updateSlide:function(t,e){var o=this,i=t&&t.$content,a=t.width||t.opts.width,s=t.height||t.opts.height,r=t.$slide;o.adjustCaption(t),i&&(a||s||"video"===t.contentType)&&!t.hasError&&(n.fancybox.stop(i),n.fancybox.setTranslate(i,o.getFitPos(t)),t.pos===o.currPos&&(o.isAnimating=!1,o.updateCursor())),o.adjustLayout(t),r.length&&(r.trigger("refresh"),t.pos===o.currPos&&o.$refs.toolbar.add(o.$refs.navigation.find(".fancybox-button--arrow_right")).toggleClass("compensate-for-scrollbar",r.get(0).scrollHeight>r.get(0).clientHeight)),o.trigger("onUpdate",t,e)},centerSlide:function(t){var e=this,o=e.current,i=o.$slide;!e.isClosing&&o&&(i.siblings().css({transform:"",opacity:""}),i.parent().children().removeClass("fancybox-slide--previous fancybox-slide--next"),n.fancybox.animate(i,{top:0,left:0,opacity:1},void 0===t?0:t,function(){i.css({transform:"",opacity:""}),o.isComplete||e.complete()},!1))},isMoved:function(t){var e,o,i=t||this.current;return!!i&&(o=n.fancybox.getTranslate(this.$refs.stage),e=n.fancybox.getTranslate(i.$slide),!i.$slide.hasClass("fancybox-animated")&&(Math.abs(e.top-o.top)>.5||Math.abs(e.left-o.left)>.5))},updateCursor:function(t,e){var o,i,a=this,s=a.current,r=a.$refs.container;s&&!a.isClosing&&a.Guestures&&(r.removeClass("fancybox-is-zoomable fancybox-can-zoomIn fancybox-can-zoomOut fancybox-can-swipe fancybox-can-pan"),o=a.canPan(t,e),i=!!o||a.isZoomable(),r.toggleClass("fancybox-is-zoomable",i),n("[data-fancybox-zoom]").prop("disabled",!i),o?r.addClass("fancybox-can-pan"):i&&("zoom"===s.opts.clickContent||n.isFunction(s.opts.clickContent)&&"zoom"==s.opts.clickContent(s))?r.addClass("fancybox-can-zoomIn"):s.opts.touch&&(s.opts.touch.vertical||a.group.length>1)&&"video"!==s.contentType&&r.addClass("fancybox-can-swipe"))},isZoomable:function(){var t,e=this,n=e.current;if(n&&!e.isClosing&&"image"===n.type&&!n.hasError){if(!n.isLoaded)return!0;if((t=e.getFitPos(n))&&(n.width>t.width||n.height>t.height))return!0}return!1},isScaledDown:function(t,e){var o=this,i=!1,a=o.current,s=a.$content;return void 0!==t&&void 0!==e?i=t<a.width&&e<a.height:s&&(i=n.fancybox.getTranslate(s),i=i.width<a.width&&i.height<a.height),i},canPan:function(t,e){var o=this,i=o.current,a=null,s=!1;return"image"===i.type&&(i.isComplete||t&&e)&&!i.hasError&&(s=o.getFitPos(i),void 0!==t&&void 0!==e?a={width:t,height:e}:i.isComplete&&(a=n.fancybox.getTranslate(i.$content)),a&&s&&(s=Math.abs(a.width-s.width)>1.5||Math.abs(a.height-s.height)>1.5)),s},loadSlide:function(t){var e,o,i,a=this;if(!t.isLoading&&!t.isLoaded){if(t.isLoading=!0,!1===a.trigger("beforeLoad",t))return t.isLoading=!1,!1;switch(e=t.type,o=t.$slide,o.off("refresh").trigger("onReset").addClass(t.opts.slideClass),e){case"image":a.setImage(t);break;case"iframe":a.setIframe(t);break;case"html":a.setContent(t,t.src||t.content);break;case"video":a.setContent(t,t.opts.video.tpl.replace(/\{\{src\}\}/gi,t.src).replace("{{format}}",t.opts.videoFormat||t.opts.video.format||"").replace("{{poster}}",t.thumb||""));break;case"inline":n(t.src).length?a.setContent(t,n(t.src)):a.setError(t);break;case"ajax":a.showLoading(t),i=n.ajax(n.extend({},t.opts.ajax.settings,{url:t.src,success:function(e,n){"success"===n&&a.setContent(t,e)},error:function(e,n){e&&"abort"!==n&&a.setError(t)}})),o.one("onReset",function(){i.abort()});break;default:a.setError(t)}return!0}},setImage:function(t){var o,i=this;setTimeout(function(){var e=t.$image;i.isClosing||!t.isLoading||e&&e.length&&e[0].complete||t.hasError||i.showLoading(t)},50),i.checkSrcset(t),t.$content=n('<div class="fancybox-content"></div>').addClass("fancybox-is-hidden").appendTo(t.$slide.addClass("fancybox-slide--image")),!1!==t.opts.preload&&t.opts.width&&t.opts.height&&t.thumb&&(t.width=t.opts.width,t.height=t.opts.height,o=e.createElement("img"),o.onerror=function(){n(this).remove(),t.$ghost=null},o.onload=function(){i.afterLoad(t)},t.$ghost=n(o).addClass("fancybox-image").appendTo(t.$content).attr("src",t.thumb)),i.setBigImage(t)},checkSrcset:function(e){var n,o,i,a,s=e.opts.srcset||e.opts.image.srcset;if(s){i=t.devicePixelRatio||1,a=t.innerWidth*i,o=s.split(",").map(function(t){var e={};return t.trim().split(/\s+/).forEach(function(t,n){var o=parseInt(t.substring(0,t.length-1),10);if(0===n)return e.url=t;o&&(e.value=o,e.postfix=t[t.length-1])}),e}),o.sort(function(t,e){return t.value-e.value});for(var r=0;r<o.length;r++){var c=o[r];if("w"===c.postfix&&c.value>=a||"x"===c.postfix&&c.value>=i){n=c;break}}!n&&o.length&&(n=o[o.length-1]),n&&(e.src=n.url,e.width&&e.height&&"w"==n.postfix&&(e.height=e.width/e.height*n.value,e.width=n.value),e.opts.srcset=s)}},setBigImage:function(t){var o=this,i=e.createElement("img"),a=n(i);t.$image=a.one("error",function(){o.setError(t)}).one("load",function(){var e;t.$ghost||(o.resolveImageSlideSize(t,this.naturalWidth,this.naturalHeight),o.afterLoad(t)),o.isClosing||(t.opts.srcset&&(e=t.opts.sizes,e&&"auto"!==e||(e=(t.width/t.height>1&&s.width()/s.height()>1?"100":Math.round(t.width/t.height*100))+"vw"),a.attr("sizes",e).attr("srcset",t.opts.srcset)),t.$ghost&&setTimeout(function(){t.$ghost&&!o.isClosing&&t.$ghost.hide()},Math.min(300,Math.max(1e3,t.height/1600))),o.hideLoading(t))}).addClass("fancybox-image").attr("src",t.src).appendTo(t.$content),(i.complete||"complete"==i.readyState)&&a.naturalWidth&&a.naturalHeight?a.trigger("load"):i.error&&a.trigger("error")},resolveImageSlideSize:function(t,e,n){var o=parseInt(t.opts.width,10),i=parseInt(t.opts.height,10);t.width=e,t.height=n,o>0&&(t.width=o,t.height=Math.floor(o*n/e)),i>0&&(t.width=Math.floor(i*e/n),t.height=i)},setIframe:function(t){var e,o=this,i=t.opts.iframe,a=t.$slide;t.$content=n('<div class="fancybox-content'+(i.preload?" fancybox-is-hidden":"")+'"></div>').css(i.css).appendTo(a),a.addClass("fancybox-slide--"+t.contentType),t.$iframe=e=n(i.tpl.replace(/\{rnd\}/g,(new Date).getTime())).attr(i.attr).appendTo(t.$content),i.preload?(o.showLoading(t),e.on("load.fb error.fb",function(e){this.isReady=1,t.$slide.trigger("refresh"),o.afterLoad(t)}),a.on("refresh.fb",function(){var n,o,s=t.$content,r=i.css.width,c=i.css.height;if(1===e[0].isReady){try{n=e.contents(),o=n.find("body")}catch(t){}o&&o.length&&o.children().length&&(a.css("overflow","visible"),s.css({width:"100%","max-width":"100%",height:"9999px"}),void 0===r&&(r=Math.ceil(Math.max(o[0].clientWidth,o.outerWidth(!0)))),s.css("width",r||"").css("max-width",""),void 0===c&&(c=Math.ceil(Math.max(o[0].clientHeight,o.outerHeight(!0)))),s.css("height",c||""),a.css("overflow","auto")),s.removeClass("fancybox-is-hidden")}})):o.afterLoad(t),e.attr("src",t.src),a.one("onReset",function(){try{n(this).find("iframe").hide().unbind().attr("src","//about:blank")}catch(t){}n(this).off("refresh.fb").empty(),t.isLoaded=!1,t.isRevealed=!1})},setContent:function(t,e){var o=this;o.isClosing||(o.hideLoading(t),t.$content&&n.fancybox.stop(t.$content),t.$slide.empty(),l(e)&&e.parent().length?((e.hasClass("fancybox-content")||e.parent().hasClass("fancybox-content"))&&e.parents(".fancybox-slide").trigger("onReset"),t.$placeholder=n("<div>").hide().insertAfter(e),e.css("display","inline-block")):t.hasError||("string"===n.type(e)&&(e=n("<div>").append(n.trim(e)).contents()),t.opts.filter&&(e=n("<div>").html(e).find(t.opts.filter))),t.$slide.one("onReset",function(){n(this).find("video,audio").trigger("pause"),t.$placeholder&&(t.$placeholder.after(e.removeClass("fancybox-content").hide()).remove(),t.$placeholder=null),t.$smallBtn&&(t.$smallBtn.remove(),t.$smallBtn=null),t.hasError||(n(this).empty(),t.isLoaded=!1,t.isRevealed=!1)}),n(e).appendTo(t.$slide),n(e).is("video,audio")&&(n(e).addClass("fancybox-video"),n(e).wrap("<div></div>"),t.contentType="video",t.opts.width=t.opts.width||n(e).attr("width"),t.opts.height=t.opts.height||n(e).attr("height")),t.$content=t.$slide.children().filter("div,form,main,video,audio,article,.fancybox-content").first(),t.$content.siblings().hide(),t.$content.length||(t.$content=t.$slide.wrapInner("<div></div>").children().first()),t.$content.addClass("fancybox-content"),t.$slide.addClass("fancybox-slide--"+t.contentType),o.afterLoad(t))},setError:function(t){t.hasError=!0,t.$slide.trigger("onReset").removeClass("fancybox-slide--"+t.contentType).addClass("fancybox-slide--error"),t.contentType="html",this.setContent(t,this.translate(t,t.opts.errorTpl)),t.pos===this.currPos&&(this.isAnimating=!1)},showLoading:function(t){var e=this;(t=t||e.current)&&!t.$spinner&&(t.$spinner=n(e.translate(e,e.opts.spinnerTpl)).appendTo(t.$slide).hide().fadeIn("fast"))},hideLoading:function(t){var e=this;(t=t||e.current)&&t.$spinner&&(t.$spinner.stop().remove(),delete t.$spinner)},afterLoad:function(t){var e=this;e.isClosing||(t.isLoading=!1,t.isLoaded=!0,e.trigger("afterLoad",t),e.hideLoading(t),!t.opts.smallBtn||t.$smallBtn&&t.$smallBtn.length||(t.$smallBtn=n(e.translate(t,t.opts.btnTpl.smallBtn)).appendTo(t.$content)),t.opts.protect&&t.$content&&!t.hasError&&(t.$content.on("contextmenu.fb",function(t){return 2==t.button&&t.preventDefault(),!0}),"image"===t.type&&n('<div class="fancybox-spaceball"></div>').appendTo(t.$content)),e.adjustCaption(t),e.adjustLayout(t),t.pos===e.currPos&&e.updateCursor(),e.revealContent(t))},adjustCaption:function(t){var e,n=this,o=t||n.current,i=o.opts.caption,a=o.opts.preventCaptionOverlap,s=n.$refs.caption,r=!1;s.toggleClass("fancybox-caption--separate",a),a&&i&&i.length&&(o.pos!==n.currPos?(e=s.clone().appendTo(s.parent()),e.children().eq(0).empty().html(i),r=e.outerHeight(!0),e.empty().remove()):n.$caption&&(r=n.$caption.outerHeight(!0)),o.$slide.css("padding-bottom",r||""))},adjustLayout:function(t){var e,n,o,i,a=this,s=t||a.current;s.isLoaded&&!0!==s.opts.disableLayoutFix&&(s.$content.css("margin-bottom",""),s.$content.outerHeight()>s.$slide.height()+.5&&(o=s.$slide[0].style["padding-bottom"],i=s.$slide.css("padding-bottom"),parseFloat(i)>0&&(e=s.$slide[0].scrollHeight,s.$slide.css("padding-bottom",0),Math.abs(e-s.$slide[0].scrollHeight)<1&&(n=i),s.$slide.css("padding-bottom",o))),s.$content.css("margin-bottom",n))},revealContent:function(t){var e,o,i,a,s=this,r=t.$slide,c=!1,l=!1,d=s.isMoved(t),u=t.isRevealed;return t.isRevealed=!0,e=t.opts[s.firstRun?"animationEffect":"transitionEffect"],i=t.opts[s.firstRun?"animationDuration":"transitionDuration"],i=parseInt(void 0===t.forcedDuration?i:t.forcedDuration,10),!d&&t.pos===s.currPos&&i||(e=!1),"zoom"===e&&(t.pos===s.currPos&&i&&"image"===t.type&&!t.hasError&&(l=s.getThumbPos(t))?c=s.getFitPos(t):e="fade"),"zoom"===e?(s.isAnimating=!0,c.scaleX=c.width/l.width,c.scaleY=c.height/l.height,a=t.opts.zoomOpacity,"auto"==a&&(a=Math.abs(t.width/t.height-l.width/l.height)>.1),a&&(l.opacity=.1,c.opacity=1),n.fancybox.setTranslate(t.$content.removeClass("fancybox-is-hidden"),l),p(t.$content),void n.fancybox.animate(t.$content,c,i,function(){s.isAnimating=!1,s.complete()})):(s.updateSlide(t),e?(n.fancybox.stop(r),o="fancybox-slide--"+(t.pos>=s.prevPos?"next":"previous")+" fancybox-animated fancybox-fx-"+e,r.addClass(o).removeClass("fancybox-slide--current"),t.$content.removeClass("fancybox-is-hidden"),p(r),"image"!==t.type&&t.$content.hide().show(0),void n.fancybox.animate(r,"fancybox-slide--current",i,function(){r.removeClass(o).css({transform:"",opacity:""}),t.pos===s.currPos&&s.complete()},!0)):(t.$content.removeClass("fancybox-is-hidden"),u||!d||"image"!==t.type||t.hasError||t.$content.hide().fadeIn("fast"),void(t.pos===s.currPos&&s.complete())))},getThumbPos:function(t){var e,o,i,a,s,r=!1,c=t.$thumb;return!(!c||!g(c[0]))&&(e=n.fancybox.getTranslate(c),o=parseFloat(c.css("border-top-width")||0),i=parseFloat(c.css("border-right-width")||0),a=parseFloat(c.css("border-bottom-width")||0),s=parseFloat(c.css("border-left-width")||0),r={top:e.top+o,left:e.left+s,width:e.width-i-s,height:e.height-o-a,scaleX:1,scaleY:1},e.width>0&&e.height>0&&r)},complete:function(){var t,e=this,o=e.current,i={};!e.isMoved()&&o.isLoaded&&(o.isComplete||(o.isComplete=!0,o.$slide.siblings().trigger("onReset"),e.preload("inline"),p(o.$slide),o.$slide.addClass("fancybox-slide--complete"),n.each(e.slides,function(t,o){o.pos>=e.currPos-1&&o.pos<=e.currPos+1?i[o.pos]=o:o&&(n.fancybox.stop(o.$slide),o.$slide.off().remove())}),e.slides=i),e.isAnimating=!1,e.updateCursor(),e.trigger("afterShow"),o.opts.video.autoStart&&o.$slide.find("video,audio").filter(":visible:first").trigger("play").one("ended",function(){Document.exitFullscreen?Document.exitFullscreen():this.webkitExitFullscreen&&this.webkitExitFullscreen(),e.next()}),o.opts.autoFocus&&"html"===o.contentType&&(t=o.$content.find("input[autofocus]:enabled:visible:first"),t.length?t.trigger("focus"):e.focus(null,!0)),o.$slide.scrollTop(0).scrollLeft(0))},preload:function(t){var e,n,o=this;o.group.length<2||(n=o.slides[o.currPos+1],e=o.slides[o.currPos-1],e&&e.type===t&&o.loadSlide(e),n&&n.type===t&&o.loadSlide(n))},focus:function(t,o){var i,a,s=this,r=["a[href]","area[href]",'input:not([disabled]):not([type="hidden"]):not([aria-hidden])',"select:not([disabled]):not([aria-hidden])","textarea:not([disabled]):not([aria-hidden])","button:not([disabled]):not([aria-hidden])","iframe","object","embed","video","audio","[contenteditable]",'[tabindex]:not([tabindex^="-"])'].join(",");s.isClosing||(i=!t&&s.current&&s.current.isComplete?s.current.$slide.find("*:visible"+(o?":not(.fancybox-close-small)":"")):s.$refs.container.find("*:visible"),i=i.filter(r).filter(function(){return"hidden"!==n(this).css("visibility")&&!n(this).hasClass("disabled")}),i.length?(a=i.index(e.activeElement),t&&t.shiftKey?(a<0||0==a)&&(t.preventDefault(),i.eq(i.length-1).trigger("focus")):(a<0||a==i.length-1)&&(t&&t.preventDefault(),i.eq(0).trigger("focus"))):s.$refs.container.trigger("focus"))},activate:function(){var t=this;n(".fancybox-container").each(function(){var e=n(this).data("FancyBox");e&&e.id!==t.id&&!e.isClosing&&(e.trigger("onDeactivate"),e.removeEvents(),e.isVisible=!1)}),t.isVisible=!0,(t.current||t.isIdle)&&(t.update(),t.updateControls()),t.trigger("onActivate"),t.addEvents()},close:function(t,e){var o,i,a,s,r,c,l,u=this,f=u.current,h=function(){u.cleanUp(t)};return!u.isClosing&&(u.isClosing=!0,!1===u.trigger("beforeClose",t)?(u.isClosing=!1,d(function(){u.update()}),!1):(u.removeEvents(),a=f.$content,o=f.opts.animationEffect,i=n.isNumeric(e)?e:o?f.opts.animationDuration:0,f.$slide.removeClass("fancybox-slide--complete fancybox-slide--next fancybox-slide--previous fancybox-animated"),!0!==t?n.fancybox.stop(f.$slide):o=!1,f.$slide.siblings().trigger("onReset").remove(),i&&u.$refs.container.removeClass("fancybox-is-open").addClass("fancybox-is-closing").css("transition-duration",i+"ms"),u.hideLoading(f),u.hideControls(!0),u.updateCursor(),"zoom"!==o||a&&i&&"image"===f.type&&!u.isMoved()&&!f.hasError&&(l=u.getThumbPos(f))||(o="fade"),"zoom"===o?(n.fancybox.stop(a),s=n.fancybox.getTranslate(a),c={top:s.top,left:s.left,scaleX:s.width/l.width,scaleY:s.height/l.height,width:l.width,height:l.height},r=f.opts.zoomOpacity,
"auto"==r&&(r=Math.abs(f.width/f.height-l.width/l.height)>.1),r&&(l.opacity=0),n.fancybox.setTranslate(a,c),p(a),n.fancybox.animate(a,l,i,h),!0):(o&&i?n.fancybox.animate(f.$slide.addClass("fancybox-slide--previous").removeClass("fancybox-slide--current"),"fancybox-animated fancybox-fx-"+o,i,h):!0===t?setTimeout(h,i):h(),!0)))},cleanUp:function(e){var o,i,a,s=this,r=s.current.opts.$orig;s.current.$slide.trigger("onReset"),s.$refs.container.empty().remove(),s.trigger("afterClose",e),s.current.opts.backFocus&&(r&&r.length&&r.is(":visible")||(r=s.$trigger),r&&r.length&&(i=t.scrollX,a=t.scrollY,r.trigger("focus"),n("html, body").scrollTop(a).scrollLeft(i))),s.current=null,o=n.fancybox.getInstance(),o?o.activate():(n("body").removeClass("fancybox-active compensate-for-scrollbar"),n("#fancybox-style-noscroll").remove())},trigger:function(t,e){var o,i=Array.prototype.slice.call(arguments,1),a=this,s=e&&e.opts?e:a.current;if(s?i.unshift(s):s=a,i.unshift(a),n.isFunction(s.opts[t])&&(o=s.opts[t].apply(s,i)),!1===o)return o;"afterClose"!==t&&a.$refs?a.$refs.container.trigger(t+".fb",i):r.trigger(t+".fb",i)},updateControls:function(){var t=this,o=t.current,i=o.index,a=t.$refs.container,s=t.$refs.caption,r=o.opts.caption;o.$slide.trigger("refresh"),r&&r.length?(t.$caption=s,s.children().eq(0).html(r)):t.$caption=null,t.hasHiddenControls||t.isIdle||t.showControls(),a.find("[data-fancybox-count]").html(t.group.length),a.find("[data-fancybox-index]").html(i+1),a.find("[data-fancybox-prev]").prop("disabled",!o.opts.loop&&i<=0),a.find("[data-fancybox-next]").prop("disabled",!o.opts.loop&&i>=t.group.length-1),"image"===o.type?a.find("[data-fancybox-zoom]").show().end().find("[data-fancybox-download]").attr("href",o.opts.image.src||o.src).show():o.opts.toolbar&&a.find("[data-fancybox-download],[data-fancybox-zoom]").hide(),n(e.activeElement).is(":hidden,[disabled]")&&t.$refs.container.trigger("focus")},hideControls:function(t){var e=this,n=["infobar","toolbar","nav"];!t&&e.current.opts.preventCaptionOverlap||n.push("caption"),this.$refs.container.removeClass(n.map(function(t){return"fancybox-show-"+t}).join(" ")),this.hasHiddenControls=!0},showControls:function(){var t=this,e=t.current?t.current.opts:t.opts,n=t.$refs.container;t.hasHiddenControls=!1,t.idleSecondsCounter=0,n.toggleClass("fancybox-show-toolbar",!(!e.toolbar||!e.buttons)).toggleClass("fancybox-show-infobar",!!(e.infobar&&t.group.length>1)).toggleClass("fancybox-show-caption",!!t.$caption).toggleClass("fancybox-show-nav",!!(e.arrows&&t.group.length>1)).toggleClass("fancybox-is-modal",!!e.modal)},toggleControls:function(){this.hasHiddenControls?this.showControls():this.hideControls()}}),n.fancybox={version:"3.5.7",defaults:a,getInstance:function(t){var e=n('.fancybox-container:not(".fancybox-is-closing"):last').data("FancyBox"),o=Array.prototype.slice.call(arguments,1);return e instanceof b&&("string"===n.type(t)?e[t].apply(e,o):"function"===n.type(t)&&t.apply(e,o),e)},open:function(t,e,n){return new b(t,e,n)},close:function(t){var e=this.getInstance();e&&(e.close(),!0===t&&this.close(t))},destroy:function(){this.close(!0),r.add("body").off("click.fb-start","**")},isMobile:/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent),use3d:function(){var n=e.createElement("div");return t.getComputedStyle&&t.getComputedStyle(n)&&t.getComputedStyle(n).getPropertyValue("transform")&&!(e.documentMode&&e.documentMode<11)}(),getTranslate:function(t){var e;return!(!t||!t.length)&&(e=t[0].getBoundingClientRect(),{top:e.top||0,left:e.left||0,width:e.width,height:e.height,opacity:parseFloat(t.css("opacity"))})},setTranslate:function(t,e){var n="",o={};if(t&&e)return void 0===e.left&&void 0===e.top||(n=(void 0===e.left?t.position().left:e.left)+"px, "+(void 0===e.top?t.position().top:e.top)+"px",n=this.use3d?"translate3d("+n+", 0px)":"translate("+n+")"),void 0!==e.scaleX&&void 0!==e.scaleY?n+=" scale("+e.scaleX+", "+e.scaleY+")":void 0!==e.scaleX&&(n+=" scaleX("+e.scaleX+")"),n.length&&(o.transform=n),void 0!==e.opacity&&(o.opacity=e.opacity),void 0!==e.width&&(o.width=e.width),void 0!==e.height&&(o.height=e.height),t.css(o)},animate:function(t,e,o,i,a){var s,r=this;n.isFunction(o)&&(i=o,o=null),r.stop(t),s=r.getTranslate(t),t.on(f,function(c){(!c||!c.originalEvent||t.is(c.originalEvent.target)&&"z-index"!=c.originalEvent.propertyName)&&(r.stop(t),n.isNumeric(o)&&t.css("transition-duration",""),n.isPlainObject(e)?void 0!==e.scaleX&&void 0!==e.scaleY&&r.setTranslate(t,{top:e.top,left:e.left,width:s.width*e.scaleX,height:s.height*e.scaleY,scaleX:1,scaleY:1}):!0!==a&&t.removeClass(e),n.isFunction(i)&&i(c))}),n.isNumeric(o)&&t.css("transition-duration",o+"ms"),n.isPlainObject(e)?(void 0!==e.scaleX&&void 0!==e.scaleY&&(delete e.width,delete e.height,t.parent().hasClass("fancybox-slide--image")&&t.parent().addClass("fancybox-is-scaling")),n.fancybox.setTranslate(t,e)):t.addClass(e),t.data("timer",setTimeout(function(){t.trigger(f)},o+33))},stop:function(t,e){t&&t.length&&(clearTimeout(t.data("timer")),e&&t.trigger(f),t.off(f).css("transition-duration",""),t.parent().removeClass("fancybox-is-scaling"))}},n.fn.fancybox=function(t){var e;return t=t||{},e=t.selector||!1,e?n("body").off("click.fb-start",e).on("click.fb-start",e,{options:t},i):this.off("click.fb-start").on("click.fb-start",{items:this,options:t},i),this},r.on("click.fb-start","[data-fancybox]",i),r.on("click.fb-start","[data-fancybox-trigger]",function(t){n('[data-fancybox="'+n(this).attr("data-fancybox-trigger")+'"]').eq(n(this).attr("data-fancybox-index")||0).trigger("click.fb-start",{$trigger:n(this)})}),function(){var t=null;r.on("mousedown mouseup focus blur",".fancybox-button",function(e){switch(e.type){case"mousedown":t=n(this);break;case"mouseup":t=null;break;case"focusin":n(".fancybox-button").removeClass("fancybox-focus"),n(this).is(t)||n(this).is("[disabled]")||n(this).addClass("fancybox-focus");break;case"focusout":n(".fancybox-button").removeClass("fancybox-focus")}})}()}}(window,document,jQuery),function(t){"use strict";var e={youtube:{matcher:/(youtube\.com|youtu\.be|youtube\-nocookie\.com)\/(watch\?(.*&)?v=|v\/|u\/|embed\/?)?(videoseries\?list=(.*)|[\w-]{11}|\?listType=(.*)&list=(.*))(.*)/i,params:{autoplay:1,autohide:1,fs:1,rel:0,hd:1,wmode:"transparent",enablejsapi:1,html5:1},paramPlace:8,type:"iframe",url:"https://www.youtube-nocookie.com/embed/$4",thumb:"https://img.youtube.com/vi/$4/hqdefault.jpg"},vimeo:{matcher:/^.+vimeo.com\/(.*\/)?([\d]+)(.*)?/,params:{autoplay:1,hd:1,show_title:1,show_byline:1,show_portrait:0,fullscreen:1},paramPlace:3,type:"iframe",url:"//player.vimeo.com/video/$2"},instagram:{matcher:/(instagr\.am|instagram\.com)\/p\/([a-zA-Z0-9_\-]+)\/?/i,type:"image",url:"//$1/p/$2/media/?size=l"},gmap_place:{matcher:/(maps\.)?google\.([a-z]{2,3}(\.[a-z]{2})?)\/(((maps\/(place\/(.*)\/)?\@(.*),(\d+.?\d+?)z))|(\?ll=))(.*)?/i,type:"iframe",url:function(t){return"//maps.google."+t[2]+"/?ll="+(t[9]?t[9]+"&z="+Math.floor(t[10])+(t[12]?t[12].replace(/^\//,"&"):""):t[12]+"").replace(/\?/,"&")+"&output="+(t[12]&&t[12].indexOf("layer=c")>0?"svembed":"embed")}},gmap_search:{matcher:/(maps\.)?google\.([a-z]{2,3}(\.[a-z]{2})?)\/(maps\/search\/)(.*)/i,type:"iframe",url:function(t){return"//maps.google."+t[2]+"/maps?q="+t[5].replace("query=","q=").replace("api=1","")+"&output=embed"}}},n=function(e,n,o){if(e)return o=o||"","object"===t.type(o)&&(o=t.param(o,!0)),t.each(n,function(t,n){e=e.replace("$"+t,n||"")}),o.length&&(e+=(e.indexOf("?")>0?"&":"?")+o),e};t(document).on("objectNeedsType.fb",function(o,i,a){var s,r,c,l,d,u,f,p=a.src||"",h=!1;s=t.extend(!0,{},e,a.opts.media),t.each(s,function(e,o){if(c=p.match(o.matcher)){if(h=o.type,f=e,u={},o.paramPlace&&c[o.paramPlace]){d=c[o.paramPlace],"?"==d[0]&&(d=d.substring(1)),d=d.split("&");for(var i=0;i<d.length;++i){var s=d[i].split("=",2);2==s.length&&(u[s[0]]=decodeURIComponent(s[1].replace(/\+/g," ")))}}return l=t.extend(!0,{},o.params,a.opts[e],u),p="function"===t.type(o.url)?o.url.call(this,c,l,a):n(o.url,c,l),r="function"===t.type(o.thumb)?o.thumb.call(this,c,l,a):n(o.thumb,c),"youtube"===e?p=p.replace(/&t=((\d+)m)?(\d+)s/,function(t,e,n,o){return"&start="+((n?60*parseInt(n,10):0)+parseInt(o,10))}):"vimeo"===e&&(p=p.replace("&%23","#")),!1}}),h?(a.opts.thumb||a.opts.$thumb&&a.opts.$thumb.length||(a.opts.thumb=r),"iframe"===h&&(a.opts=t.extend(!0,a.opts,{iframe:{preload:!1,attr:{scrolling:"no"}}})),t.extend(a,{type:h,src:p,origSrc:a.src,contentSource:f,contentType:"image"===h?"image":"gmap_place"==f||"gmap_search"==f?"map":"video"})):p&&(a.type=a.opts.defaultType)});var o={youtube:{src:"https://www.youtube.com/iframe_api",class:"YT",loading:!1,loaded:!1},vimeo:{src:"https://player.vimeo.com/api/player.js",class:"Vimeo",loading:!1,loaded:!1},load:function(t){var e,n=this;if(this[t].loaded)return void setTimeout(function(){n.done(t)});this[t].loading||(this[t].loading=!0,e=document.createElement("script"),e.type="text/javascript",e.src=this[t].src,"youtube"===t?window.onYouTubeIframeAPIReady=function(){n[t].loaded=!0,n.done(t)}:e.onload=function(){n[t].loaded=!0,n.done(t)},document.body.appendChild(e))},done:function(e){var n,o,i;"youtube"===e&&delete window.onYouTubeIframeAPIReady,(n=t.fancybox.getInstance())&&(o=n.current.$content.find("iframe"),"youtube"===e&&void 0!==YT&&YT?i=new YT.Player(o.attr("id"),{events:{onStateChange:function(t){0==t.data&&n.next()}}}):"vimeo"===e&&void 0!==Vimeo&&Vimeo&&(i=new Vimeo.Player(o),i.on("ended",function(){n.next()})))}};t(document).on({"afterShow.fb":function(t,e,n){e.group.length>1&&("youtube"===n.contentSource||"vimeo"===n.contentSource)&&o.load(n.contentSource)}})}(jQuery),function(t,e,n){"use strict";var o=function(){return t.requestAnimationFrame||t.webkitRequestAnimationFrame||t.mozRequestAnimationFrame||t.oRequestAnimationFrame||function(e){return t.setTimeout(e,1e3/60)}}(),i=function(){return t.cancelAnimationFrame||t.webkitCancelAnimationFrame||t.mozCancelAnimationFrame||t.oCancelAnimationFrame||function(e){t.clearTimeout(e)}}(),a=function(e){var n=[];e=e.originalEvent||e||t.e,e=e.touches&&e.touches.length?e.touches:e.changedTouches&&e.changedTouches.length?e.changedTouches:[e];for(var o in e)e[o].pageX?n.push({x:e[o].pageX,y:e[o].pageY}):e[o].clientX&&n.push({x:e[o].clientX,y:e[o].clientY});return n},s=function(t,e,n){return e&&t?"x"===n?t.x-e.x:"y"===n?t.y-e.y:Math.sqrt(Math.pow(t.x-e.x,2)+Math.pow(t.y-e.y,2)):0},r=function(t){if(t.is('a,area,button,[role="button"],input,label,select,summary,textarea,video,audio,iframe')||n.isFunction(t.get(0).onclick)||t.data("selectable"))return!0;for(var e=0,o=t[0].attributes,i=o.length;e<i;e++)if("data-fancybox-"===o[e].nodeName.substr(0,14))return!0;return!1},c=function(e){var n=t.getComputedStyle(e)["overflow-y"],o=t.getComputedStyle(e)["overflow-x"],i=("scroll"===n||"auto"===n)&&e.scrollHeight>e.clientHeight,a=("scroll"===o||"auto"===o)&&e.scrollWidth>e.clientWidth;return i||a},l=function(t){for(var e=!1;;){if(e=c(t.get(0)))break;if(t=t.parent(),!t.length||t.hasClass("fancybox-stage")||t.is("body"))break}return e},d=function(t){var e=this;e.instance=t,e.$bg=t.$refs.bg,e.$stage=t.$refs.stage,e.$container=t.$refs.container,e.destroy(),e.$container.on("touchstart.fb.touch mousedown.fb.touch",n.proxy(e,"ontouchstart"))};d.prototype.destroy=function(){var t=this;t.$container.off(".fb.touch"),n(e).off(".fb.touch"),t.requestId&&(i(t.requestId),t.requestId=null),t.tapped&&(clearTimeout(t.tapped),t.tapped=null)},d.prototype.ontouchstart=function(o){var i=this,c=n(o.target),d=i.instance,u=d.current,f=u.$slide,p=u.$content,h="touchstart"==o.type;if(h&&i.$container.off("mousedown.fb.touch"),(!o.originalEvent||2!=o.originalEvent.button)&&f.length&&c.length&&!r(c)&&!r(c.parent())&&(c.is("img")||!(o.originalEvent.clientX>c[0].clientWidth+c.offset().left))){if(!u||d.isAnimating||u.$slide.hasClass("fancybox-animated"))return o.stopPropagation(),void o.preventDefault();i.realPoints=i.startPoints=a(o),i.startPoints.length&&(u.touch&&o.stopPropagation(),i.startEvent=o,i.canTap=!0,i.$target=c,i.$content=p,i.opts=u.opts.touch,i.isPanning=!1,i.isSwiping=!1,i.isZooming=!1,i.isScrolling=!1,i.canPan=d.canPan(),i.startTime=(new Date).getTime(),i.distanceX=i.distanceY=i.distance=0,i.canvasWidth=Math.round(f[0].clientWidth),i.canvasHeight=Math.round(f[0].clientHeight),i.contentLastPos=null,i.contentStartPos=n.fancybox.getTranslate(i.$content)||{top:0,left:0},i.sliderStartPos=n.fancybox.getTranslate(f),i.stagePos=n.fancybox.getTranslate(d.$refs.stage),i.sliderStartPos.top-=i.stagePos.top,i.sliderStartPos.left-=i.stagePos.left,i.contentStartPos.top-=i.stagePos.top,i.contentStartPos.left-=i.stagePos.left,n(e).off(".fb.touch").on(h?"touchend.fb.touch touchcancel.fb.touch":"mouseup.fb.touch mouseleave.fb.touch",n.proxy(i,"ontouchend")).on(h?"touchmove.fb.touch":"mousemove.fb.touch",n.proxy(i,"ontouchmove")),n.fancybox.isMobile&&e.addEventListener("scroll",i.onscroll,!0),((i.opts||i.canPan)&&(c.is(i.$stage)||i.$stage.find(c).length)||(c.is(".fancybox-image")&&o.preventDefault(),n.fancybox.isMobile&&c.parents(".fancybox-caption").length))&&(i.isScrollable=l(c)||l(c.parent()),n.fancybox.isMobile&&i.isScrollable||o.preventDefault(),(1===i.startPoints.length||u.hasError)&&(i.canPan?(n.fancybox.stop(i.$content),i.isPanning=!0):i.isSwiping=!0,i.$container.addClass("fancybox-is-grabbing")),2===i.startPoints.length&&"image"===u.type&&(u.isLoaded||u.$ghost)&&(i.canTap=!1,i.isSwiping=!1,i.isPanning=!1,i.isZooming=!0,n.fancybox.stop(i.$content),i.centerPointStartX=.5*(i.startPoints[0].x+i.startPoints[1].x)-n(t).scrollLeft(),i.centerPointStartY=.5*(i.startPoints[0].y+i.startPoints[1].y)-n(t).scrollTop(),i.percentageOfImageAtPinchPointX=(i.centerPointStartX-i.contentStartPos.left)/i.contentStartPos.width,i.percentageOfImageAtPinchPointY=(i.centerPointStartY-i.contentStartPos.top)/i.contentStartPos.height,i.startDistanceBetweenFingers=s(i.startPoints[0],i.startPoints[1]))))}},d.prototype.onscroll=function(t){var n=this;n.isScrolling=!0,e.removeEventListener("scroll",n.onscroll,!0)},d.prototype.ontouchmove=function(t){var e=this;return void 0!==t.originalEvent.buttons&&0===t.originalEvent.buttons?void e.ontouchend(t):e.isScrolling?void(e.canTap=!1):(e.newPoints=a(t),void((e.opts||e.canPan)&&e.newPoints.length&&e.newPoints.length&&(e.isSwiping&&!0===e.isSwiping||t.preventDefault(),e.distanceX=s(e.newPoints[0],e.startPoints[0],"x"),e.distanceY=s(e.newPoints[0],e.startPoints[0],"y"),e.distance=s(e.newPoints[0],e.startPoints[0]),e.distance>0&&(e.isSwiping?e.onSwipe(t):e.isPanning?e.onPan():e.isZooming&&e.onZoom()))))},d.prototype.onSwipe=function(e){var a,s=this,r=s.instance,c=s.isSwiping,l=s.sliderStartPos.left||0;if(!0!==c)"x"==c&&(s.distanceX>0&&(s.instance.group.length<2||0===s.instance.current.index&&!s.instance.current.opts.loop)?l+=Math.pow(s.distanceX,.8):s.distanceX<0&&(s.instance.group.length<2||s.instance.current.index===s.instance.group.length-1&&!s.instance.current.opts.loop)?l-=Math.pow(-s.distanceX,.8):l+=s.distanceX),s.sliderLastPos={top:"x"==c?0:s.sliderStartPos.top+s.distanceY,left:l},s.requestId&&(i(s.requestId),s.requestId=null),s.requestId=o(function(){s.sliderLastPos&&(n.each(s.instance.slides,function(t,e){var o=e.pos-s.instance.currPos;n.fancybox.setTranslate(e.$slide,{top:s.sliderLastPos.top,left:s.sliderLastPos.left+o*s.canvasWidth+o*e.opts.gutter})}),s.$container.addClass("fancybox-is-sliding"))});else if(Math.abs(s.distance)>10){if(s.canTap=!1,r.group.length<2&&s.opts.vertical?s.isSwiping="y":r.isDragging||!1===s.opts.vertical||"auto"===s.opts.vertical&&n(t).width()>800?s.isSwiping="x":(a=Math.abs(180*Math.atan2(s.distanceY,s.distanceX)/Math.PI),s.isSwiping=a>45&&a<135?"y":"x"),"y"===s.isSwiping&&n.fancybox.isMobile&&s.isScrollable)return void(s.isScrolling=!0);r.isDragging=s.isSwiping,s.startPoints=s.newPoints,n.each(r.slides,function(t,e){var o,i;n.fancybox.stop(e.$slide),o=n.fancybox.getTranslate(e.$slide),i=n.fancybox.getTranslate(r.$refs.stage),e.$slide.css({transform:"",opacity:"","transition-duration":""}).removeClass("fancybox-animated").removeClass(function(t,e){return(e.match(/(^|\s)fancybox-fx-\S+/g)||[]).join(" ")}),e.pos===r.current.pos&&(s.sliderStartPos.top=o.top-i.top,s.sliderStartPos.left=o.left-i.left),n.fancybox.setTranslate(e.$slide,{top:o.top-i.top,left:o.left-i.left})}),r.SlideShow&&r.SlideShow.isActive&&r.SlideShow.stop()}},d.prototype.onPan=function(){var t=this;if(s(t.newPoints[0],t.realPoints[0])<(n.fancybox.isMobile?10:5))return void(t.startPoints=t.newPoints);t.canTap=!1,t.contentLastPos=t.limitMovement(),t.requestId&&i(t.requestId),t.requestId=o(function(){n.fancybox.setTranslate(t.$content,t.contentLastPos)})},d.prototype.limitMovement=function(){var t,e,n,o,i,a,s=this,r=s.canvasWidth,c=s.canvasHeight,l=s.distanceX,d=s.distanceY,u=s.contentStartPos,f=u.left,p=u.top,h=u.width,g=u.height;return i=h>r?f+l:f,a=p+d,t=Math.max(0,.5*r-.5*h),e=Math.max(0,.5*c-.5*g),n=Math.min(r-h,.5*r-.5*h),o=Math.min(c-g,.5*c-.5*g),l>0&&i>t&&(i=t-1+Math.pow(-t+f+l,.8)||0),l<0&&i<n&&(i=n+1-Math.pow(n-f-l,.8)||0),d>0&&a>e&&(a=e-1+Math.pow(-e+p+d,.8)||0),d<0&&a<o&&(a=o+1-Math.pow(o-p-d,.8)||0),{top:a,left:i}},d.prototype.limitPosition=function(t,e,n,o){var i=this,a=i.canvasWidth,s=i.canvasHeight;return n>a?(t=t>0?0:t,t=t<a-n?a-n:t):t=Math.max(0,a/2-n/2),o>s?(e=e>0?0:e,e=e<s-o?s-o:e):e=Math.max(0,s/2-o/2),{top:e,left:t}},d.prototype.onZoom=function(){var e=this,a=e.contentStartPos,r=a.width,c=a.height,l=a.left,d=a.top,u=s(e.newPoints[0],e.newPoints[1]),f=u/e.startDistanceBetweenFingers,p=Math.floor(r*f),h=Math.floor(c*f),g=(r-p)*e.percentageOfImageAtPinchPointX,b=(c-h)*e.percentageOfImageAtPinchPointY,m=(e.newPoints[0].x+e.newPoints[1].x)/2-n(t).scrollLeft(),v=(e.newPoints[0].y+e.newPoints[1].y)/2-n(t).scrollTop(),y=m-e.centerPointStartX,x=v-e.centerPointStartY,w=l+(g+y),$=d+(b+x),S={top:$,left:w,scaleX:f,scaleY:f};e.canTap=!1,e.newWidth=p,e.newHeight=h,e.contentLastPos=S,e.requestId&&i(e.requestId),e.requestId=o(function(){n.fancybox.setTranslate(e.$content,e.contentLastPos)})},d.prototype.ontouchend=function(t){var o=this,s=o.isSwiping,r=o.isPanning,c=o.isZooming,l=o.isScrolling;if(o.endPoints=a(t),o.dMs=Math.max((new Date).getTime()-o.startTime,1),o.$container.removeClass("fancybox-is-grabbing"),n(e).off(".fb.touch"),e.removeEventListener("scroll",o.onscroll,!0),o.requestId&&(i(o.requestId),o.requestId=null),o.isSwiping=!1,o.isPanning=!1,o.isZooming=!1,o.isScrolling=!1,o.instance.isDragging=!1,o.canTap)return o.onTap(t);o.speed=100,o.velocityX=o.distanceX/o.dMs*.5,o.velocityY=o.distanceY/o.dMs*.5,r?o.endPanning():c?o.endZooming():o.endSwiping(s,l)},d.prototype.endSwiping=function(t,e){var o=this,i=!1,a=o.instance.group.length,s=Math.abs(o.distanceX),r="x"==t&&a>1&&(o.dMs>130&&s>10||s>50);o.sliderLastPos=null,"y"==t&&!e&&Math.abs(o.distanceY)>50?(n.fancybox.animate(o.instance.current.$slide,{top:o.sliderStartPos.top+o.distanceY+150*o.velocityY,opacity:0},200),i=o.instance.close(!0,250)):r&&o.distanceX>0?i=o.instance.previous(300):r&&o.distanceX<0&&(i=o.instance.next(300)),!1!==i||"x"!=t&&"y"!=t||o.instance.centerSlide(200),o.$container.removeClass("fancybox-is-sliding")},d.prototype.endPanning=function(){var t,e,o,i=this;i.contentLastPos&&(!1===i.opts.momentum||i.dMs>350?(t=i.contentLastPos.left,e=i.contentLastPos.top):(t=i.contentLastPos.left+500*i.velocityX,e=i.contentLastPos.top+500*i.velocityY),o=i.limitPosition(t,e,i.contentStartPos.width,i.contentStartPos.height),o.width=i.contentStartPos.width,o.height=i.contentStartPos.height,n.fancybox.animate(i.$content,o,366))},d.prototype.endZooming=function(){var t,e,o,i,a=this,s=a.instance.current,r=a.newWidth,c=a.newHeight;a.contentLastPos&&(t=a.contentLastPos.left,e=a.contentLastPos.top,i={top:e,left:t,width:r,height:c,scaleX:1,scaleY:1},n.fancybox.setTranslate(a.$content,i),r<a.canvasWidth&&c<a.canvasHeight?a.instance.scaleToFit(150):r>s.width||c>s.height?a.instance.scaleToActual(a.centerPointStartX,a.centerPointStartY,150):(o=a.limitPosition(t,e,r,c),n.fancybox.animate(a.$content,o,150)))},d.prototype.onTap=function(e){var o,i=this,s=n(e.target),r=i.instance,c=r.current,l=e&&a(e)||i.startPoints,d=l[0]?l[0].x-n(t).scrollLeft()-i.stagePos.left:0,u=l[0]?l[0].y-n(t).scrollTop()-i.stagePos.top:0,f=function(t){var o=c.opts[t];if(n.isFunction(o)&&(o=o.apply(r,[c,e])),o)switch(o){case"close":r.close(i.startEvent);break;case"toggleControls":r.toggleControls();break;case"next":r.next();break;case"nextOrClose":r.group.length>1?r.next():r.close(i.startEvent);break;case"zoom":"image"==c.type&&(c.isLoaded||c.$ghost)&&(r.canPan()?r.scaleToFit():r.isScaledDown()?r.scaleToActual(d,u):r.group.length<2&&r.close(i.startEvent))}};if((!e.originalEvent||2!=e.originalEvent.button)&&(s.is("img")||!(d>s[0].clientWidth+s.offset().left))){if(s.is(".fancybox-bg,.fancybox-inner,.fancybox-outer,.fancybox-container"))o="Outside";else if(s.is(".fancybox-slide"))o="Slide";else{if(!r.current.$content||!r.current.$content.find(s).addBack().filter(s).length)return;o="Content"}if(i.tapped){if(clearTimeout(i.tapped),i.tapped=null,Math.abs(d-i.tapX)>50||Math.abs(u-i.tapY)>50)return this;f("dblclick"+o)}else i.tapX=d,i.tapY=u,c.opts["dblclick"+o]&&c.opts["dblclick"+o]!==c.opts["click"+o]?i.tapped=setTimeout(function(){i.tapped=null,r.isAnimating||f("click"+o)},500):f("click"+o);return this}},n(e).on("onActivate.fb",function(t,e){e&&!e.Guestures&&(e.Guestures=new d(e))}).on("beforeClose.fb",function(t,e){e&&e.Guestures&&e.Guestures.destroy()})}(window,document,jQuery),function(t,e){"use strict";e.extend(!0,e.fancybox.defaults,{btnTpl:{slideShow:'<button data-fancybox-play class="fancybox-button fancybox-button--play" title="{{PLAY_START}}"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M6.5 5.4v13.2l11-6.6z"/></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M8.33 5.75h2.2v12.5h-2.2V5.75zm5.15 0h2.2v12.5h-2.2V5.75z"/></svg></button>'},slideShow:{autoStart:!1,speed:3e3,progress:!0}});var n=function(t){this.instance=t,this.init()};e.extend(n.prototype,{timer:null,isActive:!1,$button:null,init:function(){var t=this,n=t.instance,o=n.group[n.currIndex].opts.slideShow;t.$button=n.$refs.toolbar.find("[data-fancybox-play]").on("click",function(){t.toggle()}),n.group.length<2||!o?t.$button.hide():o.progress&&(t.$progress=e('<div class="fancybox-progress"></div>').appendTo(n.$refs.inner))},set:function(t){var n=this,o=n.instance,i=o.current;i&&(!0===t||i.opts.loop||o.currIndex<o.group.length-1)?n.isActive&&"video"!==i.contentType&&(n.$progress&&e.fancybox.animate(n.$progress.show(),{scaleX:1},i.opts.slideShow.speed),n.timer=setTimeout(function(){o.current.opts.loop||o.current.index!=o.group.length-1?o.next():o.jumpTo(0)},i.opts.slideShow.speed)):(n.stop(),o.idleSecondsCounter=0,o.showControls())},clear:function(){var t=this;clearTimeout(t.timer),t.timer=null,t.$progress&&t.$progress.removeAttr("style").hide()},start:function(){var t=this,e=t.instance.current;e&&(t.$button.attr("title",(e.opts.i18n[e.opts.lang]||e.opts.i18n.en).PLAY_STOP).removeClass("fancybox-button--play").addClass("fancybox-button--pause"),t.isActive=!0,e.isComplete&&t.set(!0),t.instance.trigger("onSlideShowChange",!0))},stop:function(){var t=this,e=t.instance.current;t.clear(),t.$button.attr("title",(e.opts.i18n[e.opts.lang]||e.opts.i18n.en).PLAY_START).removeClass("fancybox-button--pause").addClass("fancybox-button--play"),t.isActive=!1,t.instance.trigger("onSlideShowChange",!1),t.$progress&&t.$progress.removeAttr("style").hide()},toggle:function(){var t=this;t.isActive?t.stop():t.start()}}),e(t).on({"onInit.fb":function(t,e){e&&!e.SlideShow&&(e.SlideShow=new n(e))},"beforeShow.fb":function(t,e,n,o){var i=e&&e.SlideShow;o?i&&n.opts.slideShow.autoStart&&i.start():i&&i.isActive&&i.clear()},"afterShow.fb":function(t,e,n){var o=e&&e.SlideShow;o&&o.isActive&&o.set()},"afterKeydown.fb":function(n,o,i,a,s){var r=o&&o.SlideShow;!r||!i.opts.slideShow||80!==s&&32!==s||e(t.activeElement).is("button,a,input")||(a.preventDefault(),r.toggle())},"beforeClose.fb onDeactivate.fb":function(t,e){var n=e&&e.SlideShow;n&&n.stop()}}),e(t).on("visibilitychange",function(){var n=e.fancybox.getInstance(),o=n&&n.SlideShow;o&&o.isActive&&(t.hidden?o.clear():o.set())})}(document,jQuery),function(t,e){"use strict";var n=function(){for(var e=[["requestFullscreen","exitFullscreen","fullscreenElement","fullscreenEnabled","fullscreenchange","fullscreenerror"],["webkitRequestFullscreen","webkitExitFullscreen","webkitFullscreenElement","webkitFullscreenEnabled","webkitfullscreenchange","webkitfullscreenerror"],["webkitRequestFullScreen","webkitCancelFullScreen","webkitCurrentFullScreenElement","webkitCancelFullScreen","webkitfullscreenchange","webkitfullscreenerror"],["mozRequestFullScreen","mozCancelFullScreen","mozFullScreenElement","mozFullScreenEnabled","mozfullscreenchange","mozfullscreenerror"],["msRequestFullscreen","msExitFullscreen","msFullscreenElement","msFullscreenEnabled","MSFullscreenChange","MSFullscreenError"]],n={},o=0;o<e.length;o++){var i=e[o];if(i&&i[1]in t){for(var a=0;a<i.length;a++)n[e[0][a]]=i[a];return n}}return!1}();if(n){var o={request:function(e){e=e||t.documentElement,e[n.requestFullscreen](e.ALLOW_KEYBOARD_INPUT)},exit:function(){t[n.exitFullscreen]()},toggle:function(e){e=e||t.documentElement,this.isFullscreen()?this.exit():this.request(e)},isFullscreen:function(){return Boolean(t[n.fullscreenElement])},enabled:function(){return Boolean(t[n.fullscreenEnabled])}};e.extend(!0,e.fancybox.defaults,{btnTpl:{fullScreen:'<button data-fancybox-fullscreen class="fancybox-button fancybox-button--fsenter" title="{{FULL_SCREEN}}"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z"/></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M5 16h3v3h2v-5H5zm3-8H5v2h5V5H8zm6 11h2v-3h3v-2h-5zm2-11V5h-2v5h5V8z"/></svg></button>'},fullScreen:{autoStart:!1}}),e(t).on(n.fullscreenchange,function(){var t=o.isFullscreen(),n=e.fancybox.getInstance();n&&(n.current&&"image"===n.current.type&&n.isAnimating&&(n.isAnimating=!1,n.update(!0,!0,0),n.isComplete||n.complete()),n.trigger("onFullscreenChange",t),n.$refs.container.toggleClass("fancybox-is-fullscreen",t),n.$refs.toolbar.find("[data-fancybox-fullscreen]").toggleClass("fancybox-button--fsenter",!t).toggleClass("fancybox-button--fsexit",t))})}e(t).on({"onInit.fb":function(t,e){var i;if(!n)return void e.$refs.toolbar.find("[data-fancybox-fullscreen]").remove();e&&e.group[e.currIndex].opts.fullScreen?(i=e.$refs.container,i.on("click.fb-fullscreen","[data-fancybox-fullscreen]",function(t){t.stopPropagation(),t.preventDefault(),o.toggle()}),e.opts.fullScreen&&!0===e.opts.fullScreen.autoStart&&o.request(),e.FullScreen=o):e&&e.$refs.toolbar.find("[data-fancybox-fullscreen]").hide()},"afterKeydown.fb":function(t,e,n,o,i){e&&e.FullScreen&&70===i&&(o.preventDefault(),e.FullScreen.toggle())},"beforeClose.fb":function(t,e){e&&e.FullScreen&&e.$refs.container.hasClass("fancybox-is-fullscreen")&&o.exit()}})}(document,jQuery),function(t,e){"use strict";var n="fancybox-thumbs";e.fancybox.defaults=e.extend(!0,{btnTpl:{thumbs:'<button data-fancybox-thumbs class="fancybox-button fancybox-button--thumbs" title="{{THUMBS}}"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M14.59 14.59h3.76v3.76h-3.76v-3.76zm-4.47 0h3.76v3.76h-3.76v-3.76zm-4.47 0h3.76v3.76H5.65v-3.76zm8.94-4.47h3.76v3.76h-3.76v-3.76zm-4.47 0h3.76v3.76h-3.76v-3.76zm-4.47 0h3.76v3.76H5.65v-3.76zm8.94-4.47h3.76v3.76h-3.76V5.65zm-4.47 0h3.76v3.76h-3.76V5.65zm-4.47 0h3.76v3.76H5.65V5.65z"/></svg></button>'},thumbs:{autoStart:!1,hideOnClose:!0,parentEl:".fancybox-container",axis:"y"}},e.fancybox.defaults);var o=function(t){this.init(t)};e.extend(o.prototype,{$button:null,$grid:null,$list:null,isVisible:!1,isActive:!1,init:function(t){var e=this,n=t.group,o=0;e.instance=t,e.opts=n[t.currIndex].opts.thumbs,t.Thumbs=e,e.$button=t.$refs.toolbar.find("[data-fancybox-thumbs]");for(var i=0,a=n.length;i<a&&(n[i].thumb&&o++,!(o>1));i++);o>1&&e.opts?(e.$button.removeAttr("style").on("click",function(){e.toggle()}),e.isActive=!0):e.$button.hide()},create:function(){var t,o=this,i=o.instance,a=o.opts.parentEl,s=[];o.$grid||(o.$grid=e('<div class="'+n+" "+n+"-"+o.opts.axis+'"></div>').appendTo(i.$refs.container.find(a).addBack().filter(a)),o.$grid.on("click","a",function(){i.jumpTo(e(this).attr("data-index"))})),o.$list||(o.$list=e('<div class="'+n+'__list">').appendTo(o.$grid)),e.each(i.group,function(e,n){t=n.thumb,t||"image"!==n.type||(t=n.src),s.push('<a href="javascript:;" tabindex="0" data-index="'+e+'"'+(t&&t.length?' style="background-image:url('+t+')"':'class="fancybox-thumbs-missing"')+"></a>")}),o.$list[0].innerHTML=s.join(""),"x"===o.opts.axis&&o.$list.width(parseInt(o.$grid.css("padding-right"),10)+i.group.length*o.$list.children().eq(0).outerWidth(!0))},focus:function(t){var e,n,o=this,i=o.$list,a=o.$grid;o.instance.current&&(e=i.children().removeClass("fancybox-thumbs-active").filter('[data-index="'+o.instance.current.index+'"]').addClass("fancybox-thumbs-active"),n=e.position(),"y"===o.opts.axis&&(n.top<0||n.top>i.height()-e.outerHeight())?i.stop().animate({scrollTop:i.scrollTop()+n.top},t):"x"===o.opts.axis&&(n.left<a.scrollLeft()||n.left>a.scrollLeft()+(a.width()-e.outerWidth()))&&i.parent().stop().animate({scrollLeft:n.left},t))},update:function(){var t=this;t.instance.$refs.container.toggleClass("fancybox-show-thumbs",this.isVisible),t.isVisible?(t.$grid||t.create(),t.instance.trigger("onThumbsShow"),t.focus(0)):t.$grid&&t.instance.trigger("onThumbsHide"),t.instance.update()},hide:function(){this.isVisible=!1,this.update()},show:function(){this.isVisible=!0,this.update()},toggle:function(){this.isVisible=!this.isVisible,this.update()}}),e(t).on({"onInit.fb":function(t,e){var n;e&&!e.Thumbs&&(n=new o(e),n.isActive&&!0===n.opts.autoStart&&n.show())},"beforeShow.fb":function(t,e,n,o){var i=e&&e.Thumbs;i&&i.isVisible&&i.focus(o?0:250)},"afterKeydown.fb":function(t,e,n,o,i){var a=e&&e.Thumbs;a&&a.isActive&&71===i&&(o.preventDefault(),a.toggle())},"beforeClose.fb":function(t,e){var n=e&&e.Thumbs;n&&n.isVisible&&!1!==n.opts.hideOnClose&&n.$grid.hide()}})}(document,jQuery),function(t,e){"use strict";function n(t){var e={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;","/":"&#x2F;","`":"&#x60;","=":"&#x3D;"};return String(t).replace(/[&<>"'`=\/]/g,function(t){return e[t]})}e.extend(!0,e.fancybox.defaults,{btnTpl:{share:'<button data-fancybox-share class="fancybox-button fancybox-button--share" title="{{SHARE}}"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M2.55 19c1.4-8.4 9.1-9.8 11.9-9.8V5l7 7-7 6.3v-3.5c-2.8 0-10.5 2.1-11.9 4.2z"/></svg></button>'},share:{url:function(t,e){return!t.currentHash&&"inline"!==e.type&&"html"!==e.type&&(e.origSrc||e.src)||window.location},
tpl:'<div class="fancybox-share"><h1>{{SHARE}}</h1><p><a class="fancybox-share__button fancybox-share__button--fb" href="https://www.facebook.com/sharer/sharer.php?u={{url}}"><svg viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="m287 456v-299c0-21 6-35 35-35h38v-63c-7-1-29-3-55-3-54 0-91 33-91 94v306m143-254h-205v72h196" /></svg><span>Facebook</span></a><a class="fancybox-share__button fancybox-share__button--tw" href="https://twitter.com/intent/tweet?url={{url}}&text={{descr}}"><svg viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="m456 133c-14 7-31 11-47 13 17-10 30-27 37-46-15 10-34 16-52 20-61-62-157-7-141 75-68-3-129-35-169-85-22 37-11 86 26 109-13 0-26-4-37-9 0 39 28 72 65 80-12 3-25 4-37 2 10 33 41 57 77 57-42 30-77 38-122 34 170 111 378-32 359-208 16-11 30-25 41-42z" /></svg><span>Twitter</span></a><a class="fancybox-share__button fancybox-share__button--pt" href="https://www.pinterest.com/pin/create/button/?url={{url}}&description={{descr}}&media={{media}}"><svg viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="m265 56c-109 0-164 78-164 144 0 39 15 74 47 87 5 2 10 0 12-5l4-19c2-6 1-8-3-13-9-11-15-25-15-45 0-58 43-110 113-110 62 0 96 38 96 88 0 67-30 122-73 122-24 0-42-19-36-44 6-29 20-60 20-81 0-19-10-35-31-35-25 0-44 26-44 60 0 21 7 36 7 36l-30 125c-8 37-1 83 0 87 0 3 4 4 5 2 2-3 32-39 42-75l16-64c8 16 31 29 56 29 74 0 124-67 124-157 0-69-58-132-146-132z" fill="#fff"/></svg><span>Pinterest</span></a></p><p><input class="fancybox-share__input" type="text" value="{{url_raw}}" onclick="select()" /></p></div>'}}),e(t).on("click","[data-fancybox-share]",function(){var t,o,i=e.fancybox.getInstance(),a=i.current||null;a&&("function"===e.type(a.opts.share.url)&&(t=a.opts.share.url.apply(a,[i,a])),o=a.opts.share.tpl.replace(/\{\{media\}\}/g,"image"===a.type?encodeURIComponent(a.src):"").replace(/\{\{url\}\}/g,encodeURIComponent(t)).replace(/\{\{url_raw\}\}/g,n(t)).replace(/\{\{descr\}\}/g,i.$caption?encodeURIComponent(i.$caption.text()):""),e.fancybox.open({src:i.translate(i,o),type:"html",opts:{touch:!1,animationEffect:!1,afterLoad:function(t,e){i.$refs.container.one("beforeClose.fb",function(){t.close(null,0)}),e.$content.find(".fancybox-share__button").click(function(){return window.open(this.href,"Share","width=550, height=450"),!1})},mobile:{autoFocus:!1}}}))})}(document,jQuery),function(t,e,n){"use strict";function o(){var e=t.location.hash.substr(1),n=e.split("-"),o=n.length>1&&/^\+?\d+$/.test(n[n.length-1])?parseInt(n.pop(-1),10)||1:1,i=n.join("-");return{hash:e,index:o<1?1:o,gallery:i}}function i(t){""!==t.gallery&&n("[data-fancybox='"+n.escapeSelector(t.gallery)+"']").eq(t.index-1).focus().trigger("click.fb-start")}function a(t){var e,n;return!!t&&(e=t.current?t.current.opts:t.opts,""!==(n=e.hash||(e.$orig?e.$orig.data("fancybox")||e.$orig.data("fancybox-trigger"):""))&&n)}n.escapeSelector||(n.escapeSelector=function(t){return(t+"").replace(/([\0-\x1f\x7f]|^-?\d)|^-$|[^\x80-\uFFFF\w-]/g,function(t,e){return e?"\0"===t?"�":t.slice(0,-1)+"\\"+t.charCodeAt(t.length-1).toString(16)+" ":"\\"+t})}),n(function(){!1!==n.fancybox.defaults.hash&&(n(e).on({"onInit.fb":function(t,e){var n,i;!1!==e.group[e.currIndex].opts.hash&&(n=o(),(i=a(e))&&n.gallery&&i==n.gallery&&(e.currIndex=n.index-1))},"beforeShow.fb":function(n,o,i,s){var r;i&&!1!==i.opts.hash&&(r=a(o))&&(o.currentHash=r+(o.group.length>1?"-"+(i.index+1):""),t.location.hash!=="#"+o.currentHash&&(s&&!o.origHash&&(o.origHash=t.location.hash),o.hashTimer&&clearTimeout(o.hashTimer),o.hashTimer=setTimeout(function(){"replaceState"in t.history?(t.history[s?"pushState":"replaceState"]({},e.title,t.location.pathname+t.location.search+"#"+o.currentHash),s&&(o.hasCreatedHistory=!0)):t.location.hash=o.currentHash,o.hashTimer=null},300)))},"beforeClose.fb":function(n,o,i){i&&!1!==i.opts.hash&&(clearTimeout(o.hashTimer),o.currentHash&&o.hasCreatedHistory?t.history.back():o.currentHash&&("replaceState"in t.history?t.history.replaceState({},e.title,t.location.pathname+t.location.search+(o.origHash||"")):t.location.hash=o.origHash),o.currentHash=null)}}),n(t).on("hashchange.fb",function(){var t=o(),e=null;n.each(n(".fancybox-container").get().reverse(),function(t,o){var i=n(o).data("FancyBox");if(i&&i.currentHash)return e=i,!1}),e?e.currentHash===t.gallery+"-"+t.index||1===t.index&&e.currentHash==t.gallery||(e.currentHash=null,e.close()):""!==t.gallery&&i(t)}),setTimeout(function(){n.fancybox.getInstance()||i(o())},50))})}(window,document,jQuery),function(t,e){"use strict";var n=(new Date).getTime();e(t).on({"onInit.fb":function(t,e,o){e.$refs.stage.on("mousewheel DOMMouseScroll wheel MozMousePixelScroll",function(t){var o=e.current,i=(new Date).getTime();e.group.length<2||!1===o.opts.wheel||"auto"===o.opts.wheel&&"image"!==o.type||(t.preventDefault(),t.stopPropagation(),o.$slide.hasClass("fancybox-animated")||(t=t.originalEvent||t,i-n<250||(n=i,e[(-t.deltaY||-t.deltaX||t.wheelDelta||-t.detail)<0?"next":"previous"]())))})}})}(document,jQuery);
try {
 $(document).ready(function(){
     $("a[href*='youtu.be/'],a[href*='youtube.com/watch']").filter(":not([data-fancybox-href])").each(function(i,v){
		var id=v.href.match(/youtu\.be\/([\w-]+)[\/\?]?/) || v.href.match(/youtube.com\/watch\?v=([\w-]+)[\&]?/);
         if (id && v.href.indexOf("#")<0) {
             $(v).attr("data-fancybox-href","//www.youtube.com/embed/"+id[1]+"?controls=1&showinfo=0&rel=0&enablejsapi=1&autoplay=1&wmode=transparent");
         }
     });
     $("a[href*='brighttalk.com/webcast']").filter(":not([data-fancybox-href])").each(function(i,v){
         var id=v.href.match(/webcast\/([0-9]+)\/([0-9]+)/);
         if (id && id[2]) {
             var url="https://www.brighttalk.com/service/player/en-US/theme/default/channel/"+id[1]+"/webcast/"+id[2]+"/standalone?commid="+id[2];
             $(v).attr("data-fancybox-href",url).attr("data-type","iframe").attr("data-src",url).attr("data-options","{\"iframe\":{\"css\":{\"max-width\":760}}}");
         }
     });

     $("span[data-fancybox]:has(img[src*='.svg'])").attr("data-width",Math.min(1024,Math.floor($(window).width()*.8))).attr("data-height",Math.floor($(window).height()*.8));
     if (typeof($.fancybox)!="undefined"){
     	$("a[data-fancybox-href]").fancybox({"touch":false});
     	$.fancybox.defaults.touch=false;
     }
 });
} catch (e) {}
// Bert 2.0
window.Bert = new function() {
 var bert=this;
 this.enabled=1; // active;
 this.profile={};
 this.value=0;
 this.now=new Date();


 // setup BERT
 this.init=function() {
  	if (!bert.enabled) {return false; }
  	if (typeof(navigator.doNotTrack)!="undefined" && navigator.doNotTrack) { return false; }

    try { if (typeof(localStorage)!="undefined") { 
     	bert.profile=JSON.parse(localStorage["bert"] || "{}");
        bert.valuable();
    }} catch (e) { bert.enabled=false; return false;}

  // Google GCLID
  if (window.location.search.indexOf("gclid=")>=0) {
   var g=window.location.search.match(/gclid=([^\&]+)/);
   if (g && g[1]) { bert.GCLID=g[1].substr(0,128) + ("//"+bert.now.toISOString()); }
   bert.addInterest('utm','gclid',bert.GCLID);
   bert.addInterest('utm','medium',"paid");
  }
  // UTMs
   var qs=window.location.search;
   if (document.referrer && document.referrer.indexOf("?")>0) { qs+="&"+document.referrer.substr(document.referrer.indexOf("?")+1); }
  if (qs.indexOf("utm_")>=0 || qs.indexOf("intcmp")>=0) {
   var q=qs.substr(1).split(/[\&\?]/);
   for (var i in q) {
    var va=q[i].match(/utm_(.*?)=(.*)/);
    if (va && va[2]) { bert.addInterest('utm',va[1],va[2]); }
       else if (q[i].match(/intcmp=.+/)) {
           bert.addInterest('utm','campaign',q[i].substring(8));
       }
   }
  }
  // evar
     if (qs.indexOf("cmp=")>=0) {
         var cmp=qs.substr(qs.indexOf("cmp=")+4)+"&";
         cmp=cmp.substr(0,cmp.indexOf("&"));
         if (cmp.indexOf(":")>=0) {
             if (cmp.match(/.+-([0-9_]+)$/)) {
                 bert.addInterest("utm","dcmID",cmp.substr(cmp.lastIndexOf("-")+1));
        	     cmp=cmp.substr(0,cmp.lastIndexOf("-"));
             }
           var q=cmp.split(/\:/);
           if (q && q.length>1) {
            if (q[0] && q[0]!="NA") { bert.addInterest("utm","medium",q[0].substr(0,16)); }
            if (q[1] && q[1]!="NA") { bert.addInterest("utm","source",q[1].substr(0,16)); }
            if (q[2] && q[2]!="NA") { bert.addInterest("utm","audience",q[2].substr(0,16)); }
            if (q[3] && q[3]!="NA") { bert.addInterest("utm","segment",q[3].substr(0,16)); }
            if (q[4] && q[4]!="NA") { bert.addInterest("utm","campaign",q[4].substr(0,64)); }
            if (q[5] && q[5]!="NA") { bert.addInterest("utm","content",q[5].substr(0,64)); }
           } else {
              bert.addInterest("utm","content",cmp.substr(0,64));
           }
         }
     }
     // cj event
	if (qs.indexOf("cjevent=")>=0) {
         var cje=qs.substr(qs.indexOf("cjevent=")+8)+"&";
         cje=cje.substr(0,cje.indexOf("&"));
        bert.addInterest("utm","cjevent",cje.substr(0,32));
	}
     if (qs.indexOf("&SID=")>=0) {
         var sid=qs.substr(qs.indexOf("&SID=")+5)+"&";
         sid=sid.substr(0,sid.indexOf("&"));
        bert.addInterest("utm","sid",sid.substr(0,48));
	}
  // site section
  var ps=window.location.pathname.match(/products?\/([^\.\/]+)[\.\/]?/);
  if (ps) { bert.addInterest('products',ps[1]); }
  var is=window.location.pathname.match(/industry\/([^\.\/]+)[\.\/]?/) || window.location.pathname.match(/solutions\/public.sector\/([^\.\/]+)[\.\/]?/);
  if (is) { bert.addInterest('industry',is[1]); }
  //var main=document.getElementById("main");
  //if (main && main.hasAttribute("data-topic")) {
  //       bert.addInterest("topics",main.getAttribute("data-topic"));
  //   }
  if (typeof(digitalData)!="undefined" && typeof(digitalData.pageInfo)!="undefined") {
         if (digitalData.pageInfo.areaInterest) { bert.addInterest("topic",digitalData.pageInfo.areaInterest.replace(/,.*/,"")); }
         if (digitalData.pageInfo.industry) { bert.addInterest("industry",digitalData.pageInfo.industry.replace(/,.*/,"")); }
  }
  // source
     if (document.referrer && (!bert.profile.utm || !bert.profile.utm.source)) {
         var host=document.referrer.match(/\/\/([^\/]+)\/?/);
         if (host && host[1]) { bert.addInterest('utm','source',host[1]); }
     }
     if (document.referrer && (document.referrer.indexOf("myverizonenterprise")>0 || document.referrer.indexOf("enterpriseportal.verizon")>0)) {
         bert.addInterest('utm','customer','vec');
     }
     else if (document.referrer && document.referrer.indexOf("mb.verizonwireless")>0) {
         bert.addInterest('utm','customer','mb');
     }
  // previous page
     if (typeof(bert.profile.utm)!="undefined" && window.location.pathname!=bert.profile.utm.currentpage && "/support/"!=bert.profile.utm.currentpage ) {
      bert.addInterest("utm","previouspage",bert.profile.utm.currentpage);
     }
     bert.addInterest("utm","currentpage",window.location.pathname);
     if (typeof(digitalData)!="undefined" && window.location.pathname.indexOf("contact")<0) {
         var pt=digitalData.pageInfo.pageType;
         if (pt && pt.indexOf(":")>0) {
             bert.addInterest("utm","pagetype",pt.substr(0,pt.indexOf(":")));
         }
     }

 }

 // generate unique id
 this.newID=function() {
    var id=Math.floor(Math.random()*1048576).toString(16)+"-"+Math.floor(bert.now/3600000).toString(16);
    return id;
 }


 // remember something section,subsection[,value]
 this.addInterest=function(s,ss,v) {
  if (typeof(localStorage)!="undefined") {
   var section=JSON.parse(localStorage["bert"] || "{}");
   s=s.toLowerCase(); ss=ss.toLowerCase();
   if (!section[s]) { section[s]={}; }
   var l=(v ? v : Math.min(9,parseInt(section[s][ss]||0)+1));
   if (l>0) { for (i in section[s]) {
    if (section[s][i]>=l) { section[s][i]--; }
   } }
   section[s][ss]=l;
   bert.profile=section;
   localStorage["bert"]=JSON.stringify(section);
  }
 }

 // populate standard hidden fields
 this.mktoForm=function() {
     var tags=document.getElementsByTagName("INPUT");
     if (tags && tags.length) {
         var utm = bert.profile.utm || {};
         var fields={'mktoformoriginalPAGE':document.location.pathname}
         if (utm.source) { fields['mktoformlastSOURCE']=utm.source; }
         if (utm.medium) { fields['mktoformlastMEDIUM']=utm.medium; }
         if (utm.campaign) { fields['mktoformlastCAMPAIGN']=utm.campaign; }
         if (utm.sid) { fields['zCSSID']=utm.sid; }
         if (utm) { fields['zCSCMP']=bert.cmp(); }

         for (t=0;t<tags.length;t++) {
             if (tags[t].name && !tags[t].value && fields[tags[t].name]) {
                 tags[t].value=fields[tags[t].name];
             }
         }
     }
 }

 //is profile valuable
 this.valuable=function() {
     var v=0;
     for (var a in bert.profile) {
         for (var b in bert.profile[a]) {
             if (typeof(bert.profile[a][b])=="number") { v+=bert.profile[a][b]; } else { v++; }
         }
     }
     bert.value=v;
     return v;
 }

 // get cmp code
 this.cmp=function() {
     var utm=bert.profile.utm || {};
     var cmp=[];
     cmp.push(utm.medium || "");
     cmp.push(utm.source || "");
     cmp.push(utm.audience || "");
     cmp.push(utm.segment || "");
     cmp.push(utm.campaign || "");
     cmp.push(utm.content || "");
     return cmp.join(":");
 }

}

// defer start
if (typeof(Bert) != "undefined") {
 if (typeof($)!="undefined" && typeof($.noop) != "undefined") {
  $(window).on('load',Bert.init);
 } else {
  setTimeout(Bert.init,500);
 }
}
(function () {

    var SearchConfig = function(el){
        // List out all search object properties
        var urlParams = window.location.search.substring(1);
        urlParams = urlParams.length > 0 ? JSON.parse('{"' + decodeURI(urlParams.replace(/&/g, "\",\"").replace(/=/g,"\":\"")) + '"}') : {};

        // var obj = JSON.parse(el.attr("data-searchproperties"));
        var obj = {};
        this.searchEndpoint = el.find('.cs_search-results').attr("data-searchendpoint");
        this.loadDefaultResults = el.find('.cs_search-results').attr("data-loadDefaultResults");
        this.resultsDisplayFormat = el.find('.cs_search-results').attr('data-resultsdisplayformat');
        this.customTemplateColumnCount = el.find('.cs_search-results-area').attr('data-numberofresultsperrow');
        this.resultTemplate = typeof(el.find('.cs_search-results-area').attr('data-template')) !== 'undefined' ? el.find('.cs_search-results-area').attr('data-template') : "";
        this.facets = typeof(el.find('.cs_search-filter').attr("data-facet")) !== 'undefined' ? el.find('.cs_search-filter').attr("data-facet").split(",") : "";
        this.defaultNumberOfResults = typeof(el.find('.cs_search-results').attr("data-defaultnumberofresults")) !== 'undefined' ? el.find('.cs_search-results').attr("data-defaultnumberofresults") : "";
        this.filterLookup = obj.hasOwnProperty("filterLookup") ? obj.filterLookup : "";
        this.resultsCountLookup = typeof(el.find('.cs_search-results').attr("data-defaultnumberofresults")) !== 'undefined' ? el.find('.cs_search-results').attr("data-defaultnumberofresults") : "";
        this.resultFields = typeof(el.find('.cs_search-results').attr("data-indexs")) !== 'undefined' && el.find('.cs_search-results').attr("data-indexs") !== false ? el.find('.cs_search-results').attr("data-indexs") : "";
        this.site_name = urlParams.hasOwnProperty("cs_site_name") ? urlParams.cs_site_name.split(",") : typeof(el.find('.cs_search-results').attr("data-sitename")) !== 'undefined' && el.find('.cs_search-results').attr("data-sitename") !== false ? el.find('.cs_search-results').attr("data-sitename").split(",") : "";
        this.paginationType = typeof(el.find('.cs_search-component-pagenation').attr("data-paginationType")) !== 'undefined' && el.find('.cs_search-component-pagenation').attr("data-paginationType") !== false ? el.find('.cs_search-component-pagenation').attr("data-paginationType") : "";
        this.locale = typeof(document.head.querySelector("[name=locale]")) !== 'undefined' ? document.head.querySelector("[name=locale]").content.replace('-', '_').toLowerCase() : "";
        this.page = ves.utils.getParameterByName('page').length ? ves.utils.getParameterByName('page') : 1;
        this.start = (this.page - 1) * parseInt(this.resultsCountLookup);
        this.contentType = typeof(el.find('.cs_search-results').attr("data-contenttype")) !== 'undefined' && el.find('.cs_search-results').attr("data-contenttype") !== false ? el.find('.cs_search-results').attr("data-contenttype").split(',') : "";
        this.showMoreLabel = typeof(el.find('.cs_search-component-pagenation').attr("data-loadmorelabel")) !== 'undefined' && el.find('.cs_search-component-pagenation').attr("data-loadmorelabel") !== false ? el.find('.cs_search-component-pagenation').attr("data-loadmorelabel") : "Please author a show more label to be shown here";

        this.showRecentsearches = obj.hasOwnProperty("showRecentsearches") ? obj.showRecentsearches : "";
        this.loadNumberOfResults = obj.hasOwnProperty("loadNumberOfResults") ? obj.loadNumberOfResults : "";
        this.q = obj.hasOwnProperty("q") && obj.q.length > 0 ? obj.q : urlParams.hasOwnProperty("cs_query") ? urlParams.cs_query : "";
        this.noResultsLabel = typeof(el.find('.cs_search-results').attr("data-noResultsLabel")) !== 'undefined' && el.find('.cs_search-results').attr("data-noResultsLabel") !== false ? el.find('.cs_search-results').attr("data-noResultsLabel") : "";


        if (ves.utils.getParameterByName('filters').length) {
            var selected_filters = {};
            var filter = "";
            var data = ves.utils.urlParameters()['filters'].split(',');
            for (var f=0; f<data.length; f++){
                var thisFilter = data[f];
                thisFilter = thisFilter.split("|");
                filter = thisFilter[0];
                if (!selected_filters.hasOwnProperty(filter)){
                    selected_filters[filter] = [];
                }
                selected_filters[filter].push(thisFilter[1]);
            }
            this.selected_filters = selected_filters;
        }
    };

    CloudSearch.components.SearchConfig = SearchConfig;

})();
(function ($) {

	if (typeof (CloudSearch) !== 'undefined') {
		$.extend(CloudSearch.components.Filter.prototype, {
			set_data: function (data) {
				// console.log('filter-override facets >> '+ JSON.stringify(data.facets));
				var $filter = this.$ctx.parents('[data-facet]');
				var allLabel = $filter.data('allLabel');

				var templ = ejs.compile($('#filters_template', this.$ctx).html());

				if ($filter.data('facetPrefix') !== undefined) {
					var facetPrefix = $filter.data('facetPrefix').split('|');

					var i = 0;
					for (var key in data.facets) {
						if (data.facets.hasOwnProperty(key)) {
							data.facets[key].prefix = facetPrefix[i]
						}
						i++;
					}
				}

				if ($filter.data('facetSingular') !== undefined) {
					var facetSingular = $filter.data('facetSingular').split('|');

					var i = 0;
					for (var key in data.facets) {
						if (data.facets.hasOwnProperty(key)) {
							data.facets[key].singular = facetSingular[i]
						}
						i++;
					}
				}

				if ($filter.data('facetPlural') !== undefined) {

					var facetPlural = $filter.data('facetPlural').split('|');

					var i = 0;
					for (var key in data.facets) {
						if (data.facets.hasOwnProperty(key)) {
							data.facets[key].plural = facetPlural[i]
						}
						i++;
					}
				}

				if ($filter.data('facetLabels') !== undefined) {
					var matchFacet = false;
					if ($filter.data('facetLabels').indexOf('~') > -1) {
						matchFacet = true;
					}
					var facetLabels = $filter.data('facetLabels').split('|');

					var i = 0;

					for (var key in data.facets) {
						if (data.facets.hasOwnProperty(key) && key !== data.facets[Object.keys(data.facets)[Object.keys(data.facets).length - 1]]) {
							if (matchFacet === true) {
								for (var j in facetLabels) {
									var facetLabel = facetLabels[j].split('~');
									if (facetLabel[1] !== undefined) {
										if (data.facets[key].label === facetLabel[1]) {
											data.facets[key].facetLabel = facetLabel[0];
										}
									}
								}

							} else {
								data.facets[key].facetLabel = facetLabels[i];
							}
						}
						i++;
					}
				}

				var facetSubCategoryData = $('.cs_search-filter').attr('data-facetWithSubCategories');

				if (facetSubCategoryData !== undefined) {
					data.facetWithSubCategories = JSON.parse(facetSubCategoryData);
				}

				var output = templ(data);
				$('.level1').html(output);

				/**
				 * passing param - resourcesfilter.html
				 * data-generic-landing-page="${comp.genericProp}"
				 * data-associated-Resource-Filterr="${comp.associateResourceFilter}"
				 * data-filter-landingpage-info="${comp.resourceFilterInfo}"
				 */

                var dataGenericLandingPage = $('.cs_search-filter').attr('data-generic-landing-page');
				if (dataGenericLandingPage != undefined) {
					data.dataGenericLandingPage = dataGenericLandingPage;
					//console.log("[filter-override] dataGenericLandingPage = " + dataGenericLandingPage)
				}

				var dataAssociatedResourceFilter = $('.cs_search-filter').attr('data-associated-Resource-Filter');
				if (dataAssociatedResourceFilter != undefined) {
					data.dataAssociatedResourceFilter = dataAssociatedResourceFilter;
					//console.log("[filter-override] dataAssociatedResourceFilter = " + dataAssociatedResourceFilter)
				}

				var dataFilterLandingpageInfo = $('.cs_search-filter').attr('data-filter-landingpage-info');
				data.dataFilterLandingpageInfo = [];
				if (dataFilterLandingpageInfo != undefined) {
					data.dataFilterLandingpageInfo = JSON.parse(dataFilterLandingpageInfo);
                    //console.log("[filter-override] data.dataFilterLandingpageInfo = " + dataFilterLandingpageInfo);
				}


				if (ves.utils.getParameterByName('filters').length) {
					var filters = ves.utils.urlParameters()['filters'].split(',');
					$('.clear-all').removeClass('disableReset');
					for (var i = 0; i < filters.length; i++) {
						$filter.find('[data-value="' + filters[i] + '"]').attr('aria-checked', true);
					}
				}

                // On Page load activate active filters for landing pages. eg Activate 5G filter for 5g page on page load

				var aflist = "";
				var datasetList = [];
				var activeFilters = $('.facets [aria-checked=true]', this.$ctx).map(function (i, e) {
					aflist += '<li>' + this.innerText + '<a aria-label="Clear Filter" href="javascript:void(0);" data-value2="' + this.dataset.value + '" ></a>';
					datasetList.push(this.dataset.value);
					return ('<li><a href="javascript:void(0);">' + this.innerText + '</a>');
				});

				$('.active-filter-list').html(aflist);
				$('.active-filter-list li a').on('click', function (e) {
					event.stopPropagation();
					event.stopImmediatePropagation();
					$("[data-value='" + this.dataset.value2 + "']").click();
				});

				(activeFilters.length > 0) ? $(".title1").removeClass("title1 d-none").addClass("title1"): $(".title1").removeClass("title1").addClass("title1 d-none");
				// end active filters               

				this.setup();

				switch ($filter.data('filterType')) {
					case "search":
						this.search_events(data);
						break;
					case "product":
						this.product_events(data);
						break;
					case "sentence":
						this.sentence_events(data);
						break;
					case "resources":
						this.resources_events(data);
						break;
					default:
						this.search_events(data);
				}

			},
			search_events: function (data) {
				var self = this;
				var $filter = self.$ctx.parents('[data-facet]');

				//close all dropdowns
				$(document).on('click', function (e) {
					$('.filter-dropdown').removeClass('expand');
				});

				this.$ctx.find('.filter-dropdown-button').on('click', function (e) {
					e.preventDefault();
					e.stopPropagation();
					$(this).parent().toggleClass('expand');
				});

				this.$ctx.find('.filters-button').on('click', function (e) {
					e.preventDefault();
					e.stopPropagation();
					$(this).parent().find('.filters-window').toggleClass('open');
					$('body').addClass('stop-scrolling');
				});

				this.$ctx.find('.filters-close').on('click', function (e) {
					e.preventDefault();
					e.stopPropagation();
					$(this).parent().removeClass('open');
					$('body').removeClass('stop-scrolling');
				});

				this.$ctx.find('.filters-window-apply-button').on('click', function (e) {
					e.preventDefault();
					e.stopPropagation();
					$(this).closest('.filters-window').removeClass('open');
					$('body').removeClass('stop-scrolling');
				});

				this.$ctx.find('.clear-all').on('click', function (e) {
					e.preventDefault();
					self.clear_all();
				});

				this.$ctx.find('.level2 ul li a').on('click clearall', function (e) {
					e.preventDefault();
					e.stopPropagation();
					var $target = $(e.currentTarget);
					var $dropdown = $target.parents('.level2');

					if ($target.is('.default')) {
						$dropdown.find('ul li a').removeAttr('aria-checked');
						$target.attr('aria-checked', 'true');
					} else if ($target.is('[aria-checked=true]')) {
						$target.removeAttr('aria-checked');
					} else {
						$target.attr('aria-checked', 'true');
					}

					var itemsSelected = $dropdown.find('[aria-checked="true"]').not('.default').length;
					if (itemsSelected > 1) {
						$dropdown.find('a.default').removeAttr('aria-checked');
					} else if (itemsSelected == 1) {
						$dropdown.find('a.default').removeAttr('aria-checked');
					} else {
						$dropdown.find('a.default').attr('aria-checked', true);
					}

					self.set_filters();
				});
			},
			product_events: function (data) {
				var self = this;
				var $filter = self.$ctx.parents('[data-facet]');

				//close all dropdowns
				$(document).on('click', function (e) {
					$('.level1 ul li').removeClass('active');
				});

				this.$ctx.find('.arrow-btn').on('click', function (e) {
					e.preventDefault();
					e.stopPropagation();
					$(this).parent().toggleClass('active');
				});

				this.$ctx.find('.level2 ul li a').on('click clearall', function (e) {
					e.preventDefault();
					var $target = $(e.currentTarget);
					var $dropdown = $target.parents('.level2');
					var $filterLabel = $target.parents('.level2').parent().find('a.arrow-btn');

					$dropdown.find('ul li a').removeAttr('aria-checked');
					$target.attr('aria-checked', 'true');

					var $itemsSelected = $dropdown.find('[aria-checked="true"]').not('.default');
					var itemsSelected = 0;
					var label = ''

					$itemsSelected.each(function () {
						itemsSelected = itemsSelected + parseInt($(this).data('count'));
					})

					if ($itemsSelected.length > 0) {
						label = $target.text() + ' ' + '<span>(' + itemsSelected + ')</span>';
						$dropdown.find('a.default').removeAttr('aria-checked');
					} else {
						$dropdown.find('a.default').attr('aria-checked', true);
						label = $filterLabel.data('facetLabel') + ' ' + '<span>(' + data.hits.found + ')</span>';
					}
					$filterLabel.html(label);

					self.set_filters();
				});
			},
			sentence_events: function (data) {
				var self = this;
				var $filter = self.$ctx.parents('[data-facet]');
				var touchmoved = false;

				this.$ctx.find('.arrow-btn').on('click touchend', function (e) {
					e.preventDefault();
					e.stopPropagation();
					if (touchmoved) {
						return;
					}
					if (!$(this).parent().hasClass('active')) {
						self.$ctx.find('.dropdown-select').removeClass('active');
					}
					$(this).parent().toggleClass('active');
				});

				//close all dropdowns
				$(document).on('click', function (e) {
					self.$ctx.find('.dropdown-select').removeClass('active');
				});

				//logic for iOS devices to close dropdowns

				$(document).on('touchend', function (e) {
					if (touchmoved !== true) {
						self.$ctx.find('.dropdown-select').removeClass('active');
					}
				}).on('touchmove', function (e) {
					touchmoved = true;
				}).on('touchstart', function () {
					touchmoved = false;
				});
				this.$ctx.find('.level2 ul li a').on('touchstart touchend touchmove', function (e) {
					touchmoved = true;
				});
				// end of the iOS dropdowns                

				this.$ctx.find('.level2 ul li a').on('click clearall', function (e) {
					e.preventDefault();
					e.stopPropagation();
					var $target = $(e.currentTarget);
					var $dropdown = $target.parents('.level2');
					var $filterLabel = $target.parents('.level2').parent().find('a.arrow-btn');

					if ($target.is('.default')) {
						$dropdown.find('ul li a').removeAttr('aria-checked');
						$target.attr('aria-checked', 'true');
					} else if ($target.is('[aria-checked=true]')) {
						$target.removeAttr('aria-checked');
					} else {
						$target.attr('aria-checked', 'true');
					}

					var itemsSelected = $dropdown.find('[aria-checked="true"]').not('.default').length;
					var label = '';
					if (itemsSelected > 1) {
						label = itemsSelected + ' ' + $filterLabel.data('plural');
						$dropdown.find('a.default').removeAttr('aria-checked');
					} else if (itemsSelected == 1) {
						label = '1 ' + $filterLabel.data('singular');
						$dropdown.find('a.default').removeAttr('aria-checked');
					} else {
						label = $dropdown.find('.default').html();
						$dropdown.find('a.default').attr('aria-checked', true);
					}
					$filterLabel.html(label);

					self.set_filters();
				});
			},
			resources_events: function (data) {
				var self = this
				var $filter = self.$ctx.parents('[data-facet]')

				// Expand Topic by default
				// $(".facet-accordion:nth-child(1)").addClass("expand");
				// $(".vz-dropdown.arrow-btn")[0].setAttribute('aria-expanded', 'true');

				// Get the modal
				var modal = document.getElementById('myModal')

				// Get the button that opens the modal
				var btn = document.getElementById('myBtn')

				//close all dropdowns
				$(document).on('click', function (e) {
					$('.filter-dropdown').removeClass('active')
				})

				this.$ctx.find('.filter-dropdown-button').on('click', function (e) {
					e.stopPropagation()
					$(this).parent().toggleClass('active')
				})

				this.$ctx.find('.filter-dropdown .arrow-btn').on('click', function (e) {
					e.preventDefault()
					e.stopPropagation()
					$(this).parent().toggleClass('expand')
					var toggleExpand =
						e.target.getAttribute('aria-expanded') === 'true' ? 'false' : 'true'
					e.target.setAttribute('aria-expanded', toggleExpand)
				})

				//Newly Added for Resource Filter Sub-category
				this.$ctx
					.find('.filter-dropdown .facet-sub-category .sub-category-label')
					.on('click', function (e) {
						e.preventDefault()
						e.stopPropagation()
						// console.log('arrow button clicked');
						$(this).parents().eq(1).toggleClass('expand')
					})

				this.$ctx
					.find(
						'.filter-dropdown .facet-sub-category .sub-category-label:after'
					)
					.on('click', function (e) {
						e.preventDefault()
						e.stopPropagation()
						// console.log('arrow button clicked');
						$(this).parents().eq(1).toggleClass('expand')
					})

				this.$ctx
					.find('.filter-dropdown .facet-sub-category .sub-category-info')
					.on('click', function (e) {
						e.preventDefault()
						e.stopPropagation()
						// Display modal on click of 'info' icon in subcategories
						modal.style.display = 'block'
					})

				//------------- Below code is for Modal window for Subcategories -------------------------------------

				// Get the modal
				var modal = document.getElementById('myModal')

				// Get the button that opens the modal
				var btn = document.getElementById('myBtn')

				// Get the <span> element that closes the modal
				var span = document.getElementsByClassName('close')[0]

				// When the user clicks on <span> (x), close the modal
				span.onclick = function () {
					modal.style.display = 'none'
				}

				// When the user clicks anywhere outside of the modal, close it
				window.onclick = function (event) {
					if (event.target == modal) {
						modal.style.display = 'none'
					}
				}

				//----------------------------- End of Modal Window code ----------------------------------------------------

				this.$ctx.find('.clear-all').on('click', function (e) {
					e.preventDefault()
					self.clear_all()
				})

				// Filter By - Featured checkbox listener
				this.$ctx.find('.activefilter').on('click clearall', function (e) {
					e.preventDefault()
					e.stopPropagation()
					var $target = $(e.target)

					if ($target.is('[aria-checked=true]')) {
						$target.removeAttr('aria-checked')
						$target.removeAttr('data-value')
					} else {
						$target.attr('aria-checked', 'true')
						$target.attr('data-value', 'featured|true')
					}
					self.set_filters()
				})

				/**
				 * Adding path for urls
				 * Uncomment line 458 for testing with .html or adding url params for inner pages
				 */

				var resourceLinkList = $('.resources-nav-link')
				var resourcePathBegin
				var resourcePathEnd

				if (window.location.pathname.indexOf('.html') != -1) {
					resourcePathBegin =
						data.dataAssociatedResourceFilter === undefined
							? './resources/'
							: './'
					resourcePathEnd = '.html'
				} else {
					resourcePathBegin =
						data.dataAssociatedResourceFilter === undefined ? './' : '../'
					resourcePathEnd = '/'
				}

				for (var p = 0; p < resourceLinkList.length; p++) {
					for (var q = 0; q < data.dataFilterLandingpageInfo.length; q++) {
						if (
							data.dataFilterLandingpageInfo[q].Title != '' &&
							resourceLinkList[p].innerText ===
								data.dataFilterLandingpageInfo[q].Title
						) {
							var path = data.dataFilterLandingpageInfo[q].path // + ".html"; // ?filters=" + resourceLinkList[p].parentElement.getAttribute("data-value");
							var tpath =
								resourcePathBegin + path.split('/').pop() + resourcePathEnd
							resourceLinkList[p].parentElement.setAttribute('href', tpath)
							//resourceLinkList[p].parentElement.setAttribute("href", path);
						}
					}
				}

				/**
				 * RESOURCE NAV LEFT
				 * Activate Active Filters on checkbox click
				 */

				this.$ctx.find('.level2 ul li a').on('click clearall', function (e) {
					if (e.target.className != 'resources-nav-link') {
						e.preventDefault()
						e.stopPropagation()
						var $target = $(e.currentTarget)
						//var $dropdown = $target.parents('.level2');
						var $dropdown = $target.parents('.facet-accordion')
						var $filterLabel = $target
							.parents('.level2')
							.parent()
							.find('a.arrow-btn')

						if ($target.is('[aria-checked=true]')) {
							$target.removeAttr('aria-checked')
						} else {
							$target.attr('aria-checked', 'true')
						}

						var itemsSelected = $dropdown.find('[aria-checked="true"]').length
						var label = ''
						if (itemsSelected > 0) {
							label =
								$filterLabel.data('facetLabel') + ' (' + itemsSelected + ')'
						} else {
							label = $filterLabel.data('facetLabel')
						}

						$filterLabel.find('span').html(label)

						/**
						 * Active filters
						 * User selected checkbox filter will be activated
						 */
						var aflist = ''
						var datasetList = []
						var activeFilters = $('.facets [aria-checked=true]', this.$ctx).map(
							function (i, e) {
								aflist +=
									'<li>' +
									this.innerText +
									'<a aria-label="Clear Filter" href="javascript:void(0);" data-value2="' +
									this.dataset.value +
									'" ></a>'
								datasetList.push(this.dataset.value)
								return (
									'<li><a href="javascript:void(0);">' + this.innerText + '</a>'
								)
							}
						)

						$('.active-filter-list').html(aflist)

						$('.active-filter-list li a').on('click', function (e) {
							event.stopPropagation()
							event.stopImmediatePropagation()
							$("[data-value='" + this.dataset.value2 + "']").click()
						})

						activeFilters.length > 0
							? $('.title1').removeClass('title1 d-none').addClass('title1')
							: $('.title1').removeClass('title1').addClass('title1 d-none')
						// end active filters

						if (
							data.dataAssociatedResourceFilter != undefined &&
							activeFilters.length === 0
						) {
							if (window.location.pathname.indexOf('.html') === -1) {
								window.location.href = '../'
							} else {
								window.location.href = '../resources.html'
							}
						}

						/**
						 * LANDING PAGE
						 * On click on checkbox navigate user to Insite & A Resource page with filter selected
						 */

						if (
							$('.facets [aria-checked=true]', this.$ctx).length > 1 &&
							data.dataAssociatedResourceFilter != undefined
						) {
							if (window.location.pathname.indexOf('.html') != -1) {
								window.location.href =
									'../resources.html?filters=' +
									encodeURI(datasetList.toString())
							} else {
								window.location.href =
									'../?filters=' + encodeURI(datasetList.toString())
							}
						}

						self.set_filters()
					}
				})

				// On page load activate associated filter from dataAssociatedResourceFilter eg. activate 5g filter in 5g page
				var resourceLinkList = $('.resources-nav-link')
				for (var k = 0; k < resourceLinkList.length; k++) {
					if (
						resourceLinkList[k].innerText == data.dataAssociatedResourceFilter
					) {
						resourceLinkList[k].parentElement.click()
						break
					}
				}

				// sticky filters
				if (typeof window.document.documentMode === "undefined") { // disable on IE
					var mq = window.matchMedia('(min-width: 768px)'),
						filters = document.querySelector('.resourcesfilter'),
						secondaryNav = document.querySelector('.secondarynav'),
						windowTop = window.scrollY,
						direction
					function dodgeNav() {
						if (mq.matches) {
							filters.style.position = 'sticky'
							if (direction === 'down') {
								filters.style.top = secondaryNav.offsetHeight + 'px'
							} else {
								filters.style.top =
									secondaryNav.offsetHeight + secondaryNav.offsetTop + 'px'
							}
						} else {
							filters.style.position = 'relative'
							filters.style.top = '0'
						}
					}
					document.addEventListener('scroll', function () {
						direction = window.scrollY > windowTop ? 'down' : 'up'
						windowTop = window.scrollY
						dodgeNav()
					})
					mq.addEventListener("change", dodgeNav())
				}
				// end sticky filters

			},
			set_filters: function () {
				var filters = $('[aria-checked=true]', this.$ctx).map(function (i, e) {
					return $(e).data('value');
				}).get();
				this.$ctx.prop('filters', filters);
				this.$ctx.trigger('filter_change', [filters]);
			},
			clear_all: function (e) {
				this.$ctx.find('[aria-checked=true]').each(function (count, value) {
					if (count !== 0) {
						$(this).removeAttr('aria-checked')
					}
				});

				this.$ctx.find('[aria-checked=true]').trigger('clearall');
				this.reset_sort_by();
			},
			reset_sort_by: function () {
				var sortOptions = this.$ctx.find('.sort');
				sortOptions.find('.sort-item').removeClass('selected');
				sortOptions.find('.sort-item:first').addClass('selected');
				sortOptions.find('.sort-item.selected').trigger('click');
			}
		})
	}

})($);
(function($) {
    if (typeof(CloudSearch) !== 'undefined'){
        $.extend(CloudSearch.components.Pagination.prototype, {
            createPagination: function() {

                var $pagination = $(this.options.target).parents('.cs_search-component-pagenation');
                var $buttons = $pagination.find('.cs_pagination-buttons');
                var $dropdown = $pagination.find('.cs_pagination-dropdown');
                var $options = $pagination.find('.options');

                var resultsNumber = this.options.data.hits.found;
                var resultsPerPage = parseInt(this.options.resultsPerPage);
                var totalPages = Math.ceil(resultsNumber / resultsPerPage);
                var currentPage = this.options.activePageNumber;
                var prevLabel = $pagination.data('previouslabel');
                var nextLabel = $pagination.data('nextlabel');
                var ofLabel = $pagination.data('oflabel');
                var showingLabel = $pagination.data('showinglabel');
                var pageLink = "";

                $buttons.empty();
                $options.empty();

                var prevEnabled = '<div class="cta-rounded-button-black-outline"><a class="cs_pagination-link back-link vz-button-link" data-loc="Content:pagination:Resources" href="#">'+prevLabel+'</a></div>';
                var prevDisabled = '<div class="cta-rounded-button-gray-outline"><a class="cs_pagination-link back-link vz-button-link" data-loc="Content:pagination:Resources" href="#">'+prevLabel+'</a></div>';
                var nextEnabled = '<div class="cta-rounded-button-black-outline" ><a class="cs_pagination-link forward-link vz-button-link" data-loc="Content:pagination:Resources" data-forward="true" href="#">'+nextLabel+'</a></div>';
                var nextDisabled = '<div class="cta-rounded-button-gray-outline"><a class="cs_pagination-link forward-link vz-button-link" data-loc="Content:pagination:Resources" data-forward="true" href="#">'+nextLabel+'</a></div>';

                $dropdown.removeClass('dropdown-active');

                if (resultsNumber <= this.options.resultsPerPage) return;

                if (currentPage == 1) {
                    $buttons.append(prevDisabled);
                    $buttons.append(nextEnabled);
                } else if (currentPage === totalPages) {
                    $buttons.append(prevEnabled);
                    $buttons.append(nextDisabled);
                } else {
                    $buttons.append(prevEnabled);
                    $buttons.append(nextEnabled);
                }
                

                // $(".vz-checkbox").uniqueId();
                
                $dropdown.addClass('dropdown-active');

                $dropdown.find('button span').text(showingLabel+' '+currentPage+' '+ofLabel+' '+totalPages);

                for (var i=1; i<=totalPages; i++){
                    pageLink = '<li role="option"><a class="cs_pagination-link vz-text-link" data-loc="Content:pagination:Resources" data-link-number="'+i+'" href="#"> '+showingLabel+' '+i+' '+ofLabel+' '+totalPages+'</a></li>';
                    $options.append(pageLink);
                }

                this.addBacktoTopHandler();
                this.addPaginationLinkHandler();
                this.addDropdownHandler($dropdown); 
                this.addpopstateHandler();
                this.addResetHandler();             
            },
            addBacktoTopHandler : function() {
                $('.cs_pagination-link').click(function(e){
                    e.preventDefault();
                    $("html, body").animate({ scrollTop: 275 }, 500);
                });
            },
            addDropdownHandler: function($dropdown){

                //close dropdowns
                $(document).on('click', function(e){
                    $dropdown.find('button').removeClass('active');
                    $dropdown.find('.task-options').removeClass('turn');
                });

                $dropdown.find('button').off('click').on('click', function(e){
                    e.stopPropagation();
                    $(this).next().toggleClass('turn');
                    $(this).toggleClass('active');
                });
            },
            addPaginationLinkHandler: function(){
                $('.cs_pagination-link').click(function(e){
                    if (this.options.searchObj.config.paginationType === "showMore"){
                        this.options.searchObj.config.persistResults = true;
                    }

                    var clickedLink = $(e.currentTarget);
                    var resultsPerPage = parseInt(this.options.resultsPerPage);
                    var pageNumber = ves.utils.getParameterByName('page').length ? parseInt(ves.utils.getParameterByName('page')): 1;
                    e.preventDefault();
                    if (clickedLink.attr('data-link-number')){
                        this.options.searchObj.config.page = parseInt(clickedLink.attr('data-link-number'));
                        this.options.searchObj.config.start = (parseInt(clickedLink.attr('data-link-number')) - 1) * resultsPerPage;
                    } else {
                        if (clickedLink.hasClass('back-link')){
                            if (pageNumber !== 1){
                                
                                this.options.searchObj.config.page = pageNumber - 1;
                                this.options.searchObj.config.start = (this.options.searchObj.config.page - 1) * resultsPerPage;
                            }
                        } else {
                            this.options.searchObj.config.page = pageNumber + 1;
                            this.options.searchObj.config.start = (this.options.searchObj.config.page - 1) * resultsPerPage;
                        }
                    }

                    var url = "";
                    var pathname = window.location.pathname;
                    var hash = window.location.hash;
                    var params = ves.utils.urlParameters();

                    params["page"] = this.options.searchObj.config.page;

                    var query = ves.utils.toQueryString(params).length ? '?'+ves.utils.toQueryString(params) : '';

                    url = pathname+query+hash;
                    if (history.pushState) {
                        history.pushState({},"",url);
                    }

                    var newSearchOptions = this.options.searchObj.config;

                    new CloudSearch.components.SearchQuery(newSearchOptions, function(url){
                        this.options.searchObj.loadResults(url);
                    }.bind(this));
                }.bind(this));
            },
            addpopstateHandler: function(){
                $(window).off('popstate.pagination');
                $(window).on('popstate.pagination', function(){

                    if (ves.utils.getParameterByName('page').length) {
                        var pageNumber = parseInt(ves.utils.getParameterByName('page'));
                        var startNumber = parseInt(pageNumber - 1);
                        this.options.searchObj.config.page = pageNumber;
                        this.options.searchObj.config.start = startNumber * 12;
                    }

                    if (ves.utils.getParameterByName('filters').length) {
                        var selected_filters = {};
                        var filter = "";
                        var $filter = $('.cs_search-filter');
                        var data = ves.utils.urlParameters()['filters'].split(',');
                        $filter.find('[aria-checked="true"]').removeAttr('aria-checked');
                        for (var f=0; f<data.length; f++){
                            $filter.find('[data-value="'+data[f]+'"]').attr('aria-checked', 'true');
                            var thisFilter = data[f];
                            thisFilter = thisFilter.split("|");
                            filter = thisFilter[0];
                            if (!selected_filters.hasOwnProperty(filter)){
                                selected_filters[filter] = [];
                            }
                            selected_filters[filter].push(thisFilter[1]);
                        }
                        this.options.searchObj.config.selected_filters = selected_filters;
                    }

                    if (ves.utils.getParameterByName('sortby').length) {
                        var sortBy = ves.utils.getParameterByName('sortby');
                        $('.cs_sort-options').find('[data-sortby]').removeClass('selected');
                        $('.cs_sort-options').find('[data-sortby="'+sortBy+'"]').addClass('selected');
                        this.options.searchObj.config.sortby = sortBy;
                    }

                    var newSearchOptions = this.options.searchObj.config;


                    //newSearchOptions.start = parseInt(this.options.start);
                    new CloudSearch.components.SearchQuery(newSearchOptions, function(url){
                        this.options.searchObj.loadResults(url);
                    
                    }.bind(this));  
                }.bind(this));
                
            },
            addResetHandler: function(){

                $('.clear-all').on('click.test', function(e){

                    var currentPage = this.options.searchObj.config.page;

                    this.options.searchObj.config.page = 1;
                    this.options.start = 0;

                    var updateurl = window.location.protocol + "//" + window.location.host + window.location.pathname + '?' + "page=" + currentPage;
                    window.history.pushState({path:updateurl},'',updateurl);

                    var newSearchOptions = this.options.searchObj.config;

                    newSearchOptions.start = parseInt(this.options.start);
                    new CloudSearch.components.SearchQuery(newSearchOptions, function(url){
                        this.options.searchObj.loadResults(url);
                    
                    }.bind(this));  
                }.bind(this));

                $('.clear-all').off('click.test');
                
            },

        })
    }

})($);

    
(function () {

    var SearchResult = function(data, target, count, options,nonManualTilesSize){
        this.$target = target;
        this.config = data;
        this.options = options;
        this.count = count;
        this.init(data,nonManualTilesSize);
    };

    SearchResult.prototype = {
        init: function(data,nonManualTilesSize){
            switch(data.resultType) {
                case "standard":
                    this.generateRowResult(data.resultData);
                    break;
                case "custom":
                    this.generateBoxResult(data.resultData);
                    break;
                case "table":
                    this.generateTableResult(data.resultData);
                    break;
                case "pattern":
                    this.generatePatternResult(data.resultData,nonManualTilesSize);
                    break;
                case "category":
                    this.generateCategoryResult(data.resultData);
                    break;
                case "featured":
                    this.generateFeaturedResult(data.resultData, data.highlightResultData);
                    break;
                case "resourcelist":
                    this.generateReourceListResult(data.resultData,nonManualTilesSize);
                    break;
                default:
                    this.generateRowResult(data.resultData);
            }
        },
        generateReourceListResult: function(data,nonManualTilesSize){
            var self = this;
            var totalManualTiles = this.$target.find('.searchtile').length;            
            var isRelevanceSort = $(".cs_search-sort-search-results .cs_sort-options li.selected").data('sortby') === 'relevance' ? true : false;
            var hasSelectedFilters = self.options.hasOwnProperty("selected_filters") && Object.keys(this.options.selected_filters).length !== 0;
            var embeddedCount = hasSelectedFilters ? this.count : this.count + totalManualTiles;
            var featureCard = data.featured === "true" ? "featured" : ""

            if (!hasSelectedFilters) {
                checkEmbeddedContent();
            }

            function checkEmbeddedContent() {
                var embedContent = false;
                var $searchTile;

                if (self.options.start === 0) {
                    var $possibleManualTile = $(".searchtilesection").find('.searchtile [data-position="'+(embeddedCount+1)+'"]');
                    if ($possibleManualTile.length) {
                        var embedContent = true;
                        var $searchTile = $possibleManualTile.parent();
                    }
                }



                if (embedContent) {
                    //Find if our category <div> already exists within the results container
                    var $containers = self.$target.find('.pattern-container');

                    if ($containers.length === 0 || (embeddedCount) % 99999 === 0) {
                        var containerHtml = '<div class="pattern-container"></div>';
                        self.returnHtml(containerHtml);
                    }

                    var $container = self.$target.find('.pattern-container').last();

                    if ((embeddedCount) % 99999 === 0 || (embeddedCount - 1) % 99999 === 0) {

                        var $resultHtml = $('<div class="cs_row-large-result embedded-content"><div class="searchtile"></div></div>');
                        $resultHtml.find('.searchtile').append($searchTile.html())
                        self.returnTargetedHtml($container, $resultHtml);
                    } else {

                        var $resultHtml = $('<div role="img" aria-label="'+ data.title +'" class="cs_row-small-result embedded-content"><div class="searchtile"></div></div>');
                        $resultHtml.find('.searchtile').append($searchTile.html())
                        self.returnTargetedHtml($container, $resultHtml);
                    }

                    embeddedCount++;
                    checkEmbeddedContent();
                }
            }
            //For page-type
            var urlPath = data.url;
            var res="resources";
            var resLenght = res.length;
            var pageType = "";

            if(urlPath.indexOf(res) !== -1){
              var pageTypePath= urlPath.substring(urlPath.indexOf(res)+resLenght+1);
              if(pageTypePath)
	              {
		            if(pageTypePath.indexOf("/") !== -1)
		            	 pageType = pageTypePath.substring(0,pageTypePath.indexOf("/"));
		          }
            }

            //Find if our category <div> already exists within the results container
            var $containers = this.$target.find('.pattern-container');
            if ($containers.length === 0 || embeddedCount % 99999 === 0) {
                var containerHtml = '<div class="pattern-container"></div>';
                this.returnHtml(containerHtml);
            }

            var $container = this.$target.find('.pattern-container').last();


            if (true){ //embeddedCount % 99999 === 0 || (embeddedCount - 1) % 99999 === 0) {
                var resultPath = (typeof data.referencepath !== "undefined") ? data.referencepath : data.url;
                var vanityPath = (typeof data.url !== "undefined") ? data.url.replace(/www98/,"www") : '';
                var videoPath = (typeof data.exturl !== "undefined") ? data.exturl : '';
                var videoPathPlus = videoPath + '?rel=0&autoplay=1&mute=1';
                var resourceType = '';
                if(typeof data.expertinsightscontenttype !== 'undefined' && data.expertinsightscontenttype.length> 0)
                {
                	resourceType = data.expertinsightscontenttype;
                }
                if(typeof data.productresourcescontenttype !== 'undefined' && data.productresourcescontenttype.length> 0)
                {
                	resourceType = resourceType + data.productresourcescontenttype;
                }

                var content_type = (typeof data.content_type !== "undefined") ? data.content_type : '';

                if (typeof data.url !== 'undefined' && data.url.split('.')[data.url.split('.').length -1] === 'pdf') {
                data['image'] = "/business/content/dam" + data.url + '/jcr:content/renditions/cq5dam.thumbnail.480.960.png';
                target = "_blank";
                isPDF = true;
            	}
                var target = '_self';
                var isPDF = false;

                // Add images for PDFs based on renditions
                if (typeof data.path !== 'undefined' && data.path.split('.')[data.path.split('.').length -1] === 'pdf') {
                    data['image'] = data.path + '/jcr:content/renditions/cq5dam.thumbnail.480.960.png';
                    data['image'] = "https://d23uobcja6cuc.cloudfront.net/business/bin/get/asset.png"+data.path.replace(/\/content\/dam/,"");
                    target = "_blank";
                    isPDF = true;
                }

                if (content_type === 'videoasset') {
                    data['image'] = data.path + '/jcr:content/renditions/cq5dam.thumbnail.480.360.png';
                    data['image'] = "https://d23uobcja6cuc.cloudfront.net/business/bin/get/asset.png"+data.path.replace(/\/content\/dam/,"");
                }

                // When there is no image, pull from generic image path
                if (typeof data['image'] == 'undefined' && typeof $('.cs_search-results').data('imagePaths') !== "undefined") {
                    var items = $('.cs_search-results').data('imagePaths');
                    data['image'] = items[Math.floor(Math.random()*items.length)];
                }

                var caption = '';
                if(typeof data.expertinsightscontenttype !== 'undefined' && data.expertinsightscontenttype.length> 0)
                {
                    caption = String(data.expertinsightscontenttype).replace(/\,/g, ", ");
                }
                if (content_type === 'videoasset') {
                    if (caption !== '')
                        var $resultHtml = $('<div role="img" aria-label="'+ data.title +'" class="cs_row-large-result '+ featureCard +'"><a class="cs_result-link vz-text-link" data-loc="Content:Grid:Resources:'+ pageType +':'+ data.title +'" href="'+ videoPathPlus +'" target="'+target+'" resource-type="'+ pageType +'"></a></div>');
                    else
                    {
                    	pageType = "Unknown";
                        var $resultHtml =  $('<div role="img" aria-label="'+ data.title +'" class="cs_row-large-result '+ featureCard +'"><a class="cs_result-link vz-text-link" data-loc="Content:Grid:Resources:'+ pageType +':'+ data.title +'" href="'+ videoPathPlus +'" target="'+target+'"></a></div>');
                 	}
                 } else {
                     if(caption !== '')
                        var $resultHtml = $('<div role="img" aria-label="'+ data.title +'" class="cs_row-large-result '+ featureCard +'"><a class="cs_result-link vz-text-link" data-loc="Content:Grid:Resources:'+ pageType +':'+ data.title +'" href="'+ vanityPath +'" target="'+target+'" resource-type="'+ pageType +'"></a></div>');
                     else
                     	{
                     		pageType = "Unknown";
                        	var $resultHtml = $('<div role="img" aria-label="'+ data.title +'" class="cs_row-large-result '+ featureCard +'"><a class="cs_result-link vz-text-link" data-loc="Content:Grid:Resources:'+ pageType +':'+ data.title +'" href="'+ vanityPath +'" target="'+target+'"></a></div>');
                 		}
                 }


                var description = (typeof data.description !== 'undefined')? data.description : '';
              
                var featured = (data.featured === "true") ? "featured" : "featured d-none";
                var popular = Number(data.popularity) > 15 ? "<span class='popular'>Popular</span>" : ""
                var pic =  data.image;
                var minutes = (typeof data.read_time !== 'undefined') ? data.read_time : '';
                var showMinutes = (typeof data.read_time !== 'undefined') ? 'min-read' : 'min-read d-none';
                var showDate = (typeof data.created_date !== 'undefined') ? 'created-date' : 'created-date d-none';
                if(showDate === "created-date") {
                var date = Date.parse(data.created_date);
                var today = new Date(date).toString().slice(4, 10) + ', ' + new Date(date).toString().slice(11, 15);
                } 

				$imageHtml = $('<div style="padding-top: 56.25%; background-color: grey; background-size: cover; background-position: center; background-image: url(\''+ pic +'\''+ ');'+'"></div>');

                $resultHtml.find('a').append($imageHtml);

                $propHtml = $('<div class="card_body"><div class="meta-top"><span class="' + featured +'">Featured</span>' + popular + '<span class="' + showDate + '">'+today+'</span></div><div class="cs_result-field-title h3_dup"> <h3>' + data.title + ' </h3></div><div class="description">' + description + '</div>');
                
                var metaBottom = "<div class='meta-bottom'>"

                if (typeof caption !== 'undefined' && caption.length > 0) {
                    metaBottom += '<span class="caption">' + caption + '</span>'
                }

                metaBottom += '<span class="' + showMinutes + '">' + minutes +' min read</span></div>'

                $propHtml.append(metaBottom)
                
                $resultHtml.find('a').append($propHtml);              

                this.returnTargetedHtml($container, $resultHtml);
            }
            if (!hasSelectedFilters && isRelevanceSort) {
                embeddedCount++;
                checkEmbeddedContent();
            }
         // Handling Manual tiles position is at the end of page
			if (!hasSelectedFilters	&& (self.options.defaultNumberOfResults > nonManualTilesSize) && ((this.count + 1) == nonManualTilesSize)) {
				for (var k = nonManualTilesSize + 1; k <= self.options.defaultNumberOfResults; k++) {
					var $manualTileAtEnd = $(".searchtilesection").find('.searchtile [data-position="' + (k) + '"]');
					if ($manualTileAtEnd.length) {
						embeddedCount++;
						checkEmbeddedContent();
					}
				}
			}

        },
        generateBoxResult: function(data){
            var resultHtml = '';
            var val = "";
            var classes = "";
            var template = "";
            var isPDF = (typeof data.url !== 'undefined' && data.url.split('.')[data.url.split('.').length -1] === 'pdf');
            var target = isPDF?'_blank':'_self';

            template = JSON.parse(this.config.template);
            resultHtml += '<a class="cs_result-link vz-text-link" data-loc="Content:Grid" href="'+data.url+'" target="'+target+'">';
            resultHtml += '<div class="cs_box-result aem-Grid aem-Grid--12 aem-Grid--default--12 column-'+this.config.columns+'">';
            for (var t=0; t<template.length; t++){

                classes = template[t].class;
                field = template[t].field;
                if (data.hasOwnProperty(field)){
                    val = data[field];
                    if (field === 'image'){
                        resultHtml += '<img class="cs_result-field-'+field+' '+classes+' ' + (isPDF?'pdf-resource':'') + '" src="'+val+'" />';
                    } else if (field === 'url') {

                    } else {
                        resultHtml += '<div class="cs_result-field-'+field+' '+classes+'">'+val+'</div>';
                    }
                } 
            }
            resultHtml += '</div>';
            resultHtml += '</a>';
            this.returnHtml(resultHtml);
        },
        generateRowResult: function(data){
            var resultHtml = '';
            var isPDF = (typeof data.url !== 'undefined' && data.url.split('.')[data.url.split('.').length -1] === 'pdf');
            var target = isPDF?'_blank':'_self';
            resultHtml += '<div class="cs_row-result"><a class="cs_result-link vz-text-link" data-loc="Content:Grid" href="'+data.url+'" target="'+target+'">';
            for (prop in data){
                if (prop !== "url"){
                    if (prop === 'image'){
                   		var imageAltText = (typeof data['imagealttext'] !== 'undefined') ? data['imagealttext']: '';
                        resultHtml += '<div class="cs_result-field-'+prop+' ' + (isPDF?'pdf-resource':'') + '"><img src="'+data[prop]+'"    alt="'+imageAltText+'"></div>';
                    } else {
                        resultHtml += '<div class="cs_result-field-'+prop+'">'+data[prop]+'</div>';
                    } 
                }
            }
            resultHtml += '</a></div>';
            this.returnHtml(resultHtml);
        },
        generateTableResult: function(data){
            var resultHtml = '';
            var isPDF = (typeof data.url !== 'undefined' && data.url.split('.')[data.url.split('.').length -1] === 'pdf');
            resultHtml += '<tr class="cs_table-row-result">';
            for (prop in data){
                if (prop === 'image'){
                	var imageAltText = (typeof data['imagealttext'] !== 'undefined') ? data['imagealttext']: '';
                    resultHtml += '<td class="cs_result-field-'+prop+' ' + (isPDF?'pdf-resource':'') + '"><img src="'+data[prop]+'"   alt="'+imageAltText+'"></td>';
                } else {
                    resultHtml += '<td class="cs_result-field-'+prop+'">'+data[prop]+'</td>';
                }
            }
            resultHtml += '</tr>';
            this.returnHtml(resultHtml);
        },
        generatePatternResult: function(data,nonManualTilesSize){
            var self = this;
            var totalManualTiles = this.$target.find('.searchtile').length;
            var isRelevanceSort = $(".cs_search-sort-search-results .cs_sort-options li.selected").data('sortby') === 'relevance' ? true : false;
            var hasSelectedFilters = self.options.hasOwnProperty("selected_filters") && Object.keys(this.options.selected_filters).length !== 0;
            var embeddedCount = hasSelectedFilters ? this.count : this.count + totalManualTiles;

            if (!hasSelectedFilters && isRelevanceSort) {
                checkEmbeddedContent();
            }

            function checkEmbeddedContent() {
                var embedContent = false;
                var $searchTile;

                if (self.options.start === 0) {
                    var $possibleManualTile = $(".searchtilesection").find('.searchtile [data-position="'+(embeddedCount+1)+'"]');
                    if ($possibleManualTile.length) {
                        var embedContent = true;
                        var $searchTile = $possibleManualTile.parent();
                    }
                }



                if (embedContent) {
                    //Find if our category <div> already exists within the results container
                    var $containers = self.$target.find('.pattern-container');

                    if ($containers.length === 0 || (embeddedCount) % 6 === 0) {
                        var containerHtml = '<div class="pattern-container"></div>';
                        self.returnHtml(containerHtml);
                    }
                    
                    var $container = self.$target.find('.pattern-container').last();

                    if ((embeddedCount) % 6 === 0 || (embeddedCount - 1) % 6 === 0) {

                        var $resultHtml = $('<div class="cs_row-large-result embedded-content"><div class="searchtile"></div></div>');
                        $resultHtml.find('.searchtile').append($searchTile.html())
                        self.returnTargetedHtml($container, $resultHtml);
                    } else {

                        var $resultHtml = $('<div class="cs_row-small-result embedded-content"><div class="searchtile"></div></div>');
                        $resultHtml.find('.searchtile').append($searchTile.html())
                        self.returnTargetedHtml($container, $resultHtml);
                    }

                    embeddedCount++;
                    checkEmbeddedContent();
                }
            }

            //Find if our category <div> already exists within the results container
            var $containers = this.$target.find('.pattern-container');
            if ($containers.length === 0 || embeddedCount % 6 === 0) {
                var containerHtml = '<div class="pattern-container"></div>';
                this.returnHtml(containerHtml);
            }
            
            var $container = this.$target.find('.pattern-container').last();


            if (embeddedCount % 6 === 0 || (embeddedCount - 1) % 6 === 0) {
                var resultPath = (typeof data.referencepath !== "undefined") ? data.referencepath : data.url;
                var vanityPath = (typeof data.url !== "undefined") ? data.url : '';
                var videoPath = (typeof data.exturl !== "undefined") ? data.exturl : '';
                var videoPathPlus = videoPath + '?rel=0&autoplay=1&mute=1';
                var resourcetype = (typeof data.resourcetype !== 'undefined')? data.resourcetype : '';
                var content_type = (typeof data.content_type !== "undefined") ? data.content_type : '';

                if (typeof data.url !== 'undefined' && data.url.split('.')[data.url.split('.').length -1] === 'pdf') {
                data['image'] = "/business/content/dam" + data.url + '/jcr:content/renditions/cq5dam.thumbnail.480.960.png';
                target = "_blank";
                isPDF = true;
            }
                var target = '_self';
                var isPDF = false;

                // Add images for PDFs based on renditions
                if (typeof data.path !== 'undefined' && data.path.split('.')[data.path.split('.').length -1] === 'pdf') {
                    data['image'] = data.path + '/jcr:content/renditions/cq5dam.thumbnail.480.960.png';
                    data['image'] = "https://d23uobcja6cuc.cloudfront.net/business/bin/get/asset.png"+data.path.replace(/\/content\/dam/,"");
                    target = "_blank";
                    isPDF = true;
                }

                if (content_type === 'videoasset') {
                    data['image'] = data.path + '/jcr:content/renditions/cq5dam.thumbnail.480.360.png';
                    data['image'] = "https://d23uobcja6cuc.cloudfront.net/business/bin/get/asset.png"+data.path.replace(/\/content\/dam/,"");
                }

                // When there is no image, pull from generic image path
                if (typeof data['image'] == 'undefined' && typeof $('.cs_search-results').data('imagePaths') !== "undefined") {
                    var items = $('.cs_search-results').data('imagePaths');
                    data['image'] = items[Math.floor(Math.random()*items.length)];
                }

                
                if (content_type === 'videoasset') {
                    var $resultHtml = $('<div role="img" aria-label="'+ data.title +'" class="cs_row-large-result"><a class="cs_result-link vz-text-link" data-loc="Content:Grid" href="'+ videoPathPlus +'" target="'+target+'"></a></div>');
                } else {
                    var $resultHtml = $('<div role="img" aria-label="'+ data.title +'" class="cs_row-large-result"><a class="cs_result-link vz-text-link" data-loc="Content:Grid" href="'+ vanityPath +'" target="'+target+'"></a></div>');
                }         
                
                for (prop in data){
                    if (prop !== "url"){
                        if (prop === 'image'){
                        	var imageAltText = (typeof data['imagealttext'] !== 'undefined') ? data['imagealttext']: '';
                            $imageHtml = $('<div class="cs_result-field-'+prop+' ' + (isPDF?'pdf-resource':'') + '" style="background-image:url(\''+data[prop]+'\')"></div>');
                            $img = $('<img src="'+data[prop]+'" alt="'+imageAltText+'"/>');
                            $imageHtml.append($img);
                            $resultHtml.find('a').append($imageHtml);
                        } else if (prop == 'title'){
                            $propHtml = $('<div class="cs_result-field-'+prop+' h3_dup">'+data[prop]+'</div>');
                            $resultHtml.find('a').append($propHtml);
                        } else if (prop == 'gatetype'){
                            var gatePrefix = 'gating_';
                            var newGateClass = (typeof data['gatetype'] !== 'undefined') ? 'gating_' + String(data['gatetype']).toLowerCase() : ''; 
                           
                            $resultHtml.find('a').addClass(newGateClass);
                        }
                    }
                }
                this.returnTargetedHtml($container, $resultHtml);
            } else {
                // Generate actual result. This was copied directly from generateRowResult above
                var gatedClass = (typeof data['gatetype'] !== 'undefined') ? 'gating_' + String(data['gatetype']).toLowerCase() : '';
                var resultHtml = '';
                var resultPath = data.url;
                var vanityPath = (typeof data.url !== 'undefined') ? data.url : '';
                var videoPath = (typeof data.exturl !== 'undefined') ? data.exturl : '';
                var videoPathPlus = videoPath + '?rel=0&autoplay=1&mute=1';
                var content_type = (typeof data.content_type !== "undefined") ? data.content_type : '';
                var target = (typeof data.url !== 'undefined' && data.url.split('.')[data.url.split('.').length -1] === 'pdf')?'_blank':'_self';


                var content_type = (typeof data.content_type !== "undefined") ? data.content_type : '';
            
                        if (content_type === 'videoasset') {
                            resultHtml += '<div role="img" aria-label="'+ data.title +'" class="cs_row-small-result"><a class="cs_result-link vz-text-link '+gatedClass+'" data-loc="Content:Grid" href="'+videoPathPlus+'" target="'+target+'">';
                        } else {
                            resultHtml += '<div role="img" aria-label="'+ data.title +'" class="cs_row-small-result"><a class="cs_result-link vz-text-link '+gatedClass+'" data-loc="Content:Grid" href="'+vanityPath+'" target="'+target+'">';
                        }            
                
                
                for (prop in data){
                    if (prop !== "url"){
                        if (prop === 'title'){
                            resultHtml += '<div class="cs_result-field-'+prop+' h3_dup">'+data[prop]+'</div>';
                        }
                    }
                }
                
                resultHtml += '</a></div>';
                this.returnTargetedHtml($container, resultHtml);
            }

            if (!hasSelectedFilters && isRelevanceSort) {
                embeddedCount++;
                checkEmbeddedContent();
            }
			// Handling Manual tiles position is at the end of page
			if (!hasSelectedFilters	&& (self.options.defaultNumberOfResults > nonManualTilesSize) && ((this.count + 1) == nonManualTilesSize)) {
				for (var k = nonManualTilesSize + 1; k <= self.options.defaultNumberOfResults; k++) {
					var $manualTileAtEnd = $(".searchtilesection").find('.searchtile [data-position="' + (k) + '"]');
					if ($manualTileAtEnd.length) {
						embeddedCount++;
						checkEmbeddedContent();
					}
				}
			}

        },
        generateCategoryResult: function(data){
            var resultHtml = '', prodInitial = '', prodTitle = '', $letterTile;
            var resultPath = (typeof data.referencepath !== "undefined") ? data.referencepath : data.url;
            var vanityPath = (typeof data.url !== 'undefined') ? data.url : '';
            var target = (typeof data.url !== 'undefined' && data.url.split('.')[data.url.split('.').length -1] === 'pdf')?'_blank':'_self';
            resultHtml += '<div class="cs_row-result"><a class="cs_result-link vz-text-link" data-loc="Content:'+prodTitle+'" href="'+vanityPath+'" target="'+target+'">';

            for (prop in data){ //'fields' items

                if (prop === 'title'){
                    prodTitle = data[prop];

                    //individual product markup
                    resultHtml += '<div class="cs_result-field">'+prodTitle+'</div>';

                    //find first letter to use as box label
                    prodInitial = prodTitle.charAt(0).toUpperCase();                   

                    //if the letter tile exists, append the result. otherwise create new letter tile and append the result
                    $letterTile = this.$target.find('.letter-tile.letter-' + prodInitial);
                    if ($letterTile.length === 0) {
                        this.returnHtml('<div class="letter-tile letter-' + prodInitial+'"><h3>' + prodInitial +'</h3>' + resultHtml + '</div>');
                    } else {
                        this.returnTargetedHtml($letterTile, resultHtml);
                    }
                }

            }
        },
        generateFeaturedResult: function(data, highlightResultData){
            var title = (typeof data.title !== 'undefined') ? highlightResultData.title : '';
            var description = (typeof data.description !== 'undefined')? highlightResultData.description : '';
            if(description.length > 135) {
              description = description.slice(0, 135) + '...'
            }
            var resultPath = (typeof data.referencepath !== "undefined") ? data.referencepath : data.url;
            var resourcetype = (typeof data.resourcetype !== 'undefined')? data.resourcetype : '';
            var content_type = (typeof data.content_type !== "undefined") ? data.content_type : '';
            var vanityPath = (typeof data.url !== 'undefined')? data.url : '';
            var videoPath = (typeof data.exturl !== 'undefined') ? data.exturl : '';
            var videoPathPlus = videoPath + '?rel=0&autoplay=1&mute=1';
            var visiblePath = window.location.protocol+'//'+window.location.host+vanityPath;
            var target = '_self';
            var isPDF = false;

            if (typeof data.url !== 'undefined' && data.url.split('.')[data.url.split('.').length -1] === 'pdf') {
                data['image'] = "/business/content/dam" + data.url + '/jcr:content/renditions/cq5dam.thumbnail.480.960.png';
                target = "_blank";
                isPDF = true;
            }

            if (content_type === 'videoasset') {
                data['image'] = data.path + '/jcr:content/renditions/cq5dam.thumbnail.480.360.png';
            }

            if (typeof data['featured'] !== 'undefined' && data['featured'] === 'true') {
                if (typeof data['image'] == 'undefined' && typeof $('.cs_search-results').data('imagePaths') !== 'undefined') {
                    var items = $('.cs_search-results').data('imagePaths');
                    data['image'] = items[Math.floor(Math.random()*items.length)];
                }
                if ($('.cs_search-featured-results-area').children().length < 4) {

                    var featuredResultHtml = '';

                            if (content_type === 'videoasset') {
                                featuredResultHtml = '<div class="cs_row-featured-result"><a class="cs_result-link vz-image-link" data-loc="Content:Search results" href="'+videoPathPlus+'"  target="'+target+'">';
                            } else {
                                featuredResultHtml = '<div class="cs_row-featured-result"><a class="cs_result-link vz-image-link" data-loc="Content:Search results" href="'+vanityPath+'"  target="'+target+'">';
                            }

                    for (prop in data){
			            if (prop == 'gatetype'){
			                    var gatePrefix = 'gating_';
			                    var newGateClass = (typeof data['gatetype'] !== 'undefined') ? 'gating_' + String(data['gatetype']).toLowerCase() : '';                   
		            			featuredResultHtml = '<div class="cs_row-featured-result"><a class="cs_result-link vz-image-link '+ newGateClass + '" data-loc="Content:Search results" href="'+resultPath+'"  target="'+target+'">';
		            			break;
		 	             }                
			        }
			        var imageAltText = (typeof data['imagealttext'] !== 'undefined') ? data['imagealttext']: '';
                    featuredResultHtml  += '<div class="cs_result-field-image ' + (isPDF?'pdf-resource':'') + '"><img src="'+data['image']+'" alt="'+imageAltText+'"></div>';
                    featuredResultHtml  +=  '<div class="cs_result-field-title">'+title+'</div>';

                    if (description == null) {
                        featuredResultHtml += ''
                    } else {
                        featuredResultHtml += '<div class="cs_result-field-description">'+description+'</div>';
                    }

                    featuredResultHtml  +=  '<button class="quick-view-button vz-button-link" data-loc="Content:Search results"><span class="right-arrow"></span></button></a></div>';

                    this.returnTargetedHtml($(".cs_search-featured-results-area"), featuredResultHtml);
                }
            }

            var resultHtml = '';
            var content_type = (typeof data.content_type !== "undefined") ? data.content_type : '';

                if (content_type === 'videoasset') {
                        resultHtml = '<div class="cs_row-result"><a class="cs_result-link vz-image-link" data-loc="Content:Search results" href="'+ videoPathPlus +'"  target="'+target+'">';
                } else {
                        resultHtml = '<div class="cs_row-result"><a class="cs_result-link vz-image-link" data-loc="Content:Search results" href="'+ vanityPath +'"  target="'+target+'">';
                }


            for (prop in data){
	            if (prop == 'gatetype'){
	                    var gatePrefix = 'gating_';
	                     var newGateClass = (typeof data['gatetype'] !== 'undefined') ? 'gating_' + String(data['gatetype']).toLowerCase() : '';                    
            			resultHtml = '<div class="cs_row-result"><a class="cs_result-link vz-image-link ' + newGateClass + '" data-loc="Content:Search results" href="'+vanityPath+'"  target="'+target+'">';
            			break;
 	             }                
	        }

            resultHtml += '<div class="cs_result-field-title">'+title+'</div>';
            
            resultHtml += '<div class="cs_result-field-path">'+visiblePath+'</div>';
            

            if (description == null) {
                resultHtml += ''
            } else {
                resultHtml += '<div class="cs_result-field-description">'+description+'</div>';
            }
            
            if (resourcetype) {
            resultHtml += '</a><div class="cs_result-field-tags"><ul>';
            for (var i = 0; i < resourcetype.length; i++) {
                resultHtml += '<li>'+ resourcetype[i]+ '</li>';
            }
            resultHtml += '</ul></div>';
            }
            resultHtml += '</div>';
            this.returnHtml(resultHtml);

        },
        returnHtml: function(html){
            this.$target.append(html);
        },
        returnTargetedHtml: function($target, html){
            $target.append(html);
        },
    };

    CloudSearch.components.SearchResult = SearchResult;


})();

(function($) {
    if (typeof(CloudSearch) !== 'undefined'){
        $.extend(CloudSearch.components.SearchComponent.prototype, {
            initHandlers: function(){
                // Handle search submit button click
                this.$searchSubmit.click(function(e){
                    e.preventDefault();
                    this.newUserSearch();
                }.bind(this));


                // Handle filter add/remove
                $('[data-cmp-list-filter]').on('filter_change', function(e, filters){
                    this.getFilterValues(filters);
                    this.config.persistResults = false;
                    var options = this.config;
                    options.getFacets = false;
                    if (options.hasOwnProperty("selected_filters") && typeof(options.selected_filters) !== "string" && Object.keys(options.selected_filters).length === 0)
                    {
                    	options.getFacets = true;
                    }
					if (options.hasOwnProperty("selected_filters") && typeof(options.selected_filters) !== "string" && Object.keys(options.selected_filters).length === 1){
                        for (prop in options.selected_filters)
                            {
                                if(prop === "featured")
                                {
                                     options.getFacets = true;
                                }
                            }
                    }
                    options.page = 1;
                    options.start = 0;

                    var url = "";
                    var pathname = window.location.pathname;
                    var hash = window.location.hash;
                    var params = ves.utils.urlParameters();

                    params["page"] = options.page;
                    // params["filters"] = filters;

                    var query = ves.utils.toQueryString(params).length ? '?'+ves.utils.toQueryString(params) : '';

                    url = pathname+query+hash;
                    if (history.pushState) {
                        history.pushState({},"",url);
                    }

                    new CloudSearch.components.SearchQuery(options, function(url){
                        this.loadResults(url);
                    }.bind(this));
                }.bind(this));
                
                $('.cs_sort-options .sort-item').click(function(){
                    this.getSortOption();
                }.bind(this));

                $('.cs_search-no-results li a').each(function(index, item) {
                    var linkText = $(item).text();
                    var encodeItem = encodeURIComponent(linkText);
                    var linkURL = search.actionURL + encodeItem;
                    $(item).attr('href', linkURL);
                });
            },
            getSortOption: function(){
                console.log('get sort option');
                var sort = $('.cs_search-sort-search-results').find('.selected').attr('data-sortby');
                // var sortStr = "";
                // if (sort === 'relevance'){
                //     sortStr = "&sort=featured%20desc,created_date%20desc";
                // } else if(sort === 'alphabetical'){
                //     sortStr = '&sort=title%20asc';
                // } else {
                //     sortStr = '&sort=created_date%20desc';
                // }

                this.config.sortby = sort;
                this.config.persistResults = false;

                this.config.page = 1;
                this.config.start = 0;

                var url = "";
                var pathname = window.location.pathname;
                var hash = window.location.hash;
                var params = ves.utils.urlParameters();

                params["page"] = this.config.page;
                params["sortby"] = sort;

                var query = ves.utils.toQueryString(params).length ? '?'+ves.utils.toQueryString(params) : '';

                url = pathname+query+hash;
                if (history.pushState) {
                    history.pushState({},"",url);
                }

                var options = this.config;
                options.getFacets = true;
            	if (options.hasOwnProperty("selected_filters") && typeof(options.selected_filters) !== "string" && Object.keys(options.selected_filters).length !== 0 ){
            		options.getFacets = false;
            		if(Object.keys(options.selected_filters).length === 1)
            		{
            			for (prop in options.selected_filters)
                        {
                            if(prop === "featured")
                            {
                                 options.getFacets = true;
                            }
                        }
            		}
                }
                

                new CloudSearch.components.SearchQuery(options, function(url){
                    this.loadResults(url);
                }.bind(this));
            },
            getFilterValues: function(data){
                var selected_filters = {};
                var filter = "";
                for (var f=0; f<data.length; f++){
                    var thisFilter = data[f];
                    thisFilter = thisFilter.split("|");
                    filter = thisFilter[0];
                    if (!selected_filters.hasOwnProperty(filter)){
                        selected_filters[filter] = [];
                    }
                    selected_filters[filter].push(thisFilter[1]);
                }

                this.config.selected_filters = selected_filters;

                if (this.config.selected_filters.hasOwnProperty(filter) === true) {
                    $('.clear-all').removeClass('disableReset');
                } else {
                    $('.clear-all').addClass('disableReset');
                }
            },
            getInitialData: function(noFacets){
                var options = this.config;
                this.config.persistResults = false;
                options.getFacets = noFacets ? false : true;

                options.qparser = 'structured';

                if (this.isInitialSearch && options.hasOwnProperty("selected_filters")) {
                    var unfilteredOptions = JSON.parse(JSON.stringify(this.config));
                    delete unfilteredOptions.selected_filters;

                    new CloudSearch.components.SearchQuery(unfilteredOptions, function(unfilteredUrl) {
                        this.loadResults(unfilteredUrl, function(){
                            this.getInitialData(true);
                        }.bind(this));
                    }.bind(this));
                } else {
                    new CloudSearch.components.SearchQuery(options, function(url){
                        if (this.config.loadDefaultResults){
                            this.loadResults(url);
                        }
                    }.bind(this));
                }
            },
            showNoResults: function(){
                var searchTerm = $('.searchbar .cs_search-string').attr('placeholder');
                var resultsString = $('.cs_search-no-results__wrapper').data('results-string');
                var noSearchParameter = search.getParameter('cs_query').replace(/<.+?>/g,"");

                if(resultsString && searchTerm) {
                    $('.cs_results-count').html(resultsString + ' &ldquo;'+ noSearchParameter +'&rdquo; ');
                    $('.searchfilter').css('display', 'none');
                   //$('.resourcesfilter .cs_search-filter').css('display', 'none');                   
         
                } else {
                    $('.cs_currently-showing').text('0');
                    $('.cs_total-results').text('0');
                }

                if($('.cs_total-results').length < 1) {
                    $('.cs_results-count').hide();
                }
               
                if($('.cs_search-no-results').length > 0){
                    $('.cs_search-no-results').show();
                    $('.cs_search-results-area').hide();
                    $('.cs_search-featured-results-area').hide();

                    if(searchTerm){
                        $('.cs_search-no-results__search-term').text(noSearchParameter);
                    }
                } else {
                    this.$resultsArea.html(this.config.noResultsLabel);
                }
				
					var totalResultsCount = $('.cs_total-results').text();
                     if(totalResultsCount == 0 || totalResultsCount == ''){
                         $('.cs_search-no-results').css("display","block");
						 $('.sort .cs_search-sort-search-results').css("display","none");
						 $('.searchresults .pagenation').css("display","none");
                	} 
                
            },

            setPageNumber: function(){

                var hasPageNumber = window.location.search.indexOf("page=") > 0;
                if (!hasPageNumber){
                    var url = "";
                    var pathname = window.location.pathname;
                    var hash = window.location.hash;
                    var params = ves.utils.urlParameters();

                    if (this.config.page.length > 0){
                        params["page"] = this.config.page;

                        var query = ves.utils.toQueryString(params).length ? '?'+ves.utils.toQueryString(params) : '';
                        url = pathname+query+hash;

                    } else {
                        var params = ves.utils.urlParameters();
                        this.config.page = 1;

                        params["page"] = this.config.page;

                        var query = ves.utils.toQueryString(params).length ? '?'+ves.utils.toQueryString(params) : '';

                        url = pathname+query+hash;
                    }
                    if (history.replaceState){
                        history.replaceState({},"",url);
                    }
                }
            },
            loadResults: function(url, cb){
                var options = {};

                options.requestURL = url;

                new CloudSearch.components.SearchRequest(options, function(data){
                    if (data.hits.found !== 0) {
                        if (this.isInitialSearch){
                            // Load up filters if this is the initial page load
                            this.generateFilters(data);

                            // Turn flag off for loading filters so they aren't re-loaded every time we load new results
                            this.isInitialSearch = false;

                            // Exit method early if actual results are not supposed to be shown until enters a search term or interacts with filter
                            if (!this.config.loadDefaultResults){
                                return;
                            }
                        }
                        // Set result count label
                        this.setResultCountLabel(data);

                        // Load up set of results onto page
                        this.generateResultHtml(data);

                        // Create pagination based on result set
                        this.generatePagination(data);
						
						 $('.cs_search-results-area').show();
						$('.cs_search-featured-results-area').show();
						
						$('.searchresults .pagenation').css("display","block");
						$('.cs_search-no-results').css("display","none");
						$('.sort .cs_search-sort-search-results').css("display","block");
						var totalResultsCount = $('.cs_total-results').text();
                        if(totalResultsCount !== 0 || totalResultsCount !== '')
                		{
                            $('.cs_search-no-results').css("display","none");
                        }
                    } else {
                        this.showNoResults();
                    }

                    if (typeof cb !== 'undefined') {
                        cb();
                    }

                }.bind(this));
            },
            generateResultHtml: function(data){

                var resultObj = {};
                var result = "";
                var results = "";
                resultObj.columns = this.config.customTemplateColumnCount;
                resultObj.template = this.config.resultTemplate;
                resultObj.resultType = this.config.resultsDisplayFormat;
                results = data.hits.hit;
                if (!this.config.persistResults){
                    this.$resultsArea.empty();
                }

                for (var i=0; i<results.length; i++){
                    resultObj.resultData = results[i].fields;
                    resultObj.highlightResultData = results[i].highlights;
                    new CloudSearch.components.SearchResult(resultObj, this.$resultsArea, i, this.config,results.length);
                }
               // this.generateLightbox();
            },

            generateLightbox: function(){
                $("a[href*='youtu.be/'],a[href*='youtube.com/watch']").filter(":not([data-fancybox-href])").each(function(i,v){
                    var id=v.href.match(/youtu\.be\/(\w+)[\/\?]?/) || v.href.match(/youtube.com\/watch\?v=(\w+)[\&]?/);
                     if (id && v.href.indexOf("#")<0) {
                         $(v).attr("data-fancybox-href","//www.youtube.com/embed/"+id[1]+"?autoplay=1");
                         $(v).attr("allow","autoplay; encrypted-media");
                     }
                 });
                $("a[data-fancybox-href]").fancybox();
            },

            generatePagination: function(data){
                var options = {};
                options.searchObj = this;
                options.data = data;
                options.activePageNumber = this.config.page;
                options.resultsPerPage = this.config.defaultNumberOfResults;
                options.target = this.$pagination;
                new CloudSearch.components.Pagination(options);
            }
        })
    }
})($);
/**
 * File: searchbar.js
 * Copyright: MRM//McCann 2018
 * Author: Jeff Simko
 */

(function($) {
    'use strict';
    var Searchbar = function(element) {
        this.$ctx = $(element);
        this.init();
    };

    Searchbar.prototype = {

        init: function() {
            var searchParameter = search.getParameter('cs_query');
            

            this.bindevents();
            
            if (searchParameter) {
                var decodedParameter = decodeURIComponent(searchParameter.replace(/\+/g, ' '));
                this.$ctx.find('.cs_search-string').val(decodedParameter);
                this.$ctx.find('.cs_search-string').trigger('keyup');
            }            
        },

        bindevents: function() {
            var self = this;

            this.$ctx.find('.cs_search-string').on('keyup.predictive', $.debounce(250, self.activateClearButton));

            this.$ctx.find('.cs_search-submit').click(function(e) {
                self.submitSearch(e);
            });

            this.$ctx.find('.cs_predictive-search-button').click(function(e) {
                self.submitSearch(e);
            });

            this.$ctx.find('.cs_search-close').click(function(e) {
                e.preventDefault();
                self.clearForm();
            });

        },

        activateClearButton:function(){
            var self = this;
            var stringValue = $(this).val();
            var hasValue = stringValue.length > 0; 

            $(this).siblings('.cs_search-close').toggleClass('active', hasValue);
        },

        submitSearch: function(e) {
            var self = this;
            var stringValue = this.$ctx.find('.cs_search-string').val();

            if (stringValue) {
                self.$ctx.find('.cs_search-form').submit();
            }
        },

        clearForm: function() {
            var searchStr = window.location.search;
            var indexOfAnd = searchStr.indexOf('&');
            var searchLength = searchStr.length;
            if (searchStr && indexOfAnd && searchLength){
                window.location.search = '?' + searchStr.substring(indexOfAnd + 1, searchLength);
            }           
        }
    };

    window.addEventListener("load", function() {
        $('.searchbar').each(function() {
            new Searchbar(this);
        });
    })

})(jQuery);
  (function($) {
    if (typeof(CloudSearch) !== 'undefined'){
        $.extend(CloudSearch.components.SearchQuery.prototype, {
            createUrl: function(options, cb){
                var stStart = options.start;
                var stdefaultNumberOfResults = options.defaultNumberOfResults;
                var searchTiles = $(".searchtilesection").find(".searchtile").length;
                var isRelevanceSort = $(".cs_search-sort-search-results .cs_sort-options li.selected").data('sortby') === 'relevance' ? true : false;
                var hasSelectedFilters = options.hasOwnProperty("selected_filters") && Object.keys(options.selected_filters).length !== 0;
				
						
                if (!hasSelectedFilters) {
                    if (stStart === 0 && searchTiles > 0) {
                        stdefaultNumberOfResults = stdefaultNumberOfResults - searchTiles;
                    } else {
                        stStart = stStart - searchTiles;
                    }
                }

                var url = "";

                // build url using provided options
                url += options.hasOwnProperty("searchEndpoint") ? options.searchEndpoint + '?' : '';
                url += options.hasOwnProperty("defaultNumberOfResults") ? 'size=' + stdefaultNumberOfResults : 'size=20';
                url += options.hasOwnProperty("start") ? '&start=' + stStart : '&start=0';
                url += options.hasOwnProperty("qparser") ? '&q.parser=' + options.qparser : '&q.parser=structured';
                url += options.hasOwnProperty("q") && options.q.length > 0 ? '&q=%27' + options.q + '%27' : '&q=matchall';
                url += options.hasOwnProperty("resultFields") && options.resultFields.length > 0 ? '&return=' + options.resultFields : '&return=_all_fields';
                var includeTags = JSON.parse($('.cs_search-filter').attr('data-includeTags'));

                
                if (options.hasOwnProperty("getFacets") && options.getFacets && options.hasOwnProperty("facets") && options.facets.length > 0){
                    url += '&facet=%7B';
                    for (var f=0; f<options.facets.length; f++){
                        facetKey = options.facets[f].split("|");
                        if(includeTags[f].length>0)
                        {
                        	
                        	url += '%22' + facetKey[1] +'%22%3A%7Bbuckets%3A%5B'; 
                        	
                        	for(var j = 0; j < includeTags[f].length; j++) 
                        	{
                        		url +=  '%22'+ encodeURIComponent(includeTags[f][j]) + '%22';
                        		
                        		url += (j+1 !== (includeTags[f].length)) ? '%2C' : '';
                        	}
                        	
                        	url += '%5D%7D';
                        }
                        else
                        {
                       		 url += '%22' + facetKey[1] + '%22%3A%7B%22sort%22%3A%22bucket%22%2C%20%22size%22%3A50%7D';
                       		
                         }
                         
                          url += (f + 1 !== options.facets.length) ? '%2C' : '';
                        
                    }
                    url += '%7D';
                }
                 url += '&fq=%28and%20(not%20noindex%3A%20%27true%27)';
                var locale = $('.cs_search-filter').attr('data-locale');
  				
                if (locale && locale.length > 0){
                    	url += '%20%28or%20locale:\'' + locale + '\'%20include_locale:\'' + locale + '\'%29';
               	}	
                if ((options.hasOwnProperty("site_name") && options.site_name.length > 0) || (options.hasOwnProperty("contentType") && options.contentType.length > 0) || ( options.hasOwnProperty("selected_filters") && typeof(options.selected_filters) !== "string" && Object.keys(options.selected_filters).length !== 0 )){
                   
                    if (options.hasOwnProperty("site_name") && options.site_name.length > 0){
                        url += '%20%28or';
                        for (var n=0; n<options.site_name.length; n++){
                            url += '%20site:\'' + options.site_name[n] + '\'';
                        }
                        url += '%29';
                    }
                    
                    if (options.hasOwnProperty("contentType") && options.contentType.length > 0){
                        url += '%20%28or';
                        for (var t=0; t<options.contentType.length; t++){
                        var filterType = $('.cs_search-filter').data('filter-type');
                        if (options.contentType[t] === "asset" && filterType === "resources")
                         	{
								var d = new Date(new Date().setFullYear(new Date().getFullYear() - 3));
								d = d.getFullYear()+'-'+d.getMonth()+'-'+d.getDate();
                         		url += '%20(and%20content_type:\'' + options.contentType[t] + '\''+ '%20created_date:%5B%27' + d + '%27%2C%7D)';
                         	}
                         else
                         	{
                           		 url += '%20content_type:\'' + options.contentType[t] + '\'';
                            }
                        }
                        
                        url += '%29';
                    }
                    if (options.hasOwnProperty("selected_filters") && typeof(options.selected_filters) !== "string" && Object.keys(options.selected_filters).length !== 0){
                        var selectedFilter = "";
                        var featuredFlag = false;
                        var featuredUrl = "";

                        var nonFeaturedFlag = false;
                        var nonFeaturedUrl = "";

                        for (prop in options.selected_filters){
                            selectedFilter = options.selected_filters[prop];

                            if(prop ==='resources' && selectedFilter[0] === 'featured'){
                                featuredFlag = true;
                                featuredUrl = '%20(and%20featured%3A%20%27true%27)%20';
                            }
                            else{
                                for (var s=0; s<selectedFilter.length; s++){
                                 nonFeaturedUrl += '%20'+prop+':\'' + encodeURIComponent(selectedFilter[s]) + '\'';
                                }
                                nonFeaturedFlag = true;
                            }
                        }

                        if(featuredFlag === true){
                            url += featuredUrl;
                        }

                        if(nonFeaturedFlag === true){
                            url += '%20%28or'+nonFeaturedUrl +'%29';
                        }

                    }
                    else 
                    {
                    	 if (options.hasOwnProperty("getFacets") && options.getFacets && options.hasOwnProperty("facets") && options.facets.length > 0){
		                
		                    for (var f=0; f<options.facets.length; f++){
		                        facetKey = options.facets[f].split("|");
		                         
		                        if(includeTags[f].length>0)
		                        {
		                        	url += "%20%28or%20%28not%28prefix%20field%3D"+facetKey[1]+"%20%27%27%29%29";
		                        	for(var j = 0; j < includeTags[f].length; j++) 
		                        	{
		                        		url += '%20'+facetKey[1]+':\'' + encodeURIComponent(includeTags[f][j]) + '\'';
		                        	}
		                        	
		                        	 url += '%29';
		                        }
		                        
		                         
		                        
		                    }
                		}
                    }
                    url += '%29';
                }
                else
                {
                	url += '%29';
                }

                var sort = "";

                if (ves.utils.getParameterByName('sortby').length) {
                    sort = ves.utils.getParameterByName('sortby');
                } else {
                    sort = $('.cs_search-sort-search-results').data('sortby');
                }

                var sortStr = "";
                if (sort === 'relevance'){
                    sortStr = '&highlight.title=%7B%22max_phrases%22%3A5%7D&highlight.description=%7B%22max_phrases%22%3A5%7D&sort=featured%20desc,created_date%20desc';
                }
                else if(sort === 'alphabetical'){
                    sortStr = '&highlight.title=%7B%22max_phrases%22%3A5%7D&highlight.description=%7B%22max_phrases%22%3A5%7D&sort=title%20asc';
                }
                else if(sort === 'featured_created'){
                    sortStr = '&highlight.title=%7B%22max_phrases%22%3A5%7D&highlight.description=%7B%22max_phrases%22%3A5%7D&sort=featured%20desc,created_date%20desc';
                }
                 else if(sort === 'featured-title-description'){
                    sortStr = '&highlight.title=%7B%22max_phrases%22%3A5%7D&highlight.description=%7B%22max_phrases%22%3A5%7D&sort=featured%20desc,title%20desc,description%20desc';
                }
                 else if (sort === 'mostPopular'){
                    sortStr = '&highlight.title=%7B%22max_phrases%22%3A5%7D&highlight.description=%7B%22max_phrases%22%3A5%7D&sort=popularity%20desc,created_date%20desc';
                }
                 else if (sort === 'oldestToNewest'){
                    sortStr = '&highlight.title=%7B%22max_phrases%22%3A5%7D&highlight.description=%7B%22max_phrases%22%3A5%7D&sort=created_date%20asc';
                }
                 else if (sort === 'mostPopularFeatured'){
                     sortStr = '&highlight.title=%7B%22max_phrases%22%3A5%7D&highlight.description=%7B%22max_phrases%22%3A5%7D&sort=featured%20desc,popularity%20desc,created_date%20desc';
                 }
                  else if (sort === 'oldestToNewestFeatured'){
                     sortStr = '&highlight.title=%7B%22max_phrases%22%3A5%7D&highlight.description=%7B%22max_phrases%22%3A5%7D&sort=featured%20desc,created_date%20asc';
                 }
                  else if (sort === 'recentFeatured'){
                      sortStr = '&highlight.title=%7B%22max_phrases%22%3A5%7D&highlight.description=%7B%22max_phrases%22%3A5%7D&sort=featured%20desc,created_date%20desc';
                  }
                
                 else {
                    sortStr = '&highlight.title=%7B%22max_phrases%22%3A5%7D&highlight.description=%7B%22max_phrases%22%3A5%7D&sort=created_date%20desc';
                }

                url += sortStr;//options.hasOwnProperty('sortby') ? options.sortby : sortStr;

                // return completed url
                return cb(url);
            }
        })
    }
})($);
(function($) {
    if (typeof(CloudSearch) !== 'undefined'){
        $.extend(CloudSearch.components.SearchSort.prototype, {
            initHandlers: function(){
                $('.sort-item').click(function(){
                    $('.sort-item').removeClass('selected');
                    $(this).addClass('selected');
					var sortext = $(this).text();
                    $('.cs_search-sort-search-results .filter-dropdown a.filter-dropdown-button').text(sortext);
                });
            }
        })
    }
})($);
!function(i){"use strict";"function"==typeof define&&define.amd?define(["jquery"],i):"undefined"!=typeof exports?module.exports=i(require("jquery")):i(jQuery)}(function(i){"use strict";var e=window.Slick||{};(e=function(){var e=0;return function(t,o){var s,n=this;n.defaults={accessibility:!0,adaptiveHeight:!1,appendArrows:i(t),appendDots:i(t),arrows:!0,asNavFor:null,prevArrow:'<button class="slick-prev" aria-label="Previous" type="button">Previous</button>',nextArrow:'<button class="slick-next" aria-label="Next" type="button">Next</button>',autoplay:!1,autoplaySpeed:3e3,centerMode:!1,centerPadding:"50px",cssEase:"ease",customPaging:function(e,t){return i('<button type="button" />').text(t+1)},dots:!1,dotsClass:"slick-dots",draggable:!0,easing:"linear",edgeFriction:.35,fade:!1,focusOnSelect:!1,focusOnChange:!1,infinite:!0,initialSlide:0,lazyLoad:"ondemand",mobileFirst:!1,pauseOnHover:!0,pauseOnFocus:!0,pauseOnDotsHover:!1,respondTo:"window",responsive:null,rows:1,rtl:!1,slide:"",slidesPerRow:1,slidesToShow:1,slidesToScroll:1,speed:500,swipe:!0,swipeToSlide:!1,touchMove:!0,touchThreshold:5,useCSS:!0,useTransform:!0,variableWidth:!1,vertical:!1,verticalSwiping:!1,waitForAnimate:!0,zIndex:1e3},n.initials={animating:!1,dragging:!1,autoPlayTimer:null,currentDirection:0,currentLeft:null,currentSlide:0,direction:1,$dots:null,listWidth:null,listHeight:null,loadIndex:0,$nextArrow:null,$prevArrow:null,scrolling:!1,slideCount:null,slideWidth:null,$slideTrack:null,$slides:null,sliding:!1,slideOffset:0,swipeLeft:null,swiping:!1,$list:null,touchObject:{},transformsEnabled:!1,unslicked:!1},i.extend(n,n.initials),n.activeBreakpoint=null,n.animType=null,n.animProp=null,n.breakpoints=[],n.breakpointSettings=[],n.cssTransitions=!1,n.focussed=!1,n.interrupted=!1,n.hidden="hidden",n.paused=!0,n.positionProp=null,n.respondTo=null,n.rowCount=1,n.shouldClick=!0,n.$slider=i(t),n.$slidesCache=null,n.transformType=null,n.transitionType=null,n.visibilityChange="visibilitychange",n.windowWidth=0,n.windowTimer=null,s=i(t).data("slick")||{},n.options=i.extend({},n.defaults,o,s),n.currentSlide=n.options.initialSlide,n.originalSettings=n.options,void 0!==document.mozHidden?(n.hidden="mozHidden",n.visibilityChange="mozvisibilitychange"):void 0!==document.webkitHidden&&(n.hidden="webkitHidden",n.visibilityChange="webkitvisibilitychange"),n.autoPlay=i.proxy(n.autoPlay,n),n.autoPlayClear=i.proxy(n.autoPlayClear,n),n.autoPlayIterator=i.proxy(n.autoPlayIterator,n),n.changeSlide=i.proxy(n.changeSlide,n),n.clickHandler=i.proxy(n.clickHandler,n),n.selectHandler=i.proxy(n.selectHandler,n),n.setPosition=i.proxy(n.setPosition,n),n.swipeHandler=i.proxy(n.swipeHandler,n),n.dragHandler=i.proxy(n.dragHandler,n),n.keyHandler=i.proxy(n.keyHandler,n),n.instanceUid=e++,n.htmlExpr=/^(?:\s*(<[\w\W]+>)[^>]*)$/,n.registerBreakpoints(),n.init(!0)}}()).prototype.activateADA=function(){this.$slideTrack.find(".slick-active").attr({"aria-hidden":"false"}).find("a, input, button, select").attr({tabindex:"0"})},e.prototype.addSlide=e.prototype.slickAdd=function(e,t,o){var s=this;if("boolean"==typeof t)o=t,t=null;else if(t<0||t>=s.slideCount)return!1;s.unload(),"number"==typeof t?0===t&&0===s.$slides.length?i(e).appendTo(s.$slideTrack):o?i(e).insertBefore(s.$slides.eq(t)):i(e).insertAfter(s.$slides.eq(t)):!0===o?i(e).prependTo(s.$slideTrack):i(e).appendTo(s.$slideTrack),s.$slides=s.$slideTrack.children(this.options.slide),s.$slideTrack.children(this.options.slide).detach(),s.$slideTrack.append(s.$slides),s.$slides.each(function(e,t){i(t).attr("data-slick-index",e)}),s.$slidesCache=s.$slides,s.reinit()},e.prototype.animateHeight=function(){var i=this;if(1===i.options.slidesToShow&&!0===i.options.adaptiveHeight&&!1===i.options.vertical){var e=i.$slides.eq(i.currentSlide).outerHeight(!0);i.$list.animate({height:e},i.options.speed)}},e.prototype.animateSlide=function(e,t){var o={},s=this;s.animateHeight(),!0===s.options.rtl&&!1===s.options.vertical&&(e=-e),!1===s.transformsEnabled?!1===s.options.vertical?s.$slideTrack.animate({left:e},s.options.speed,s.options.easing,t):s.$slideTrack.animate({top:e},s.options.speed,s.options.easing,t):!1===s.cssTransitions?(!0===s.options.rtl&&(s.currentLeft=-s.currentLeft),i({animStart:s.currentLeft}).animate({animStart:e},{duration:s.options.speed,easing:s.options.easing,step:function(i){i=Math.ceil(i),!1===s.options.vertical?(o[s.animType]="translate("+i+"px, 0px)",s.$slideTrack.css(o)):(o[s.animType]="translate(0px,"+i+"px)",s.$slideTrack.css(o))},complete:function(){t&&t.call()}})):(s.applyTransition(),e=Math.ceil(e),!1===s.options.vertical?o[s.animType]="translate3d("+e+"px, 0px, 0px)":o[s.animType]="translate3d(0px,"+e+"px, 0px)",s.$slideTrack.css(o),t&&setTimeout(function(){s.disableTransition(),t.call()},s.options.speed))},e.prototype.getNavTarget=function(){var e=this,t=e.options.asNavFor;return t&&null!==t&&(t=i(t).not(e.$slider)),t},e.prototype.asNavFor=function(e){var t=this.getNavTarget();null!==t&&"object"==typeof t&&t.each(function(){var t=i(this).slick("getSlick");t.unslicked||t.slideHandler(e,!0)})},e.prototype.applyTransition=function(i){var e=this,t={};!1===e.options.fade?t[e.transitionType]=e.transformType+" "+e.options.speed+"ms "+e.options.cssEase:t[e.transitionType]="opacity "+e.options.speed+"ms "+e.options.cssEase,!1===e.options.fade?e.$slideTrack.css(t):e.$slides.eq(i).css(t)},e.prototype.autoPlay=function(){var i=this;i.autoPlayClear(),i.slideCount>i.options.slidesToShow&&(i.autoPlayTimer=setInterval(i.autoPlayIterator,i.options.autoplaySpeed))},e.prototype.autoPlayClear=function(){var i=this;i.autoPlayTimer&&clearInterval(i.autoPlayTimer)},e.prototype.autoPlayIterator=function(){var i=this,e=i.currentSlide+i.options.slidesToScroll;i.paused||i.interrupted||i.focussed||(!1===i.options.infinite&&(1===i.direction&&i.currentSlide+1===i.slideCount-1?i.direction=0:0===i.direction&&(e=i.currentSlide-i.options.slidesToScroll,i.currentSlide-1==0&&(i.direction=1))),i.slideHandler(e))},e.prototype.buildArrows=function(){var e=this;!0===e.options.arrows&&(e.$prevArrow=i(e.options.prevArrow).addClass("slick-arrow"),e.$nextArrow=i(e.options.nextArrow).addClass("slick-arrow"),e.slideCount>e.options.slidesToShow?(e.$prevArrow.removeClass("slick-hidden").removeAttr("aria-hidden tabindex"),e.$nextArrow.removeClass("slick-hidden").removeAttr("aria-hidden tabindex"),e.htmlExpr.test(e.options.prevArrow)&&e.$prevArrow.prependTo(e.options.appendArrows),e.htmlExpr.test(e.options.nextArrow)&&e.$nextArrow.appendTo(e.options.appendArrows),!0!==e.options.infinite&&e.$prevArrow.addClass("slick-disabled").attr("aria-disabled","true")):e.$prevArrow.add(e.$nextArrow).addClass("slick-hidden").attr({"aria-disabled":"true",tabindex:"-1"}))},e.prototype.buildDots=function(){var e,t,o=this;if(!0===o.options.dots){for(o.$slider.addClass("slick-dotted"),t=i("<ul />").addClass(o.options.dotsClass),e=0;e<=o.getDotCount();e+=1)t.append(i("<li />").append(o.options.customPaging.call(this,o,e)));o.$dots=t.appendTo(o.options.appendDots),o.$dots.find("li").first().addClass("slick-active")}},e.prototype.buildOut=function(){var e=this;e.$slides=e.$slider.children(e.options.slide+":not(.slick-cloned)").addClass("slick-slide"),e.slideCount=e.$slides.length,e.$slides.each(function(e,t){i(t).attr("data-slick-index",e).data("originalStyling",i(t).attr("style")||"")}),e.$slider.addClass("slick-slider"),e.$slideTrack=0===e.slideCount?i('<div class="slick-track"/>').appendTo(e.$slider):e.$slides.wrapAll('<div class="slick-track"/>').parent(),e.$list=e.$slideTrack.wrap('<div class="slick-list"/>').parent(),e.$slideTrack.css("opacity",0),!0!==e.options.centerMode&&!0!==e.options.swipeToSlide||(e.options.slidesToScroll=1),i("img[data-lazy]",e.$slider).not("[src]").addClass("slick-loading"),e.setupInfinite(),e.buildArrows(),e.buildDots(),e.updateDots(),e.setSlideClasses("number"==typeof e.currentSlide?e.currentSlide:0),!0===e.options.draggable&&e.$list.addClass("draggable")},e.prototype.buildRows=function(){var i,e,t,o,s,n,r,l=this;if(o=document.createDocumentFragment(),n=l.$slider.children(),l.options.rows>1){for(r=l.options.slidesPerRow*l.options.rows,s=Math.ceil(n.length/r),i=0;i<s;i++){var d=document.createElement("div");for(e=0;e<l.options.rows;e++){var a=document.createElement("div");for(t=0;t<l.options.slidesPerRow;t++){var c=i*r+(e*l.options.slidesPerRow+t);n.get(c)&&a.appendChild(n.get(c))}d.appendChild(a)}o.appendChild(d)}l.$slider.empty().append(o),l.$slider.children().children().children().css({width:100/l.options.slidesPerRow+"%",display:"inline-block"})}},e.prototype.checkResponsive=function(e,t){var o,s,n,r=this,l=!1,d=r.$slider.width(),a=window.innerWidth||i(window).width();if("window"===r.respondTo?n=a:"slider"===r.respondTo?n=d:"min"===r.respondTo&&(n=Math.min(a,d)),r.options.responsive&&r.options.responsive.length&&null!==r.options.responsive){s=null;for(o in r.breakpoints)r.breakpoints.hasOwnProperty(o)&&(!1===r.originalSettings.mobileFirst?n<r.breakpoints[o]&&(s=r.breakpoints[o]):n>r.breakpoints[o]&&(s=r.breakpoints[o]));null!==s?null!==r.activeBreakpoint?(s!==r.activeBreakpoint||t)&&(r.activeBreakpoint=s,"unslick"===r.breakpointSettings[s]?r.unslick(s):(r.options=i.extend({},r.originalSettings,r.breakpointSettings[s]),!0===e&&(r.currentSlide=r.options.initialSlide),r.refresh(e)),l=s):(r.activeBreakpoint=s,"unslick"===r.breakpointSettings[s]?r.unslick(s):(r.options=i.extend({},r.originalSettings,r.breakpointSettings[s]),!0===e&&(r.currentSlide=r.options.initialSlide),r.refresh(e)),l=s):null!==r.activeBreakpoint&&(r.activeBreakpoint=null,r.options=r.originalSettings,!0===e&&(r.currentSlide=r.options.initialSlide),r.refresh(e),l=s),e||!1===l||r.$slider.trigger("breakpoint",[r,l])}},e.prototype.changeSlide=function(e,t){var o,s,n,r=this,l=i(e.currentTarget);switch(l.is("a")&&e.preventDefault(),l.is("li")||(l=l.closest("li")),n=r.slideCount%r.options.slidesToScroll!=0,o=n?0:(r.slideCount-r.currentSlide)%r.options.slidesToScroll,e.data.message){case"previous":s=0===o?r.options.slidesToScroll:r.options.slidesToShow-o,r.slideCount>r.options.slidesToShow&&r.slideHandler(r.currentSlide-s,!1,t);break;case"next":s=0===o?r.options.slidesToScroll:o,r.slideCount>r.options.slidesToShow&&r.slideHandler(r.currentSlide+s,!1,t);break;case"index":var d=0===e.data.index?0:e.data.index||l.index()*r.options.slidesToScroll;r.slideHandler(r.checkNavigable(d),!1,t),l.children().trigger("focus");break;default:return}},e.prototype.checkNavigable=function(i){var e,t;if(e=this.getNavigableIndexes(),t=0,i>e[e.length-1])i=e[e.length-1];else for(var o in e){if(i<e[o]){i=t;break}t=e[o]}return i},e.prototype.cleanUpEvents=function(){var e=this;e.options.dots&&null!==e.$dots&&(i("li",e.$dots).off("click.slick",e.changeSlide).off("mouseenter.slick",i.proxy(e.interrupt,e,!0)).off("mouseleave.slick",i.proxy(e.interrupt,e,!1)),!0===e.options.accessibility&&e.$dots.off("keydown.slick",e.keyHandler)),e.$slider.off("focus.slick blur.slick"),!0===e.options.arrows&&e.slideCount>e.options.slidesToShow&&(e.$prevArrow&&e.$prevArrow.off("click.slick",e.changeSlide),e.$nextArrow&&e.$nextArrow.off("click.slick",e.changeSlide),!0===e.options.accessibility&&(e.$prevArrow&&e.$prevArrow.off("keydown.slick",e.keyHandler),e.$nextArrow&&e.$nextArrow.off("keydown.slick",e.keyHandler))),e.$list.off("touchstart.slick mousedown.slick",e.swipeHandler),e.$list.off("touchmove.slick mousemove.slick",e.swipeHandler),e.$list.off("touchend.slick mouseup.slick",e.swipeHandler),e.$list.off("touchcancel.slick mouseleave.slick",e.swipeHandler),e.$list.off("click.slick",e.clickHandler),i(document).off(e.visibilityChange,e.visibility),e.cleanUpSlideEvents(),!0===e.options.accessibility&&e.$list.off("keydown.slick",e.keyHandler),!0===e.options.focusOnSelect&&i(e.$slideTrack).children().off("click.slick",e.selectHandler),i(window).off("orientationchange.slick.slick-"+e.instanceUid,e.orientationChange),i(window).off("resize.slick.slick-"+e.instanceUid,e.resize),i("[draggable!=true]",e.$slideTrack).off("dragstart",e.preventDefault),i(window).off("load.slick.slick-"+e.instanceUid,e.setPosition)},e.prototype.cleanUpSlideEvents=function(){var e=this;e.$list.off("mouseenter.slick",i.proxy(e.interrupt,e,!0)),e.$list.off("mouseleave.slick",i.proxy(e.interrupt,e,!1))},e.prototype.cleanUpRows=function(){var i,e=this;e.options.rows>1&&((i=e.$slides.children().children()).removeAttr("style"),e.$slider.empty().append(i))},e.prototype.clickHandler=function(i){!1===this.shouldClick&&(i.stopImmediatePropagation(),i.stopPropagation(),i.preventDefault())},e.prototype.destroy=function(e){var t=this;t.autoPlayClear(),t.touchObject={},t.cleanUpEvents(),i(".slick-cloned",t.$slider).detach(),t.$dots&&t.$dots.remove(),t.$prevArrow&&t.$prevArrow.length&&(t.$prevArrow.removeClass("slick-disabled slick-arrow slick-hidden").removeAttr("aria-hidden aria-disabled tabindex").css("display",""),t.htmlExpr.test(t.options.prevArrow)&&t.$prevArrow.remove()),t.$nextArrow&&t.$nextArrow.length&&(t.$nextArrow.removeClass("slick-disabled slick-arrow slick-hidden").removeAttr("aria-hidden aria-disabled tabindex").css("display",""),t.htmlExpr.test(t.options.nextArrow)&&t.$nextArrow.remove()),t.$slides&&(t.$slides.removeClass("slick-slide slick-active slick-center slick-visible slick-current").removeAttr("aria-hidden").removeAttr("data-slick-index").each(function(){i(this).attr("style",i(this).data("originalStyling"))}),t.$slideTrack.children(this.options.slide).detach(),t.$slideTrack.detach(),t.$list.detach(),t.$slider.append(t.$slides)),t.cleanUpRows(),t.$slider.removeClass("slick-slider"),t.$slider.removeClass("slick-initialized"),t.$slider.removeClass("slick-dotted"),t.unslicked=!0,e||t.$slider.trigger("destroy",[t])},e.prototype.disableTransition=function(i){var e=this,t={};t[e.transitionType]="",!1===e.options.fade?e.$slideTrack.css(t):e.$slides.eq(i).css(t)},e.prototype.fadeSlide=function(i,e){var t=this;!1===t.cssTransitions?(t.$slides.eq(i).css({zIndex:t.options.zIndex}),t.$slides.eq(i).animate({opacity:1},t.options.speed,t.options.easing,e)):(t.applyTransition(i),t.$slides.eq(i).css({opacity:1,zIndex:t.options.zIndex}),e&&setTimeout(function(){t.disableTransition(i),e.call()},t.options.speed))},e.prototype.fadeSlideOut=function(i){var e=this;!1===e.cssTransitions?e.$slides.eq(i).animate({opacity:0,zIndex:e.options.zIndex-2},e.options.speed,e.options.easing):(e.applyTransition(i),e.$slides.eq(i).css({opacity:0,zIndex:e.options.zIndex-2}))},e.prototype.filterSlides=e.prototype.slickFilter=function(i){var e=this;null!==i&&(e.$slidesCache=e.$slides,e.unload(),e.$slideTrack.children(this.options.slide).detach(),e.$slidesCache.filter(i).appendTo(e.$slideTrack),e.reinit())},e.prototype.focusHandler=function(){var e=this;e.$slider.off("focus.slick blur.slick").on("focus.slick blur.slick","*",function(t){t.stopImmediatePropagation();var o=i(this);setTimeout(function(){e.options.pauseOnFocus&&(e.focussed=o.is(":focus"),e.autoPlay())},0)})},e.prototype.getCurrent=e.prototype.slickCurrentSlide=function(){return this.currentSlide},e.prototype.getDotCount=function(){var i=this,e=0,t=0,o=0;if(!0===i.options.infinite)if(i.slideCount<=i.options.slidesToShow)++o;else for(;e<i.slideCount;)++o,e=t+i.options.slidesToScroll,t+=i.options.slidesToScroll<=i.options.slidesToShow?i.options.slidesToScroll:i.options.slidesToShow;else if(!0===i.options.centerMode)o=i.slideCount;else if(i.options.asNavFor)for(;e<i.slideCount;)++o,e=t+i.options.slidesToScroll,t+=i.options.slidesToScroll<=i.options.slidesToShow?i.options.slidesToScroll:i.options.slidesToShow;else o=1+Math.ceil((i.slideCount-i.options.slidesToShow)/i.options.slidesToScroll);return o-1},e.prototype.getLeft=function(i){var e,t,o,s,n=this,r=0;return n.slideOffset=0,t=n.$slides.first().outerHeight(!0),!0===n.options.infinite?(n.slideCount>n.options.slidesToShow&&(n.slideOffset=n.slideWidth*n.options.slidesToShow*-1,s=-1,!0===n.options.vertical&&!0===n.options.centerMode&&(2===n.options.slidesToShow?s=-1.5:1===n.options.slidesToShow&&(s=-2)),r=t*n.options.slidesToShow*s),n.slideCount%n.options.slidesToScroll!=0&&i+n.options.slidesToScroll>n.slideCount&&n.slideCount>n.options.slidesToShow&&(i>n.slideCount?(n.slideOffset=(n.options.slidesToShow-(i-n.slideCount))*n.slideWidth*-1,r=(n.options.slidesToShow-(i-n.slideCount))*t*-1):(n.slideOffset=n.slideCount%n.options.slidesToScroll*n.slideWidth*-1,r=n.slideCount%n.options.slidesToScroll*t*-1))):i+n.options.slidesToShow>n.slideCount&&(n.slideOffset=(i+n.options.slidesToShow-n.slideCount)*n.slideWidth,r=(i+n.options.slidesToShow-n.slideCount)*t),n.slideCount<=n.options.slidesToShow&&(n.slideOffset=0,r=0),!0===n.options.centerMode&&n.slideCount<=n.options.slidesToShow?n.slideOffset=n.slideWidth*Math.floor(n.options.slidesToShow)/2-n.slideWidth*n.slideCount/2:!0===n.options.centerMode&&!0===n.options.infinite?n.slideOffset+=n.slideWidth*Math.floor(n.options.slidesToShow/2)-n.slideWidth:!0===n.options.centerMode&&(n.slideOffset=0,n.slideOffset+=n.slideWidth*Math.floor(n.options.slidesToShow/2)),e=!1===n.options.vertical?i*n.slideWidth*-1+n.slideOffset:i*t*-1+r,!0===n.options.variableWidth&&(o=n.slideCount<=n.options.slidesToShow||!1===n.options.infinite?n.$slideTrack.children(".slick-slide").eq(i):n.$slideTrack.children(".slick-slide").eq(i+n.options.slidesToShow),e=!0===n.options.rtl?o[0]?-1*(n.$slideTrack.width()-o[0].offsetLeft-o.width()):0:o[0]?-1*o[0].offsetLeft:0,!0===n.options.centerMode&&(o=n.slideCount<=n.options.slidesToShow||!1===n.options.infinite?n.$slideTrack.children(".slick-slide").eq(i):n.$slideTrack.children(".slick-slide").eq(i+n.options.slidesToShow+1),e=!0===n.options.rtl?o[0]?-1*(n.$slideTrack.width()-o[0].offsetLeft-o.width()):0:o[0]?-1*o[0].offsetLeft:0,e+=(n.$list.width()-o.outerWidth())/2)),e},e.prototype.getOption=e.prototype.slickGetOption=function(i){return this.options[i]},e.prototype.getNavigableIndexes=function(){var i,e=this,t=0,o=0,s=[];for(!1===e.options.infinite?i=e.slideCount:(t=-1*e.options.slidesToScroll,o=-1*e.options.slidesToScroll,i=2*e.slideCount);t<i;)s.push(t),t=o+e.options.slidesToScroll,o+=e.options.slidesToScroll<=e.options.slidesToShow?e.options.slidesToScroll:e.options.slidesToShow;return s},e.prototype.getSlick=function(){return this},e.prototype.getSlideCount=function(){var e,t,o=this;return t=!0===o.options.centerMode?o.slideWidth*Math.floor(o.options.slidesToShow/2):0,!0===o.options.swipeToSlide?(o.$slideTrack.find(".slick-slide").each(function(s,n){if(n.offsetLeft-t+i(n).outerWidth()/2>-1*o.swipeLeft)return e=n,!1}),Math.abs(i(e).attr("data-slick-index")-o.currentSlide)||1):o.options.slidesToScroll},e.prototype.goTo=e.prototype.slickGoTo=function(i,e){this.changeSlide({data:{message:"index",index:parseInt(i)}},e)},e.prototype.init=function(e){var t=this;i(t.$slider).hasClass("slick-initialized")||(i(t.$slider).addClass("slick-initialized"),t.buildRows(),t.buildOut(),t.setProps(),t.startLoad(),t.loadSlider(),t.initializeEvents(),t.updateArrows(),t.updateDots(),t.checkResponsive(!0),t.focusHandler()),e&&t.$slider.trigger("init",[t]),!0===t.options.accessibility&&t.initADA(),t.options.autoplay&&(t.paused=!1,t.autoPlay())},e.prototype.initADA=function(){var e=this,t=Math.ceil(e.slideCount/e.options.slidesToShow),o=e.getNavigableIndexes().filter(function(i){return i>=0&&i<e.slideCount});e.$slides.add(e.$slideTrack.find(".slick-cloned")).attr({"aria-hidden":"true",tabindex:"-1"}).find("a, input, button, select").attr({tabindex:"-1"}),null!==e.$dots&&(e.$slides.not(e.$slideTrack.find(".slick-cloned")).each(function(t){var s=o.indexOf(t);i(this).attr({role:"tabpanel",id:"slick-slide"+e.instanceUid+t,tabindex:-1}),-1!==s&&i(this).attr({"aria-describedby":"slick-slide-control"+e.instanceUid+s})}),e.$dots.attr("role","tablist").find("li").each(function(s){var n=o[s];i(this).attr({role:"presentation"}),i(this).find("button").first().attr({role:"tab",id:"slick-slide-control"+e.instanceUid+s,"aria-controls":"slick-slide"+e.instanceUid+n,"aria-label":s+1+" of "+t,"aria-selected":null,tabindex:"-1"})}).eq(e.currentSlide).find("button").attr({"aria-selected":"true",tabindex:"0"}).end());for(var s=e.currentSlide,n=s+e.options.slidesToShow;s<n;s++)e.$slides.eq(s).attr("tabindex",0);e.activateADA()},e.prototype.initArrowEvents=function(){var i=this;!0===i.options.arrows&&i.slideCount>i.options.slidesToShow&&(i.$prevArrow.off("click.slick").on("click.slick",{message:"previous"},i.changeSlide),i.$nextArrow.off("click.slick").on("click.slick",{message:"next"},i.changeSlide),!0===i.options.accessibility&&(i.$prevArrow.on("keydown.slick",i.keyHandler),i.$nextArrow.on("keydown.slick",i.keyHandler)))},e.prototype.initDotEvents=function(){var e=this;!0===e.options.dots&&(i("li",e.$dots).on("click.slick",{message:"index"},e.changeSlide),!0===e.options.accessibility&&e.$dots.on("keydown.slick",e.keyHandler)),!0===e.options.dots&&!0===e.options.pauseOnDotsHover&&i("li",e.$dots).on("mouseenter.slick",i.proxy(e.interrupt,e,!0)).on("mouseleave.slick",i.proxy(e.interrupt,e,!1))},e.prototype.initSlideEvents=function(){var e=this;e.options.pauseOnHover&&(e.$list.on("mouseenter.slick",i.proxy(e.interrupt,e,!0)),e.$list.on("mouseleave.slick",i.proxy(e.interrupt,e,!1)))},e.prototype.initializeEvents=function(){var e=this;e.initArrowEvents(),e.initDotEvents(),e.initSlideEvents(),e.$list.on("touchstart.slick mousedown.slick",{action:"start"},e.swipeHandler),e.$list.on("touchmove.slick mousemove.slick",{action:"move"},e.swipeHandler),e.$list.on("touchend.slick mouseup.slick",{action:"end"},e.swipeHandler),e.$list.on("touchcancel.slick mouseleave.slick",{action:"end"},e.swipeHandler),e.$list.on("click.slick",e.clickHandler),i(document).on(e.visibilityChange,i.proxy(e.visibility,e)),!0===e.options.accessibility&&e.$list.on("keydown.slick",e.keyHandler),!0===e.options.focusOnSelect&&i(e.$slideTrack).children().on("click.slick",e.selectHandler),i(window).on("orientationchange.slick.slick-"+e.instanceUid,i.proxy(e.orientationChange,e)),i(window).on("resize.slick.slick-"+e.instanceUid,i.proxy(e.resize,e)),i("[draggable!=true]",e.$slideTrack).on("dragstart",e.preventDefault),i(window).on("load.slick.slick-"+e.instanceUid,e.setPosition),i(e.setPosition)},e.prototype.initUI=function(){var i=this;!0===i.options.arrows&&i.slideCount>i.options.slidesToShow&&(i.$prevArrow.show(),i.$nextArrow.show()),!0===i.options.dots&&i.slideCount>i.options.slidesToShow&&i.$dots.show()},e.prototype.keyHandler=function(i){var e=this;i.target.tagName.match("TEXTAREA|INPUT|SELECT")||(37===i.keyCode&&!0===e.options.accessibility?e.changeSlide({data:{message:!0===e.options.rtl?"next":"previous"}}):39===i.keyCode&&!0===e.options.accessibility&&e.changeSlide({data:{message:!0===e.options.rtl?"previous":"next"}}))},e.prototype.lazyLoad=function(){function e(e){i("img[data-lazy]",e).each(function(){var e=i(this),t=i(this).attr("data-lazy"),o=i(this).attr("data-srcset"),s=i(this).attr("data-sizes")||n.$slider.attr("data-sizes"),r=document.createElement("img");r.onload=function(){e.animate({opacity:0},100,function(){o&&(e.attr("srcset",o),s&&e.attr("sizes",s)),e.attr("src",t).animate({opacity:1},200,function(){e.removeAttr("data-lazy data-srcset data-sizes").removeClass("slick-loading")}),n.$slider.trigger("lazyLoaded",[n,e,t])})},r.onerror=function(){e.removeAttr("data-lazy").removeClass("slick-loading").addClass("slick-lazyload-error"),n.$slider.trigger("lazyLoadError",[n,e,t])},r.src=t})}var t,o,s,n=this;if(!0===n.options.centerMode?!0===n.options.infinite?s=(o=n.currentSlide+(n.options.slidesToShow/2+1))+n.options.slidesToShow+2:(o=Math.max(0,n.currentSlide-(n.options.slidesToShow/2+1)),s=n.options.slidesToShow/2+1+2+n.currentSlide):(o=n.options.infinite?n.options.slidesToShow+n.currentSlide:n.currentSlide,s=Math.ceil(o+n.options.slidesToShow),!0===n.options.fade&&(o>0&&o--,s<=n.slideCount&&s++)),t=n.$slider.find(".slick-slide").slice(o,s),"anticipated"===n.options.lazyLoad)for(var r=o-1,l=s,d=n.$slider.find(".slick-slide"),a=0;a<n.options.slidesToScroll;a++)r<0&&(r=n.slideCount-1),t=(t=t.add(d.eq(r))).add(d.eq(l)),r--,l++;e(t),n.slideCount<=n.options.slidesToShow?e(n.$slider.find(".slick-slide")):n.currentSlide>=n.slideCount-n.options.slidesToShow?e(n.$slider.find(".slick-cloned").slice(0,n.options.slidesToShow)):0===n.currentSlide&&e(n.$slider.find(".slick-cloned").slice(-1*n.options.slidesToShow))},e.prototype.loadSlider=function(){var i=this;i.setPosition(),i.$slideTrack.css({opacity:1}),i.$slider.removeClass("slick-loading"),i.initUI(),"progressive"===i.options.lazyLoad&&i.progressiveLazyLoad()},e.prototype.next=e.prototype.slickNext=function(){this.changeSlide({data:{message:"next"}})},e.prototype.orientationChange=function(){var i=this;i.checkResponsive(),i.setPosition()},e.prototype.pause=e.prototype.slickPause=function(){var i=this;i.autoPlayClear(),i.paused=!0},e.prototype.play=e.prototype.slickPlay=function(){var i=this;i.autoPlay(),i.options.autoplay=!0,i.paused=!1,i.focussed=!1,i.interrupted=!1},e.prototype.postSlide=function(e){var t=this;t.unslicked||(t.$slider.trigger("afterChange",[t,e]),t.animating=!1,t.slideCount>t.options.slidesToShow&&t.setPosition(),t.swipeLeft=null,t.options.autoplay&&t.autoPlay(),!0===t.options.accessibility&&(t.initADA(),t.options.focusOnChange&&i(t.$slides.get(t.currentSlide)).attr("tabindex",0).focus()))},e.prototype.prev=e.prototype.slickPrev=function(){this.changeSlide({data:{message:"previous"}})},e.prototype.preventDefault=function(i){i.preventDefault()},e.prototype.progressiveLazyLoad=function(e){e=e||1;var t,o,s,n,r,l=this,d=i("img[data-lazy]",l.$slider);d.length?(t=d.first(),o=t.attr("data-lazy"),s=t.attr("data-srcset"),n=t.attr("data-sizes")||l.$slider.attr("data-sizes"),(r=document.createElement("img")).onload=function(){s&&(t.attr("srcset",s),n&&t.attr("sizes",n)),t.attr("src",o).removeAttr("data-lazy data-srcset data-sizes").removeClass("slick-loading"),!0===l.options.adaptiveHeight&&l.setPosition(),l.$slider.trigger("lazyLoaded",[l,t,o]),l.progressiveLazyLoad()},r.onerror=function(){e<3?setTimeout(function(){l.progressiveLazyLoad(e+1)},500):(t.removeAttr("data-lazy").removeClass("slick-loading").addClass("slick-lazyload-error"),l.$slider.trigger("lazyLoadError",[l,t,o]),l.progressiveLazyLoad())},r.src=o):l.$slider.trigger("allImagesLoaded",[l])},e.prototype.refresh=function(e){var t,o,s=this;o=s.slideCount-s.options.slidesToShow,!s.options.infinite&&s.currentSlide>o&&(s.currentSlide=o),s.slideCount<=s.options.slidesToShow&&(s.currentSlide=0),t=s.currentSlide,s.destroy(!0),i.extend(s,s.initials,{currentSlide:t}),s.init(),e||s.changeSlide({data:{message:"index",index:t}},!1)},e.prototype.registerBreakpoints=function(){var e,t,o,s=this,n=s.options.responsive||null;if("array"===i.type(n)&&n.length){s.respondTo=s.options.respondTo||"window";for(e in n)if(o=s.breakpoints.length-1,n.hasOwnProperty(e)){for(t=n[e].breakpoint;o>=0;)s.breakpoints[o]&&s.breakpoints[o]===t&&s.breakpoints.splice(o,1),o--;s.breakpoints.push(t),s.breakpointSettings[t]=n[e].settings}s.breakpoints.sort(function(i,e){return s.options.mobileFirst?i-e:e-i})}},e.prototype.reinit=function(){var e=this;e.$slides=e.$slideTrack.children(e.options.slide).addClass("slick-slide"),e.slideCount=e.$slides.length,e.currentSlide>=e.slideCount&&0!==e.currentSlide&&(e.currentSlide=e.currentSlide-e.options.slidesToScroll),e.slideCount<=e.options.slidesToShow&&(e.currentSlide=0),e.registerBreakpoints(),e.setProps(),e.setupInfinite(),e.buildArrows(),e.updateArrows(),e.initArrowEvents(),e.buildDots(),e.updateDots(),e.initDotEvents(),e.cleanUpSlideEvents(),e.initSlideEvents(),e.checkResponsive(!1,!0),!0===e.options.focusOnSelect&&i(e.$slideTrack).children().on("click.slick",e.selectHandler),e.setSlideClasses("number"==typeof e.currentSlide?e.currentSlide:0),e.setPosition(),e.focusHandler(),e.paused=!e.options.autoplay,e.autoPlay(),e.$slider.trigger("reInit",[e])},e.prototype.resize=function(){var e=this;i(window).width()!==e.windowWidth&&(clearTimeout(e.windowDelay),e.windowDelay=window.setTimeout(function(){e.windowWidth=i(window).width(),e.checkResponsive(),e.unslicked||e.setPosition()},50))},e.prototype.removeSlide=e.prototype.slickRemove=function(i,e,t){var o=this;if(i="boolean"==typeof i?!0===(e=i)?0:o.slideCount-1:!0===e?--i:i,o.slideCount<1||i<0||i>o.slideCount-1)return!1;o.unload(),!0===t?o.$slideTrack.children().remove():o.$slideTrack.children(this.options.slide).eq(i).remove(),o.$slides=o.$slideTrack.children(this.options.slide),o.$slideTrack.children(this.options.slide).detach(),o.$slideTrack.append(o.$slides),o.$slidesCache=o.$slides,o.reinit()},e.prototype.setCSS=function(i){var e,t,o=this,s={};!0===o.options.rtl&&(i=-i),e="left"==o.positionProp?Math.ceil(i)+"px":"0px",t="top"==o.positionProp?Math.ceil(i)+"px":"0px",s[o.positionProp]=i,!1===o.transformsEnabled?o.$slideTrack.css(s):(s={},!1===o.cssTransitions?(s[o.animType]="translate("+e+", "+t+")",o.$slideTrack.css(s)):(s[o.animType]="translate3d("+e+", "+t+", 0px)",o.$slideTrack.css(s)))},e.prototype.setDimensions=function(){var i=this;!1===i.options.vertical?!0===i.options.centerMode&&i.$list.css({padding:"0px "+i.options.centerPadding}):(i.$list.height(i.$slides.first().outerHeight(!0)*i.options.slidesToShow),!0===i.options.centerMode&&i.$list.css({padding:i.options.centerPadding+" 0px"})),i.listWidth=i.$list.width(),i.listHeight=i.$list.height(),!1===i.options.vertical&&!1===i.options.variableWidth?(i.slideWidth=Math.ceil(i.listWidth/i.options.slidesToShow),i.$slideTrack.width(Math.ceil(i.slideWidth*i.$slideTrack.children(".slick-slide").length))):!0===i.options.variableWidth?i.$slideTrack.width(5e3*i.slideCount):(i.slideWidth=Math.ceil(i.listWidth),i.$slideTrack.height(Math.ceil(i.$slides.first().outerHeight(!0)*i.$slideTrack.children(".slick-slide").length)));var e=i.$slides.first().outerWidth(!0)-i.$slides.first().width();!1===i.options.variableWidth&&i.$slideTrack.children(".slick-slide").width(i.slideWidth-e)},e.prototype.setFade=function(){var e,t=this;t.$slides.each(function(o,s){e=t.slideWidth*o*-1,!0===t.options.rtl?i(s).css({position:"relative",right:e,top:0,zIndex:t.options.zIndex-2,opacity:0}):i(s).css({position:"relative",left:e,top:0,zIndex:t.options.zIndex-2,opacity:0})}),t.$slides.eq(t.currentSlide).css({zIndex:t.options.zIndex-1,opacity:1})},e.prototype.setHeight=function(){var i=this;if(1===i.options.slidesToShow&&!0===i.options.adaptiveHeight&&!1===i.options.vertical){var e=i.$slides.eq(i.currentSlide).outerHeight(!0);i.$list.css("height",e)}},e.prototype.setOption=e.prototype.slickSetOption=function(){var e,t,o,s,n,r=this,l=!1;if("object"===i.type(arguments[0])?(o=arguments[0],l=arguments[1],n="multiple"):"string"===i.type(arguments[0])&&(o=arguments[0],s=arguments[1],l=arguments[2],"responsive"===arguments[0]&&"array"===i.type(arguments[1])?n="responsive":void 0!==arguments[1]&&(n="single")),"single"===n)r.options[o]=s;else if("multiple"===n)i.each(o,function(i,e){r.options[i]=e});else if("responsive"===n)for(t in s)if("array"!==i.type(r.options.responsive))r.options.responsive=[s[t]];else{for(e=r.options.responsive.length-1;e>=0;)r.options.responsive[e].breakpoint===s[t].breakpoint&&r.options.responsive.splice(e,1),e--;r.options.responsive.push(s[t])}l&&(r.unload(),r.reinit())},e.prototype.setPosition=function(){var i=this;i.setDimensions(),i.setHeight(),!1===i.options.fade?i.setCSS(i.getLeft(i.currentSlide)):i.setFade(),i.$slider.trigger("setPosition",[i])},e.prototype.setProps=function(){var i=this,e=document.body.style;i.positionProp=!0===i.options.vertical?"top":"left","top"===i.positionProp?i.$slider.addClass("slick-vertical"):i.$slider.removeClass("slick-vertical"),void 0===e.WebkitTransition&&void 0===e.MozTransition&&void 0===e.msTransition||!0===i.options.useCSS&&(i.cssTransitions=!0),i.options.fade&&("number"==typeof i.options.zIndex?i.options.zIndex<3&&(i.options.zIndex=3):i.options.zIndex=i.defaults.zIndex),void 0!==e.OTransform&&(i.animType="OTransform",i.transformType="-o-transform",i.transitionType="OTransition",void 0===e.perspectiveProperty&&void 0===e.webkitPerspective&&(i.animType=!1)),void 0!==e.MozTransform&&(i.animType="MozTransform",i.transformType="-moz-transform",i.transitionType="MozTransition",void 0===e.perspectiveProperty&&void 0===e.MozPerspective&&(i.animType=!1)),void 0!==e.webkitTransform&&(i.animType="webkitTransform",i.transformType="-webkit-transform",i.transitionType="webkitTransition",void 0===e.perspectiveProperty&&void 0===e.webkitPerspective&&(i.animType=!1)),void 0!==e.msTransform&&(i.animType="msTransform",i.transformType="-ms-transform",i.transitionType="msTransition",void 0===e.msTransform&&(i.animType=!1)),void 0!==e.transform&&!1!==i.animType&&(i.animType="transform",i.transformType="transform",i.transitionType="transition"),i.transformsEnabled=i.options.useTransform&&null!==i.animType&&!1!==i.animType},e.prototype.setSlideClasses=function(i){var e,t,o,s,n=this;if(t=n.$slider.find(".slick-slide").removeClass("slick-active slick-center slick-current").attr("aria-hidden","true"),n.$slides.eq(i).addClass("slick-current"),!0===n.options.centerMode){var r=n.options.slidesToShow%2==0?1:0;e=Math.floor(n.options.slidesToShow/2),!0===n.options.infinite&&(i>=e&&i<=n.slideCount-1-e?n.$slides.slice(i-e+r,i+e+1).addClass("slick-active").attr("aria-hidden","false"):(o=n.options.slidesToShow+i,t.slice(o-e+1+r,o+e+2).addClass("slick-active").attr("aria-hidden","false")),0===i?t.eq(t.length-1-n.options.slidesToShow).addClass("slick-center"):i===n.slideCount-1&&t.eq(n.options.slidesToShow).addClass("slick-center")),n.$slides.eq(i).addClass("slick-center")}else i>=0&&i<=n.slideCount-n.options.slidesToShow?n.$slides.slice(i,i+n.options.slidesToShow).addClass("slick-active").attr("aria-hidden","false"):t.length<=n.options.slidesToShow?t.addClass("slick-active").attr("aria-hidden","false"):(s=n.slideCount%n.options.slidesToShow,o=!0===n.options.infinite?n.options.slidesToShow+i:i,n.options.slidesToShow==n.options.slidesToScroll&&n.slideCount-i<n.options.slidesToShow?t.slice(o-(n.options.slidesToShow-s),o+s).addClass("slick-active").attr("aria-hidden","false"):t.slice(o,o+n.options.slidesToShow).addClass("slick-active").attr("aria-hidden","false"));"ondemand"!==n.options.lazyLoad&&"anticipated"!==n.options.lazyLoad||n.lazyLoad()},e.prototype.setupInfinite=function(){var e,t,o,s=this;if(!0===s.options.fade&&(s.options.centerMode=!1),!0===s.options.infinite&&!1===s.options.fade&&(t=null,s.slideCount>s.options.slidesToShow)){for(o=!0===s.options.centerMode?s.options.slidesToShow+1:s.options.slidesToShow,e=s.slideCount;e>s.slideCount-o;e-=1)t=e-1,i(s.$slides[t]).clone(!0).attr("id","").attr("data-slick-index",t-s.slideCount).prependTo(s.$slideTrack).addClass("slick-cloned");for(e=0;e<o+s.slideCount;e+=1)t=e,i(s.$slides[t]).clone(!0).attr("id","").attr("data-slick-index",t+s.slideCount).appendTo(s.$slideTrack).addClass("slick-cloned");s.$slideTrack.find(".slick-cloned").find("[id]").each(function(){i(this).attr("id","")})}},e.prototype.interrupt=function(i){var e=this;i||e.autoPlay(),e.interrupted=i},e.prototype.selectHandler=function(e){var t=this,o=i(e.target).is(".slick-slide")?i(e.target):i(e.target).parents(".slick-slide"),s=parseInt(o.attr("data-slick-index"));s||(s=0),t.slideCount<=t.options.slidesToShow?t.slideHandler(s,!1,!0):t.slideHandler(s)},e.prototype.slideHandler=function(i,e,t){var o,s,n,r,l,d=null,a=this;if(e=e||!1,!(!0===a.animating&&!0===a.options.waitForAnimate||!0===a.options.fade&&a.currentSlide===i))if(!1===e&&a.asNavFor(i),o=i,d=a.getLeft(o),r=a.getLeft(a.currentSlide),a.currentLeft=null===a.swipeLeft?r:a.swipeLeft,!1===a.options.infinite&&!1===a.options.centerMode&&(i<0||i>a.getDotCount()*a.options.slidesToScroll))!1===a.options.fade&&(o=a.currentSlide,!0!==t?a.animateSlide(r,function(){a.postSlide(o)}):a.postSlide(o));else if(!1===a.options.infinite&&!0===a.options.centerMode&&(i<0||i>a.slideCount-a.options.slidesToScroll))!1===a.options.fade&&(o=a.currentSlide,!0!==t?a.animateSlide(r,function(){a.postSlide(o)}):a.postSlide(o));else{if(a.options.autoplay&&clearInterval(a.autoPlayTimer),s=o<0?a.slideCount%a.options.slidesToScroll!=0?a.slideCount-a.slideCount%a.options.slidesToScroll:a.slideCount+o:o>=a.slideCount?a.slideCount%a.options.slidesToScroll!=0?0:o-a.slideCount:o,a.animating=!0,a.$slider.trigger("beforeChange",[a,a.currentSlide,s]),n=a.currentSlide,a.currentSlide=s,a.setSlideClasses(a.currentSlide),a.options.asNavFor&&(l=(l=a.getNavTarget()).slick("getSlick")).slideCount<=l.options.slidesToShow&&l.setSlideClasses(a.currentSlide),a.updateDots(),a.updateArrows(),!0===a.options.fade)return!0!==t?(a.fadeSlideOut(n),a.fadeSlide(s,function(){a.postSlide(s)})):a.postSlide(s),void a.animateHeight();!0!==t?a.animateSlide(d,function(){a.postSlide(s)}):a.postSlide(s)}},e.prototype.startLoad=function(){var i=this;!0===i.options.arrows&&i.slideCount>i.options.slidesToShow&&(i.$prevArrow.hide(),i.$nextArrow.hide()),!0===i.options.dots&&i.slideCount>i.options.slidesToShow&&i.$dots.hide(),i.$slider.addClass("slick-loading")},e.prototype.swipeDirection=function(){var i,e,t,o,s=this;return i=s.touchObject.startX-s.touchObject.curX,e=s.touchObject.startY-s.touchObject.curY,t=Math.atan2(e,i),(o=Math.round(180*t/Math.PI))<0&&(o=360-Math.abs(o)),o<=45&&o>=0?!1===s.options.rtl?"left":"right":o<=360&&o>=315?!1===s.options.rtl?"left":"right":o>=135&&o<=225?!1===s.options.rtl?"right":"left":!0===s.options.verticalSwiping?o>=35&&o<=135?"down":"up":"vertical"},e.prototype.swipeEnd=function(i){var e,t,o=this;if(o.dragging=!1,o.swiping=!1,o.scrolling)return o.scrolling=!1,!1;if(o.interrupted=!1,o.shouldClick=!(o.touchObject.swipeLength>10),void 0===o.touchObject.curX)return!1;if(!0===o.touchObject.edgeHit&&o.$slider.trigger("edge",[o,o.swipeDirection()]),o.touchObject.swipeLength>=o.touchObject.minSwipe){switch(t=o.swipeDirection()){case"left":case"down":e=o.options.swipeToSlide?o.checkNavigable(o.currentSlide+o.getSlideCount()):o.currentSlide+o.getSlideCount(),o.currentDirection=0;break;case"right":case"up":e=o.options.swipeToSlide?o.checkNavigable(o.currentSlide-o.getSlideCount()):o.currentSlide-o.getSlideCount(),o.currentDirection=1}"vertical"!=t&&(o.slideHandler(e),o.touchObject={},o.$slider.trigger("swipe",[o,t]))}else o.touchObject.startX!==o.touchObject.curX&&(o.slideHandler(o.currentSlide),o.touchObject={})},e.prototype.swipeHandler=function(i){var e=this;if(!(!1===e.options.swipe||"ontouchend"in document&&!1===e.options.swipe||!1===e.options.draggable&&-1!==i.type.indexOf("mouse")))switch(e.touchObject.fingerCount=i.originalEvent&&void 0!==i.originalEvent.touches?i.originalEvent.touches.length:1,e.touchObject.minSwipe=e.listWidth/e.options.touchThreshold,!0===e.options.verticalSwiping&&(e.touchObject.minSwipe=e.listHeight/e.options.touchThreshold),i.data.action){case"start":e.swipeStart(i);break;case"move":e.swipeMove(i);break;case"end":e.swipeEnd(i)}},e.prototype.swipeMove=function(i){var e,t,o,s,n,r,l=this;return n=void 0!==i.originalEvent?i.originalEvent.touches:null,!(!l.dragging||l.scrolling||n&&1!==n.length)&&(e=l.getLeft(l.currentSlide),l.touchObject.curX=void 0!==n?n[0].pageX:i.clientX,l.touchObject.curY=void 0!==n?n[0].pageY:i.clientY,l.touchObject.swipeLength=Math.round(Math.sqrt(Math.pow(l.touchObject.curX-l.touchObject.startX,2))),r=Math.round(Math.sqrt(Math.pow(l.touchObject.curY-l.touchObject.startY,2))),!l.options.verticalSwiping&&!l.swiping&&r>4?(l.scrolling=!0,!1):(!0===l.options.verticalSwiping&&(l.touchObject.swipeLength=r),t=l.swipeDirection(),void 0!==i.originalEvent&&l.touchObject.swipeLength>4&&(l.swiping=!0,i.preventDefault()),s=(!1===l.options.rtl?1:-1)*(l.touchObject.curX>l.touchObject.startX?1:-1),!0===l.options.verticalSwiping&&(s=l.touchObject.curY>l.touchObject.startY?1:-1),o=l.touchObject.swipeLength,l.touchObject.edgeHit=!1,!1===l.options.infinite&&(0===l.currentSlide&&"right"===t||l.currentSlide>=l.getDotCount()&&"left"===t)&&(o=l.touchObject.swipeLength*l.options.edgeFriction,l.touchObject.edgeHit=!0),!1===l.options.vertical?l.swipeLeft=e+o*s:l.swipeLeft=e+o*(l.$list.height()/l.listWidth)*s,!0===l.options.verticalSwiping&&(l.swipeLeft=e+o*s),!0!==l.options.fade&&!1!==l.options.touchMove&&(!0===l.animating?(l.swipeLeft=null,!1):void l.setCSS(l.swipeLeft))))},e.prototype.swipeStart=function(i){var e,t=this;if(t.interrupted=!0,1!==t.touchObject.fingerCount||t.slideCount<=t.options.slidesToShow)return t.touchObject={},!1;void 0!==i.originalEvent&&void 0!==i.originalEvent.touches&&(e=i.originalEvent.touches[0]),t.touchObject.startX=t.touchObject.curX=void 0!==e?e.pageX:i.clientX,t.touchObject.startY=t.touchObject.curY=void 0!==e?e.pageY:i.clientY,t.dragging=!0},e.prototype.unfilterSlides=e.prototype.slickUnfilter=function(){var i=this;null!==i.$slidesCache&&(i.unload(),i.$slideTrack.children(this.options.slide).detach(),i.$slidesCache.appendTo(i.$slideTrack),i.reinit())},e.prototype.unload=function(){var e=this;i(".slick-cloned",e.$slider).remove(),e.$dots&&e.$dots.remove(),e.$prevArrow&&e.htmlExpr.test(e.options.prevArrow)&&e.$prevArrow.remove(),e.$nextArrow&&e.htmlExpr.test(e.options.nextArrow)&&e.$nextArrow.remove(),e.$slides.removeClass("slick-slide slick-active slick-visible slick-current").attr("aria-hidden","true").css("width","")},e.prototype.unslick=function(i){var e=this;e.$slider.trigger("unslick",[e,i]),e.destroy()},e.prototype.updateArrows=function(){var i=this;Math.floor(i.options.slidesToShow/2),!0===i.options.arrows&&i.slideCount>i.options.slidesToShow&&!i.options.infinite&&(i.$prevArrow.removeClass("slick-disabled").attr("aria-disabled","false"),i.$nextArrow.removeClass("slick-disabled").attr("aria-disabled","false"),0===i.currentSlide?(i.$prevArrow.addClass("slick-disabled").attr("aria-disabled","true"),i.$nextArrow.removeClass("slick-disabled").attr("aria-disabled","false")):i.currentSlide>=i.slideCount-i.options.slidesToShow&&!1===i.options.centerMode?(i.$nextArrow.addClass("slick-disabled").attr("aria-disabled","true"),i.$prevArrow.removeClass("slick-disabled").attr("aria-disabled","false")):i.currentSlide>=i.slideCount-1&&!0===i.options.centerMode&&(i.$nextArrow.addClass("slick-disabled").attr("aria-disabled","true"),i.$prevArrow.removeClass("slick-disabled").attr("aria-disabled","false")))},e.prototype.updateDots=function(){var i=this;null!==i.$dots&&(i.$dots.find("li").removeClass("slick-active").end(),i.$dots.find("li").eq(Math.floor(i.currentSlide/i.options.slidesToScroll)).addClass("slick-active"))},e.prototype.visibility=function(){var i=this;i.options.autoplay&&(document[i.hidden]?i.interrupted=!0:i.interrupted=!1)},i.fn.slick=function(){var i,t,o=this,s=arguments[0],n=Array.prototype.slice.call(arguments,1),r=o.length;for(i=0;i<r;i++)if("object"==typeof s||void 0===s?o[i].slick=new e(o[i],s):t=o[i].slick[s].apply(o[i].slick,n),void 0!==t)return t;return o}});
(function($) {
    var carousel = function(element, index) {
        var self = this;
        self.$ctx = $(element);

        var windowWidth = $(window).width(),
            mobileWidth = 768;

        ElementStateCookies.setId(self.$ctx, 'text_slider_carousel' + index);

        initListeners();
        initCarousel();

        //swap assets between mobile/desktop (on page load and window resize)
        function swapAssets() {
            var textsliderWrapper = self.$ctx.find(".textslider .component-wrapper"), 
                textsliderBGImg;

            if (windowWidth <= mobileWidth) {
                //mobile
                textsliderBGImg = textsliderWrapper.data("mobile-img");
            } else {
                //desktop
                textsliderBGImg = textsliderWrapper.data("desktop-img");
            }
            textsliderWrapper.css("background-image", "url('" + textsliderBGImg + "')");
        };

        function initListeners() {
            //swap assets between mobile/desktop (on page load and window resize)
            swapAssets();

            $(window).resize(function() {
              windowWidth = $(window).width();
              swapAssets();
            });
        };

        function initCarousel() {
            //init text carousel

            self.$ctx.find(".textslider-wrapper").slick({
                infinite: true,
                variableWidth:true,
                slidesToScroll: 1,
                speed: 300,
                arrows: false,
                nextArrow: self.$ctx.find(".right-arrow-svg"),
                prevArrow: self.$ctx.find(".left-arrow-svg"),
                autoplay: false,
                mobileFirst: true,
                responsive: [
                    {
                      breakpoint: 767,
                      settings: {
                        slidesToShow: 1.06,
                        variableWidth:false,
                        slidesToShow: 1,
                        centerMode: true,
                        arrows: true
                      }
                    }
                  ]
            });
        };

        self.$ctx.find(".textslider-wrapper").on('afterChange', function (event, slick, currentSlide, nextSlide) {
            ElementStateCookies.verifyCarouselValue(self.$ctx, currentSlide);               
        });

        self.$ctx.find(".textslider-wrapper").slick('slickGoTo', ElementStateCookies.getValue(self.$ctx));

    };
    $(document).ready(function(){
    $('.carousel').each(function(index) {
        new carousel(this, index);
    });
    });
})(jQuery);
(function ($) {
    var imageCarousel = function (element, index) {
        var self = this;
        self.$ctx = $(element);

        var windowWidth = $(window).width(),
            mobileWidth = 767,
            totalWidth = 0,
            setWidthCount = 0;

        ElementStateCookies.setId(self.$ctx, 'image_carousel' + index);
        initListeners();
        initImgCarousel();       

        //swap assets between mobile/desktop (on page load and window resize)
        function swapAssets() {
            var $imagesliderImg = self.$ctx.find(".imageslider-wrapper .imageslider-slide img"),
                ImgUrl = "";

            //change slider images between mobile/desktop
            $imagesliderImg.each(function () {
                if (windowWidth <= mobileWidth) { //mobile
                    ImgUrl = $(this).data("mobile-img");
                } else { //desktop
                    ImgUrl = $(this).data("desktop-img");
                }

                $(this).attr("src", ImgUrl);
                $(this).parent().css("background-image", "url(" + ImgUrl + ")");
            });
        };

        function initListeners() {
            //swap assets between mobile/desktop (on page load and window resize)
            swapAssets();

            $(window).resize(function () {
                windowWidth = $(window).width();
                swapAssets();
            });
        };

        function initImgCarousel() {

            

            self.$ctx.find(".textslider-wrapper").slick({
                infinite: true,
                variableWidth: true,
                slidesToScroll: 1,
                touchThreshold: 6,
                speed: 300,
                arrows: false,
                nextArrow: self.$ctx.find(".right-arrow-svg"),
                prevArrow: self.$ctx.find(".left-arrow-svg"),
                autoplay: false,
                asNavFor: self.$ctx.find('.imageslider-wrapper'),
                mobileFirst: true,
                responsive: [{
                    breakpoint: 767,
                    settings: {
                        slidesToShow: 1.06,
                        variableWidth: false,
                        slidesToShow: 1,
                        centerMode: true,
                        arrows: true
                    }
                }]
            });

            self.$ctx.find('.imageslider-wrapper').slick({
                infinite: true,
                slidesToShow: 1,
                slidesToScroll: 1,
                touchThreshold: 6,
                arrows: false,
                autoplay: false,
                centerPadding: '1px',
                asNavFor: self.$ctx.find('.textslider-wrapper')
            });
            var defaultStyle = self.$ctx.find('.textslider').data('carousel-style');
            self.$ctx.find(".textslider-wrapper").on('beforeChange', function (event, slick, currentSlide, nextSlide) {

                var carouselStyle = self.$ctx.find('.textslider').data('carousel-style');
                var tileStyle = self.$ctx.find(".textslider-wrapper .slick-current").data('tile-style');
                if (currentSlide !== undefined && nextSlide !== undefined && currentSlide !== nextSlide) {
                    tileStyle = self.$ctx.find(".textslider-wrapper .slick-current").prev().data('tile-style');
                    if (nextSlide === currentSlide + 1 || ( nextSlide === 0 && slick.slideCount === currentSlide + 1)) {
                        tileStyle = self.$ctx.find(".textslider-wrapper .slick-current").next().data('tile-style');
                    }
                }
                if (tileStyle && carouselStyle && carouselStyle !== tileStyle) {
                    if (tileStyle !== 'accordion-light-background') {
                        applyTileStyle(carouselStyle, tileStyle);
                        self.$ctx.find('.textslider').data('carousel-style', tileStyle);
                    } else {
                        applyTileStyle(carouselStyle, defaultStyle);
                        self.$ctx.find('.textslider').data('carousel-style', defaultStyle);
                    }                    
                }
            });

            self.$ctx.find(".textslider-wrapper").on('afterChange', function (event, slick, currentSlide, nextSlide) {
                ElementStateCookies.verifyCarouselValue(self.$ctx, currentSlide);             
            });

            self.$ctx.find(".textslider-wrapper").slick('slickGoTo', ElementStateCookies.getValue(self.$ctx));

            self.$ctx.find(".textslider-wrapper").trigger('beforeChange');
        };

        function applyTileStyle(carouselStyle, tileStyle) {
            var $currentEl = self.$ctx.find('.textslider');
            $currentEl.removeClass(carouselStyle);
            $currentEl.addClass(tileStyle);
        }
    };
    $(window).on("load.slick",function(){
    $('.imagecarousel').each(function (index) {
        new imageCarousel(this, index);
    });
    });
})(jQuery);
