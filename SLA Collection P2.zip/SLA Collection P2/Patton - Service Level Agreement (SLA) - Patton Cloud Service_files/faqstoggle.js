function toggle(obj, num) {
if(document.getElementById(obj).style.display == 'block'){
  eval("document.getElementById(obj).style.display='none'");
  eval("document.getElementById('img'+num).src='/images/common/btn_plus.gif'");
}
else {
  eval("document.getElementById(obj).style.display='block'");
  eval("document.getElementById('img'+num).src='/images/common/btn_minus.gif'");
}
}

function togglesolution(obj, num) {
if(document.getElementById(obj).style.display == 'block'){
  eval("document.getElementById(obj).style.display='none'");
  eval("document.getElementById('img'+num).src='/images/solutions/main/plus.png'");
}
else {
  eval("document.getElementById(obj).style.display='block'");
  eval("document.getElementById('img'+num).src='/images/solutions/main/minus.png'");
}
}

function togglemedia(obj, num) {
if(document.getElementById('cat'+obj).style.display == 'block'){
  eval("document.getElementById('cat'+obj).style.display='none'");
}
else {
  for(var i=1;i<=num;i++){
	  eval("document.getElementById('cat'+i).style.display='none'");
  }
  eval("document.getElementById('cat'+obj).style.display='block'");
}
}

function toggleallmedia(obj, num) {
if(obj == 'hide'){
  for(var i=1;i<=num;i++){
	  eval("document.getElementById('cat'+i).style.display='none'");
  }
}
else {
  for(var i=1;i<=num;i++){
	  eval("document.getElementById('cat'+i).style.display='block'");
  }
}
}

function toggleall(obj) {
  if(obj == "col"){
	for (var i=1;i<parseInt(document.getElementById('main').value);i++) {
		eval("document.getElementById('main'+i).style.display='none'");
	}
	for (var i=1;i<parseInt(document.getElementById('sub').value);i++) {
		eval("document.getElementById('sub'+i).style.display='none'");
	}
	for (var i=1;i<parseInt(document.getElementById('faq').value);i++) {
		eval("document.getElementById('faq'+i).style.display='none'");
	}
	for (var i=1;i<parseInt(document.getElementById('total').value);i++) {
		eval("document.getElementById('img'+i).src='/images/common/btn_plus.gif'");
	}
  }
  else {
	for (var i=1;i<parseInt(document.getElementById('main').value);i++) {
		eval("document.getElementById('main'+i).style.display='block'");
	}
	for (var i=1;i<parseInt(document.getElementById('sub').value);i++) {
		eval("document.getElementById('sub'+i).style.display='block'");
	}
	for (var i=1;i<parseInt(document.getElementById('faq').value);i++) {
		eval("document.getElementById('faq'+i).style.display='block'");
	}
	for (var i=1;i<parseInt(document.getElementById('total').value);i++) {
		eval("document.getElementById('img'+i).src='/images/common/btn_minus.gif'");
	}
  }
}

function ctoggleall(obj) {
  if(obj == "col"){
	for (var i=1;i<parseInt(document.getElementById('main').value);i++) {
		eval("document.getElementById('main'+i).style.display='none'");
	}
	for (var i=1;i<parseInt(document.getElementById('config').value);i++) {
		eval("document.getElementById('config'+i).style.display='none'");
	}
	for (var i=1;i<parseInt(document.getElementById('total').value);i++) {
		eval("document.getElementById('img'+i).src='/images/common/btn_plus.gif'");
	}
  }
  else {
	for (var i=1;i<parseInt(document.getElementById('main').value);i++) {
		eval("document.getElementById('main'+i).style.display='block'");
	}
	for (var i=1;i<parseInt(document.getElementById('config').value);i++) {
		eval("document.getElementById('config'+i).style.display='block'");
	}
	for (var i=1;i<parseInt(document.getElementById('total').value);i++) {
		eval("document.getElementById('img'+i).src='/images/common/btn_minus.gif'");
	}
  }
}

function togglevi(obj, num, t) {
if(document.getElementById(obj).style.display == 'block'){
  eval("document.getElementById(obj).style.display='none'");
  eval("document.getElementById('td'+num).style.background='#C2BFBF'");
}
else {
  eval("document.getElementById(obj).style.display='block'");
  eval("document.getElementById('td'+num).style.background='#e6e6e6'");
}
}
