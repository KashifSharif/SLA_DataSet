function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}

function textCounter(field, countfield, maxlimit) {
if (field.value.length > maxlimit)
field.value = field.value.substring(0, maxlimit);
else
countfield.value = maxlimit - field.value.length;
}

function location_change(url) {
      	window.location = url;
}

function refreshParent(url) {
  window.opener.location.href = url;
  if (window.opener.progressWindow) 
    window.opener.progressWindow.close();
  window.close();
}

function popupwin(url,head,h,w) {
	// head = removeSpaces(head);
        remote = window.open(url,"Patton","height="+h+",width="+w+",left=200,top=200");
}

function toggle_category(t){
	if (document.getElementById(t).style.display == 'none'){
		document.getElementById(t).style.display='block';
	} else {
		document.getElementById(t).style.display='none';
	}
}

function togglewizardlist(r) {
	var o = document.forms["divshow"].dshow.value;
	
	if (o != '' && o != null && o != undefined && o != 'none'){
			document.getElementById(o).style.display='none';
	}
	if (o != r) {
		document.getElementById(r).style.display='block';
		document.forms["divshow"].dshow.value = r;
	}
	if (o == r) {
		document.forms["divshow"].dshow.value = 'none';
	}
	
}

function togglesoftwarefeatures(sf) {
		var c = document.forms[sf + "_count"].count.value;
		var s = document.forms[sf + "_count"].show.value;
		
		if (s == 'none'){
			for (var i = 1; i <= c; i++){
				document.getElementById(sf + '_' + i).style.display='block';
			}
			document.forms[sf + "_count"].show.value = 'block';
		}
		if (s == 'block'){
			for (var i = 1; i <= c; i++){
				document.getElementById(sf + '_' + i).style.display='none';
			}
			document.forms[sf + "_count"].show.value = 'none';
		}		
}

function togglewizardcomments(r) {
	var o = document.forms["divshow"].cshow.value;
	
	if (o != '' && o != null && o != undefined && o != 'none'){
			document.getElementById(o).style.display='none';
	}
	if (o != r) {
		document.getElementById(r).style.display='block';
		document.forms["divshow"].cshow.value = r;
	}
	if (o == r) {
		document.forms["divshow"].cshow.value = '';
	}
	
}

function togglewizard(r) {
	if (r == 'uroll'){
		if (document.forms["rolls"].urollstat.value == 'hide'){
			document.getElementById('uroll').style.display='block';
			document.forms["rolls"].urollstat.value = "show";
		} else {
			document.getElementById('uroll').style.display='none';
			document.forms["rolls"].urollstat.value = "hide";
		}
	}
	if (r == 'croll'){
		if (document.forms["rolls"].crollstat.value == 'hide'){
			document.getElementById('croll').style.display='block';
			document.forms["rolls"].crollstat.value = "show";
		} else {
			document.getElementById('croll').style.display='none';
			document.forms["rolls"].crollstat.value = "hide";
		}
	}	
}
function toggleacc(i,t) {
	if (document.getElementById(t).style.display == 'none'){
		document.getElementById(t).style.display='block';
		document.getElementById(i).src = '/images/common/btn_minus.gif';
		document.getElementById(t + '_2').style.display='block';
		document.getElementById(i + '_2').src = '/images/common/btn_minus.gif';
	} else {
		document.getElementById(t).style.display = 'none';
		document.getElementById(i).src = '/images/common/btn_plus.gif';
		document.getElementById(t + '_2').style.display = 'none';
		document.getElementById(i + '_2').src = '/images/common/btn_plus.gif';
	}
}

function findrep(){
	var newname = document.forms["findrepform"].country.options[document.forms["findrepform"].country.selectedIndex].value;
	var oldname = document.forms["findrepform"].divselect.value;

	if (oldname != ''){
		document.getElementById(oldname).style.display = 'none';
	}
	document.getElementById(newname).style.display = 'block';
	document.forms["findrepform"].divselect.value = newname;
}

function findcontact(){
	var newname = document.forms["findcontactform"].country.options[document.forms["findcontactform"].country.selectedIndex].value;
	var oldname = document.forms["findcontactform"].divcontact.value;

	if (oldname != ''){
		document.getElementById(oldname).style.display = 'none';
	}
	document.getElementById(newname).style.display = 'block';
	document.forms["findcontactform"].divcontact.value = newname;
}

function bankref(){
	if (document.getElementById('bank_ref_attached').checked == true){
		document.getElementById('bank_name').style.background='#FFFFFF';
		document.getElementById('bank_contact').style.background='#FFFFFF';
		document.getElementById('bank_phone').style.background='#FFFFFF';
		document.getElementById('bank_account').style.background='#FFFFFF';
	} else {
		document.getElementById('bank_name').style.background='#ACD1F5';
		document.getElementById('bank_contact').style.background='#ACD1F5';
		document.getElementById('bank_phone').style.background='#ACD1F5';
		document.getElementById('bank_account').style.background='#ACD1F5';
	}
}
function showregion(tb){
	var oldname = document.forms["regform"].regselect.value;

	document.getElementById('westeur').style.display = 'none';
	document.getElementById('usa').style.display = 'none';
	document.getElementById('asia').style.display = 'none';
	document.getElementById('india').style.display = 'none';
	document.getElementById('latam').style.display = 'none';
	document.getElementById('mena').style.display = 'none';
	document.getElementById('easteur').style.display = 'none';
	if (oldname != ''){
		document.getElementById(oldname).style.display = 'none';
	}
	document.getElementById(tb).style.display = 'block';
	document.forms["regform"].regselect.value = tb;
	window.location.hash = 'reps';
}

function selectguide(){
	var newname = document.forms["requestform"].guideselect.options[document.forms["requestform"].guideselect.selectedIndex].value;
	var oldname = document.forms["requestform"].gnum.value;

	document.getElementById('g' + oldname).style.display = 'none';
	document.getElementById('g' + newname).style.display = 'block';
	document.forms["requestform"].gnum.value = newname;
}

function selectguiderequest(){
	var newname = document.forms["requestform"].guideselect.options[document.forms["requestform"].guideselect.selectedIndex].value;
	var oldname = document.forms["requestform"].gnum.value;

	document.getElementById('g' + oldname).style.display = 'none';
	document.getElementById('g' + newname).style.display = 'block';
	document.getElementById('guidetext').innerHTML = document.getElementById('guideselectname' + newname).innerHTML;
	document.forms["requestform"].gnum.value = newname;
}

function producthover(tb){
	var olddiv = document.forms["divform"].divselect.value;
	var newcell = tb + '_cell';

	if (tb != olddiv){
		document.getElementById(newcell).className = 'product_tab_unselected';
	}
}

function servicetab(tb){
	var olddiv = document.forms["divform"].divselect.value;
	var oldcell = document.forms["divform"].divselect.value + '_cell';
	var newcell = tb + '_cell';

	document.getElementById(olddiv).style.display = 'none';
	document.getElementById(tb).style.display = 'block';
	
	document.getElementById(oldcell).className = 'product_tab_unselected';
	document.getElementById(newcell).className = 'product_tab_selected';
	
	document.forms["divform"].divselect.value = tb;
}

function producttab(tb,sttb,sdiv){
	var olddiv = document.forms["divform"].divselect.value;
	var oldcell = document.forms["divform"].divselect.value + '_cell';
	var newcell = tb + '_cell';

	document.getElementById(olddiv).style.display = 'none';
	document.getElementById(tb).style.display = 'block';
	
	document.getElementById(oldcell).className = 'product_tab_unselected';
	document.getElementById(newcell).className = 'product_tab_selected';
	
	if (newcell != sttb){
		document.getElementById(sttb).className = 'product_tab_unselected';
		document.getElementById(sdiv).style.display = 'none';
	}

	document.forms["divform"].divselect.value = tb;
}

function producttabnew(tb,sdiv){
	var olddiv = document.forms["divform"].divselect.value;

	document.getElementById(olddiv).style.display = 'none';
	document.getElementById(tb).style.display = 'block';
		
	//if (tb != sdiv){
	//	document.getElementById(sdiv).style.display = 'none';
	//}

	document.forms["divform"].divselect.value = tb;
}

function solhover(tb){
	var olddiv = document.forms["divform"].divselect.value;
	var newcell = tb + '_cell';

	if (tb != olddiv){
		document.getElementById(newcell).className = 'sol_tab_unselected';
	}
}

function soltab(tb){
	var olddiv = document.forms["divform"].divselect.value;
	var oldcell = document.forms["divform"].divselect.value + '_cell';
	var newcell = tb + '_cell';

	document.getElementById(olddiv).style.display = 'none';
	document.getElementById(tb).style.display = 'block';
	
	document.getElementById(oldcell).className = 'sol_tab_unselected';
	document.getElementById(newcell).className = 'sol_tab_selected';

	document.forms["divform"].divselect.value = tb;
}

function partner(t,dr,r){
	var oldnum = document.forms[t + "form"].ptselect.value;

	if (dr == 'r' && oldnum != r){
		var newnum = parseInt(document.forms[t + "form"].ptselect.value) + 1;
		document.getElementById(t + oldnum).style.display = 'none';	
		document.getElementById(t + newnum).style.display = 'block';
		document.forms[t + "form"].ptselect.value = newnum;
	}
	if (dr == 'r' && oldnum == r){
		var newnum = 1;
		document.getElementById(t + oldnum).style.display = 'none';	
		document.getElementById(t + newnum).style.display = 'block';
		document.forms[t + "form"].ptselect.value = newnum;
	}	
	if (dr == 'l' && oldnum != 1){
		var newnum = parseInt(document.forms[t + "form"].ptselect.value) - 1;
		document.getElementById(t + oldnum).style.display = 'none';	
		document.getElementById(t + newnum).style.display = 'block';
		document.forms[t + "form"].ptselect.value = newnum;
	}
	if (newnum == r){
		document.getElementById('rightarrow' + t).style.display = 'none';
	} else {
		document.getElementById('rightarrow' + t).style.display = 'block';
	}
	if (newnum == 1){
		document.getElementById('leftarrow' + t).style.display = 'none';
	} else {
		document.getElementById('leftarrow' + t).style.display = 'block';
	}
}

function soft_cycle(r) {
	partner('soft','r',r);

    window.setTimeout('soft_cycle(' + r + ');',8000);
}

function ip_cycle(r) {
	partner('ip','r',r);

    window.setTimeout('ip_cycle(' + r + ');',8000);
}
function vp_cycle(r) {
	partner('voip','r',r);

    window.setTimeout('vp_cycle(' + r + ');',8000);
}
  
function newsticker(dr){
	var oldnum = document.forms["news"].snum.value;

	if (dr == 'r' && oldnum != 9){
		var newnum = parseInt(document.forms["news"].snum.value) + 1;
		document.getElementById('n' + oldnum).style.display = 'none';	
		document.getElementById('n' + newnum).style.display = 'block';
		document.forms["news"].snum.value = newnum;
	}
	if (dr == 'l' && oldnum != 1){
		var newnum = parseInt(document.forms["news"].snum.value) - 1;
		document.getElementById('n' + oldnum).style.display = 'none';	
		document.getElementById('n' + newnum).style.display = 'block';
		document.forms["news"].snum.value = newnum;
	}
	if (newnum == 9){
		document.getElementById('rightarrow').style.display = 'none';
	} else {
		document.getElementById('rightarrow').style.display = 'block';
	}
	if (newnum == 1){
		document.getElementById('leftarrow').style.display = 'none';
	} else {
		document.getElementById('leftarrow').style.display = 'block';
	}
}

function trainingticker(dr){
	var oldnum = document.forms["training"].tnum.value;

	if (dr == 'r' && oldnum != 10){
		var newnum = parseInt(document.forms["training"].tnum.value) + 1;
		document.getElementById('nt' + oldnum).style.display = 'none';	
		document.getElementById('nt' + newnum).style.display = 'block';
		document.forms["training"].tnum.value = newnum;
	}
	if (dr == 'l' && oldnum != 1){
		var newnum = parseInt(document.forms["training"].tnum.value) - 1;
		document.getElementById('nt' + oldnum).style.display = 'none';	
		document.getElementById('nt' + newnum).style.display = 'block';
		document.forms["training"].tnum.value = newnum;
	}
	if (newnum == 10){
		document.getElementById('rightarrowtr').style.display = 'none';
	} else {
		document.getElementById('rightarrowtr').style.display = 'block';
	}
	if (newnum == 1){
		document.getElementById('leftarrowtr').style.display = 'none';
	} else {
		document.getElementById('leftarrowtr').style.display = 'block';
	}
}

function companyhistory(tb){
	if (tb == 'overview'){
		document.getElementById('overview').style.display = 'block';	
		document.getElementById('history').style.display = 'none';	
		document.getElementById('ops').style.display = 'none';	
		document.getElementById('customers').style.display = 'none';	
		document.getElementById('overview_cell').className = 'company_menu_selected';
		document.getElementById('history_cell').className = 'company_menu_unselected';
		document.getElementById('ops_cell').className = 'company_menu_unselected';
		document.getElementById('customers_cell').className = 'company_menu_unselected';
		document.getElementById('l1').src = '/images/common/pe_logo_white.png';
		document.getElementById('l2').src = '/images/common/pe_logo.png';
		document.getElementById('l3').src = '/images/common/pe_logo.png';
		document.getElementById('l4').src = '/images/common/pe_logo.png';
	}
	if (tb == 'history'){
		document.getElementById('overview').style.display = 'none';	
		document.getElementById('history').style.display = 'block';	
		document.getElementById('ops').style.display = 'none';	
		document.getElementById('customers').style.display = 'none';	
		document.getElementById('overview_cell').className = 'company_menu_unselected';
		document.getElementById('history_cell').className = 'company_menu_selected';
		document.getElementById('ops_cell').className = 'company_menu_unselected';
		document.getElementById('customers_cell').className = 'company_menu_unselected';
		document.getElementById('l1').src = '/images/common/pe_logo.png';
		document.getElementById('l2').src = '/images/common/pe_logo_white.png';
		document.getElementById('l3').src = '/images/common/pe_logo.png';
		document.getElementById('l4').src = '/images/common/pe_logo.png';
	}
	if (tb == 'ops'){
		document.getElementById('overview').style.display = 'none';	
		document.getElementById('history').style.display = 'none';	
		document.getElementById('ops').style.display = 'block';	
		document.getElementById('customers').style.display = 'none';	
		document.getElementById('overview_cell').className = 'company_menu_unselected';
		document.getElementById('history_cell').className = 'company_menu_unselected';
		document.getElementById('ops_cell').className = 'company_menu_selected';
		document.getElementById('customers_cell').className = 'company_menu_unselected';
		document.getElementById('l1').src = '/images/common/pe_logo.png';
		document.getElementById('l2').src = '/images/common/pe_logo.png';
		document.getElementById('l3').src = '/images/common/pe_logo_white.png';
		document.getElementById('l4').src = '/images/common/pe_logo.png';
	}
	if (tb == 'customers'){
		document.getElementById('overview').style.display = 'none';	
		document.getElementById('history').style.display = 'none';	
		document.getElementById('ops').style.display = 'none';	
		document.getElementById('customers').style.display = 'block';	
		document.getElementById('overview_cell').className = 'company_menu_unselected';
		document.getElementById('history_cell').className = 'company_menu_unselected';
		document.getElementById('ops_cell').className = 'company_menu_unselected';
		document.getElementById('customers_cell').className = 'company_menu_selected';
		document.getElementById('l1').src = '/images/common/pe_logo.png';
		document.getElementById('l2').src = '/images/common/pe_logo.png';
		document.getElementById('l3').src = '/images/common/pe_logo.png';
		document.getElementById('l4').src = '/images/common/pe_logo_white.png';
	}
}

function companyenviron(tb){
	if (tb == 'overview'){
		document.getElementById('overview').style.display = 'block';	
		document.getElementById('history').style.display = 'none';	
		document.getElementById('ops').style.display = 'none';	
		document.getElementById('customers').style.display = 'none';	
		document.getElementById('supplier').style.display = 'none';	
		document.getElementById('overview_cell').className = 'company_menu_selected';
		document.getElementById('history_cell').className = 'company_menu_unselected';
		document.getElementById('ops_cell').className = 'company_menu_unselected';
		document.getElementById('customers_cell').className = 'company_menu_unselected';
		document.getElementById('supplier_cell').className = 'company_menu_unselected';
	}
	if (tb == 'history'){
		document.getElementById('overview').style.display = 'none';	
		document.getElementById('history').style.display = 'block';	
		document.getElementById('ops').style.display = 'none';	
		document.getElementById('customers').style.display = 'none';	
		document.getElementById('supplier').style.display = 'none';	
		document.getElementById('overview_cell').className = 'company_menu_unselected';
		document.getElementById('history_cell').className = 'company_menu_selected';
		document.getElementById('ops_cell').className = 'company_menu_unselected';
		document.getElementById('customers_cell').className = 'company_menu_unselected';
		document.getElementById('supplier_cell').className = 'company_menu_unselected';
	}
	if (tb == 'ops'){
		document.getElementById('overview').style.display = 'none';	
		document.getElementById('history').style.display = 'none';	
		document.getElementById('ops').style.display = 'block';	
		document.getElementById('customers').style.display = 'none';	
		document.getElementById('supplier').style.display = 'none';	
		document.getElementById('overview_cell').className = 'company_menu_unselected';
		document.getElementById('history_cell').className = 'company_menu_unselected';
		document.getElementById('ops_cell').className = 'company_menu_selected';
		document.getElementById('customers_cell').className = 'company_menu_unselected';
		document.getElementById('supplier_cell').className = 'company_menu_unselected';
	}
	if (tb == 'customers'){
		document.getElementById('overview').style.display = 'none';	
		document.getElementById('history').style.display = 'none';	
		document.getElementById('ops').style.display = 'none';	
		document.getElementById('customers').style.display = 'block';	
		document.getElementById('supplier').style.display = 'none';	
		document.getElementById('overview_cell').className = 'company_menu_unselected';
		document.getElementById('history_cell').className = 'company_menu_unselected';
		document.getElementById('ops_cell').className = 'company_menu_unselected';
		document.getElementById('customers_cell').className = 'company_menu_selected';
		document.getElementById('supplier_cell').className = 'company_menu_unselected';
	}
	if (tb == 'supplier'){
		document.getElementById('overview').style.display = 'none';	
		document.getElementById('history').style.display = 'none';	
		document.getElementById('ops').style.display = 'none';	
		document.getElementById('customers').style.display = 'none';	
		document.getElementById('supplier').style.display = 'block';	
		document.getElementById('overview_cell').className = 'company_menu_unselected';
		document.getElementById('history_cell').className = 'company_menu_unselected';
		document.getElementById('ops_cell').className = 'company_menu_unselected';
		document.getElementById('customers_cell').className = 'company_menu_unselected';
		document.getElementById('supplier_cell').className = 'company_menu_selected';
	}
}

function companyenvironweee(tb){
	if (tb == 'overview'){
		document.getElementById('overview').style.display = 'block';	
		document.getElementById('history').style.display = 'none';	
		document.getElementById('ops').style.display = 'none';	
		document.getElementById('overview_cell').className = 'company_menu_selected';
		document.getElementById('history_cell').className = 'company_menu_unselected';
		document.getElementById('ops_cell').className = 'company_menu_unselected';
	}
	if (tb == 'history'){
		document.getElementById('overview').style.display = 'none';	
		document.getElementById('history').style.display = 'block';	
		document.getElementById('ops').style.display = 'none';	
		document.getElementById('overview_cell').className = 'company_menu_unselected';
		document.getElementById('history_cell').className = 'company_menu_selected';
		document.getElementById('ops_cell').className = 'company_menu_unselected';
	}
	if (tb == 'ops'){
		document.getElementById('overview').style.display = 'none';	
		document.getElementById('history').style.display = 'none';	
		document.getElementById('ops').style.display = 'block';	
		document.getElementById('overview_cell').className = 'company_menu_unselected';
		document.getElementById('history_cell').className = 'company_menu_unselected';
		document.getElementById('ops_cell').className = 'company_menu_selected';
	}
}

function spgtab(tb){
	if (tb == 'overview'){
		document.getElementById('overview').style.display = 'block';	
		document.getElementById('security').style.display = 'none';
		document.getElementById('history').style.display = 'none';	
		document.getElementById('ops').style.display = 'none';	
		document.getElementById('overview_cell').className = 'product_tab_selected';
		document.getElementById('security_cell').className = 'product_tab_unselected';
		document.getElementById('history_cell').className = 'product_tab_unselected';
		document.getElementById('ops_cell').className = 'product_tab_unselected';
	}
	if (tb == 'security'){
		document.getElementById('overview').style.display = 'none';	
		document.getElementById('security').style.display = 'block';
		document.getElementById('history').style.display = 'none';	
		document.getElementById('ops').style.display = 'none';	
		document.getElementById('overview_cell').className = 'product_tab_unselected';
		document.getElementById('security_cell').className = 'product_tab_selected';
		document.getElementById('history_cell').className = 'product_tab_unselected';
		document.getElementById('ops_cell').className = 'product_tab_unselected';
	}	
	if (tb == 'history'){
		document.getElementById('overview').style.display = 'none';	
		document.getElementById('security').style.display = 'none';
		document.getElementById('history').style.display = 'block';	
		document.getElementById('ops').style.display = 'none';	
		document.getElementById('overview_cell').className = 'product_tab_unselected';
		document.getElementById('security_cell').className = 'product_tab_unselected';
		document.getElementById('history_cell').className = 'product_tab_selected';
		document.getElementById('ops_cell').className = 'product_tab_unselected';
	}
	if (tb == 'ops'){
		document.getElementById('overview').style.display = 'none';	
		document.getElementById('security').style.display = 'none';
		document.getElementById('history').style.display = 'none';	
		document.getElementById('ops').style.display = 'block';	
		document.getElementById('overview_cell').className = 'product_tab_unselected';
		document.getElementById('security_cell').className = 'product_tab_unselected';
		document.getElementById('history_cell').className = 'product_tab_unselected';
		document.getElementById('ops_cell').className = 'product_tab_selected';
	}
}

function values(tb){
	if (tb == 'family'){
		document.getElementById('family').style.display = 'block';	
		document.getElementById('initiative').style.display = 'none';	
		document.getElementById('passion').style.display = 'none';	
		document.getElementById('service').style.display = 'none';	
		document.getElementById('creativity').style.display = 'none';	
		document.getElementById('fun').style.display = 'none';	
		document.getElementById('family_cell').className = 'company_menu_selected';
		document.getElementById('initiative_cell').className = 'company_menu_unselected';
		document.getElementById('passion_cell').className = 'company_menu_unselected';
		document.getElementById('service_cell').className = 'company_menu_unselected';
		document.getElementById('creativity_cell').className = 'company_menu_unselected';
		document.getElementById('fun_cell').className = 'company_menu_unselected';
	}
	if (tb == 'initiative'){
		document.getElementById('family').style.display = 'none';	
		document.getElementById('initiative').style.display = 'block';	
		document.getElementById('passion').style.display = 'none';	
		document.getElementById('service').style.display = 'none';	
		document.getElementById('creativity').style.display = 'none';	
		document.getElementById('fun').style.display = 'none';	
		document.getElementById('family_cell').className = 'company_menu_unselected';
		document.getElementById('initiative_cell').className = 'company_menu_selected';
		document.getElementById('passion_cell').className = 'company_menu_unselected';
		document.getElementById('service_cell').className = 'company_menu_unselected';
		document.getElementById('creativity_cell').className = 'company_menu_unselected';
		document.getElementById('fun_cell').className = 'company_menu_unselected';
	}
	if (tb == 'passion'){
		document.getElementById('family').style.display = 'none';	
		document.getElementById('initiative').style.display = 'none';	
		document.getElementById('passion').style.display = 'block';	
		document.getElementById('service').style.display = 'none';	
		document.getElementById('creativity').style.display = 'none';	
		document.getElementById('fun').style.display = 'none';	
		document.getElementById('family_cell').className = 'company_menu_unselected';
		document.getElementById('initiative_cell').className = 'company_menu_unselected';
		document.getElementById('passion_cell').className = 'company_menu_selected';
		document.getElementById('service_cell').className = 'company_menu_unselected';
		document.getElementById('creativity_cell').className = 'company_menu_unselected';
		document.getElementById('fun_cell').className = 'company_menu_unselected';
	}
	if (tb == 'service'){
		document.getElementById('family').style.display = 'none';	
		document.getElementById('initiative').style.display = 'none';	
		document.getElementById('passion').style.display = 'none';	
		document.getElementById('service').style.display = 'block';	
		document.getElementById('creativity').style.display = 'none';	
		document.getElementById('fun').style.display = 'none';	
		document.getElementById('family_cell').className = 'company_menu_unselected';
		document.getElementById('initiative_cell').className = 'company_menu_unselected';
		document.getElementById('passion_cell').className = 'company_menu_unselected';
		document.getElementById('service_cell').className = 'company_menu_selected';
		document.getElementById('creativity_cell').className = 'company_menu_unselected';
		document.getElementById('fun_cell').className = 'company_menu_unselected';
	}
	if (tb == 'creativity'){
		document.getElementById('family').style.display = 'none';	
		document.getElementById('initiative').style.display = 'none';	
		document.getElementById('passion').style.display = 'none';	
		document.getElementById('service').style.display = 'none';	
		document.getElementById('creativity').style.display = 'block';	
		document.getElementById('fun').style.display = 'none';	
		document.getElementById('family_cell').className = 'company_menu_unselected';
		document.getElementById('initiative_cell').className = 'company_menu_unselected';
		document.getElementById('passion_cell').className = 'company_menu_unselected';
		document.getElementById('service_cell').className = 'company_menu_unselected';
		document.getElementById('creativity_cell').className = 'company_menu_selected';
		document.getElementById('fun_cell').className = 'company_menu_unselected';
	}
	if (tb == 'fun'){
		document.getElementById('family').style.display = 'none';	
		document.getElementById('initiative').style.display = 'none';	
		document.getElementById('passion').style.display = 'none';	
		document.getElementById('service').style.display = 'none';	
		document.getElementById('creativity').style.display = 'none';	
		document.getElementById('fun').style.display = 'block';	
		document.getElementById('family_cell').className = 'company_menu_unselected';
		document.getElementById('initiative_cell').className = 'company_menu_unselected';
		document.getElementById('passion_cell').className = 'company_menu_unselected';
		document.getElementById('service_cell').className = 'company_menu_unselected';
		document.getElementById('creativity_cell').className = 'company_menu_unselected';
		document.getElementById('fun_cell').className = 'company_menu_selected';
	}
}