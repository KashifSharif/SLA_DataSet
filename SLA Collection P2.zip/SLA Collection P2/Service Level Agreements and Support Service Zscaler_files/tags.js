;(function (w) {
  console.error("Invalid tags.js configuration: 403")
})(window);