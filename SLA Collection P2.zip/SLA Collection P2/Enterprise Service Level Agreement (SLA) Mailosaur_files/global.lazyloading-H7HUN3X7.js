"use strict";(()=>{document.addEventListener("DOMContentLoaded",function(){var r;if("IntersectionObserver"in window){r=document.querySelectorAll(".lazy");var o=new IntersectionObserver(function(e,c){e.forEach(function(n){if(n.isIntersecting){var t=n.target;t.src=t.dataset.src,t.removeAttribute("data-src"),t.dataset.srcset&&(t.srcset=t.dataset.srcset,t.removeAttribute("data-srcset")),t.classList.remove("lazy"),o.unobserve(t)}})});r.forEach(function(e){o.observe(e)})}else{let e=function(){s&&clearTimeout(s),s=setTimeout(function(){var c=window.scrollY;r.forEach(n=>{n.offsetTop<window.innerHeight+c&&(n.src=n.dataset.src,n.classList.remove("lazy"))}),r.length==0&&(document.removeEventListener("scroll",e),window.removeEventListener("resize",e),window.removeEventListener("orientationChange",e))},20)};var i=e,s;r=document.querySelectorAll(".lazy"),document.addEventListener("scroll",e),window.addEventListener("resize",e),window.addEventListener("orientationChange",e)}});})();
/**
 * @license
 * Copyright (c) 2023 by ImageKit.io (https://codepen.io/imagekit_io/pen/RBXVrW)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
