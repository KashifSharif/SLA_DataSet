import serviceNowChat from './modules/service-now-home.js';
import mainMenu from './modules/main-menu.js';
import sidebarMenu from './modules/sidebar-menu.js';
import rateComment from './modules/rateComment.js';
import {dropdownFilters,filterBadges} from './modules/dropdownFilters.js'
import statusHomepage from './modules/statusHomepage.js'
import newsEventsFilters from './modules/newsEventsFilters.js'
import {searchFilters, searchBadges} from './modules/searchFilters.js'
import mySaves from './modules/mySaves.js'
import initAcc from './modules/accordions.js'
import samLoginAppendCurrentPage from './modules/samLoginAppendCurrentPage.js'
// import searchPage from './modules/searchPage.js'

rateComment()
mainMenu();
sidebarMenu()
serviceNowChat();
dropdownFilters()
filterBadges()
statusHomepage()
// searchPage()
newsEventsFilters()
searchFilters()
searchBadges()
mySaves()
//activate accordion function
initAcc('.accordion', true)
samLoginAppendCurrentPage()
