﻿// This plugin allows us to include stylesheets/scripts that are applied to the 
// content of the CKEditor (but not the toolbars) by only including the stlesheets
// in the head of the iframe that contains the CKE body. The paths are defined in
// the CKE wrappers.
CKEDITOR.plugins.add('customstyles', {
  init: function (editor) {

    editor.on("instanceReady", function () {

      insertStyles();
        
      // Every time we switch from wysiwyg to source mode CKE blows away
      // the links to our stylesheets
      editor.on('mode', function () {
        if (editor.mode == 'wysiwyg') {
          insertStyles();
        }
      });
	  
	  // Similarly, includes are also stripped when editor data is set programatically
	  editor.on('setData', function () {
		// Since this event is raised when setData is called (not *after*), we need to reinsert
		// styles asynchronously to make sure they are not added until after the data has changed
		setTimeout(insertStyles, 0);
      });

    });

    var insertStyles = function () {

      // quality of life improvements
      editor.getDoc = function () { return editor.document.$; }
      var head = editor.getDoc().getElementsByTagName("head")[0];

      // we are doing this in order to make sure that jQuery is fully loaded before bootstrap.
      // if there is a script that has a dependency it will be passed as an object instead of a string.
      // Create a copy so that we can insert in reverse order
      var scripts = editor.config['clientScripts'];
      if (scripts) {

        // Create a copy and reverse the order since we insert at the top of the <head>
        scripts = scripts.slice().reverse();

        scripts.forEach(function (script) {

          var element = editor.getDoc().createElement("script");
          var scriptPath;
          var dependentPath = [];

          // If this is an object, the src of the script will be
          // under "scriptDependencyPath" and any dependent scripts
          // will be under "scriptPath"
          if (typeof script === 'object') {
            scriptPath = script.scriptDependencyPath;

            // See if scriptPath is an array or not
            if (Array.isArray(script.scriptPath)) {
              for(var i = 0; i < script.scriptPath.length; i++) {
                dependentPath.push(script.scriptPath[i]);
              }
            }
            else {
              dependentPath.push(script.scriptPath);
            }
          } else {
            scriptPath = script;
          }

          element.setAttribute("type", "text/javascript");
          element.setAttribute("src", scriptPath);

          if (dependentPath.length > 0) {
            // Build an onload to grab each script
            var onload = '';

            for(var j = 0; j < dependentPath.length; j++) {
              onload += '$.ajax({url:"' + dependentPath[j] + '", dataType:"script"});';
            }

            element.setAttribute('onload', onload);
          }

          head.insertBefore(element, head.firstChild);
        });
      }

      // grab stylesheet paths
      var stylesheets = editor.config['clientStyles'];
      
      if (!stylesheets) { return; }

      // Create a copy and reverse the order since we insert at the top of the <head>
      stylesheets = stylesheets.slice().reverse();

      // create links and append them to the head of the iframe 
      stylesheets.forEach(function (styleSheetPath) {

        var element = editor.getDoc().createElement("link");
        element.setAttribute("rel", "stylesheet");
        element.setAttribute("type", "text/css");
        element.setAttribute("href", styleSheetPath);
        head.insertBefore(element, head.firstChild);

      });
    }

  }
});