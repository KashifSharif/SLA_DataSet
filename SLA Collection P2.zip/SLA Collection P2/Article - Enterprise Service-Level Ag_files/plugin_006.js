CKEDITOR.plugins.add('itemtemplate', {
  requires: ['richcombo'],

  init: function (editor) {
    const regex = /{{2,3}(?:Ticket.*?)}{2,3}/g;
    var config = editor.config;
    editor.ui.addRichCombo('ItemTemplate',
      {
        label: "Templates", // label displayed in toolbar
        title: 'Insert Template', // popup text when hovering over the dropdown
        multiSelect: false,
        panel:
        {
          // use the same style as the font/style dropdowns
          css: [CKEDITOR.skin.getPath('editor')].concat(config.contentsCss),
          attributes: { 'aria-label': 'Templates', 'title': 'Templates'}
        },
        init: function () {

          var htmlEncode = function htmlEncode(input) {
            return $('<div/>').text(input).html();
          };

          // our dropdownlist
          var ddl = this;

          // if templates are defined
          if (config['itemTemplates']) {

            // the templates are passed into the config from the CKE wrapper
            var templates = JSON.parse(config['itemTemplates']);

            templates.forEach(function (category) {

              // if the category contains no templates do not render it
              if (!category.Templates.length > 0) {
                return;
              }

              // otherwise lets start a group in the ddl
              ddl.startGroup(htmlEncode(category.Name));

              category.Templates.forEach(function (template) {

                // if the description is whitespace the title is automatically set to the
                // body, and we don't like that.
                if (template.Description === '') {
                  template.Description = 'No description'
                }

                var description = template.Name + ' - ' + template.Description;

                // The fact that CKEditor does not encode backslashes causes problems,
                // so we need to manually escape them before adding them to the dropdown.
                template.Body = template.Body.replaceAll('\\', '&bsol;')

                // VALUE - The value we get when the row is clicked
                // HTML - html/plain text that should be displayed in the dropdown
                // TEXT - displayed in popup when hovered over the row.
                // .add( VALUE, HTML, TEXT )
                ddl.add(template.Body, htmlEncode(template.Name), description);

                // increase width of ddl, the definition for this class is appended to
                // skins/bootstrapck/editor.css
                ddl._.panel.element.addClass('template_ddl');

              });

            });
          }
          // no templates defined
          else {
            ddl.startGroup('No templates available');
          }

          // resize the iFrame height if there aren't enough templates defined
          // the default height for richCombos is 150px, if it's less than that we will shrink to fit
          var iFrameId = ddl._.panel.element.$.firstElementChild.id;

          function resizeIFrameHeight(iFrame) {

            var contentHeight = iFrame[0].contentWindow.document.body.scrollHeight;

            if (contentHeight < 150) {
              iFrame.css('height', contentHeight);
            }
          }

          setTimeout(function () {
            resizeIFrameHeight($('#' + iFrameId));
          }, 50);
        },
        onClick: function (value) {
          // strip template tags when manually applying template
          var template = value.replace(regex, '');
          editor.focus();
          editor.fire('saveSnapshot');
          editor.insertHtml(template);
          editor.fire('saveSnapshot');
        },
      });
  }
});
