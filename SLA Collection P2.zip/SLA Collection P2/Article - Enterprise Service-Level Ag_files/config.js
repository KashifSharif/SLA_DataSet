/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

/**
 * PLEASE READ BEFORE UPDATING THE EDITOR
 * 
 * The FontAwesome plugin was manually edited (plugins/fontawesome/plugin.js) to work around
 * various issues. Please review the comments in that file to preserve those changes when upgrading
 * the editor or the FontAwesome plugin.
 */

CKEDITOR.editorConfig = function (config) {
  // Define changes to default configuration here. For example:
  // config.language = 'fr';
  // config.uiColor = '#AADC6E';

  // Default height
  config.height = 300;

  //config.skin = 'moono';
  config.allowedContent = true;
  config.extraPlugins = 'widget,lineutils,colordialog,fontawesome,youtube,itemtemplate,strinsert,richcombo,customstyles,autolink,autogrow,uploadimage,simpleimage,remoteimageblocker';

  config.autoGrow_minHeight = 210;
  config.autoGrow_maxHeight = 400;
  config.autoGrow_bottomSpace = 45;
  config.autoGrow_onStartup = true;

  // Setting the font options for the font plugin
  config.font_names = 'Arial;Comic Sans MS;Courier New;Georgia;Helvetica;Lucida Sans Unicode;Open Sans;Segoe UI;Tahoma;Times New Roman;Trebuchet MS;Verdana';

  // Make fontawesome plugin work. we need to prevent CKEditor from removing empty spans, 
  // which is what Font Awesome uses.
  CKEDITOR.dtd.$removeEmpty['span'] = false;

  // Default toolbar settings
  config.toolbar = 'Full';
  config.toolbar_Full =
  [
    { name: 'document', items: ['Source', '-', 'NewPage', 'DocProps', 'Print', '-'] },
    { name: 'editing', items: ['Find', 'Replace', '-', 'SelectAll'] },
	  { name: 'image', items: ['Table', 'HorizontalRule', 'Smiley', 'SpecialChar', 'PageBreak'] },
    '/',
    { name: 'styles', items: ['Styles', 'Format', 'Font', 'FontSize', 'TextColor', 'BGColor'] },
    { name: 'tools', items: ['Maximize', 'ShowBlocks'] },
    { name: 'links', items: ['Image', 'Link', 'Unlink', 'Anchor', 'FontAwesome', 'Youtube'] },
    '/',
    { name: 'morestyles', items: ['Bold', 'Italic', 'Underline', 'Strike', 'Subscript', 'Superscript', '-', 'RemoveFormat'] },
    { name: 'paragraph', items: ['JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock', '-', 'NumberedList', 'BulletedList', '-', 'Outdent', 'Indent', '-', 'Blockquote'] },
    { name: 'clipboard', items: ['Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo'] }
  ];

  config.toolbar_TDNoFontAwesome =
  [
    { name: 'document', items: ['Source', '-', 'NewPage', 'DocProps', 'Print', '-'] },
    { name: 'editing', items: ['Find', 'Replace', '-', 'SelectAll'] },
	  { name: 'image', items: ['Table', 'HorizontalRule', 'Smiley', 'SpecialChar', 'PageBreak'] },
    '/',
    { name: 'styles', items: ['Styles', 'Format', 'Font', 'FontSize', 'TextColor', 'BGColor'] },
    { name: 'tools', items: ['Maximize', 'ShowBlocks'] },
    { name: 'links', items: ['Image', 'Link', 'Unlink', 'Anchor'] },
    '/',
    { name: 'morestyles', items: ['Bold', 'Italic', 'Underline', 'Strike', 'Subscript', 'Superscript', '-', 'RemoveFormat'] },
    { name: 'paragraph', items: ['JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock', '-', 'NumberedList', 'BulletedList', '-', 'Outdent', 'Indent', '-', 'Blockquote'] },
    { name: 'clipboard', items: ['Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo'] }
  ];

  config.toolbar_TDSimple =
  [
    { name: 'morestyles', items: ['Bold', 'Italic', 'Underline', 'Strike', 'Subscript', 'Superscript', '-', 'RemoveFormat'] },
    { name: 'paragraph', items: ['JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock', '-', 'NumberedList', 'BulletedList', '-', 'Outdent', 'Indent', '-', 'Blockquote'] },
    { name: 'links', items: ['Image', 'Link', 'Unlink', 'Anchor'] }
  ];

  config.toolbar_TDTemplates =
  [
    { name: 'document', items: ['Source', '-', 'NewPage', 'DocProps', 'Print', '-'] },
    { name: 'editing', items: ['Find', 'Replace', '-', 'SelectAll'] },
	  { name: 'image', items: ['Table', 'HorizontalRule', 'Smiley', 'SpecialChar', 'PageBreak'] },
    { name: 'templates', items: ['ItemTemplate'] },
    '/',
    { name: 'styles', items: ['Styles', 'Format', 'Font', 'FontSize', 'TextColor', 'BGColor'] },
    { name: 'tools', items: ['Maximize', 'ShowBlocks'] },
    { name: 'links', items: ['Image', 'Link', 'Unlink', 'Anchor', 'FontAwesome', 'Youtube'] },
    '/',
    { name: 'morestyles', items: ['Bold', 'Italic', 'Underline', 'Strike', 'Subscript', 'Superscript', '-', 'RemoveFormat'] },
    { name: 'paragraph', items: ['JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock', '-', 'NumberedList', 'BulletedList', '-', 'Outdent', 'Indent', '-', 'Blockquote'] },
    { name: 'clipboard', items: ['Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo'] }
  ];

  config.toolbar_TDTemplatesWithTags =
  [
    { name: 'document', items: ['Source', '-', 'NewPage', 'DocProps', 'Print', '-'] },
    { name: 'editing', items: ['Find', 'Replace', '-', 'SelectAll'] },
	  { name: 'image', items: ['Table', 'HorizontalRule', 'Smiley', 'SpecialChar', 'PageBreak'] },
    { name: 'templates', items: ['ItemTemplate', 'strinsert'] },
    '/',
    { name: 'styles', items: ['Styles', 'Format', 'Font', 'FontSize', 'TextColor', 'BGColor'] },
    { name: 'tools', items: ['Maximize', 'ShowBlocks'] },
    { name: 'links', items: ['Image', 'Link', 'Unlink', 'Anchor', 'FontAwesome', 'Youtube'] },
    '/',
    { name: 'morestyles', items: ['Bold', 'Italic', 'Underline', 'Strike', 'Subscript', 'Superscript', '-', 'RemoveFormat'] },
    { name: 'paragraph', items: ['JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock', '-', 'NumberedList', 'BulletedList', '-', 'Outdent', 'Indent', '-', 'Blockquote'] },
    { name: 'clipboard', items: ['Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo'] }
    ];

  config.toolbar_TDFeed =
    [
      { name: 'styles', items: ['Format', 'Font', 'FontSize', 'TextColor'] }, 
      { name: 'morestyles', items: ['Bold', 'Italic', 'Underline', 'Strike', 'Subscript', 'Superscript', '-', 'RemoveFormat'] },
      '/',
      { name: 'paragraph', items: ['NumberedList', 'BulletedList'] },
      { name: 'links', items: ['Table', 'SimpleImage', 'Link', 'Unlink'] }
    ];

  // Remove plugins
  config.removePlugins = 'magicline,devtools,templates';

  // Enables resizing of CKEditor in both directions.
  config.resize_dir = 'both';

  // Prevent CKEditor from stripping out href tags from anchors
  config.extraAllowedContent = 'a{href}';

  // To configure the value of a YouTube plugin option, use the following syntax:
  // config.youtube_responsive = false;

  // The dialogDefinition event is triggered when a dialog box is opened from the CKEditor.
  // We have custom configurations to the table dialog and youtube plugin.
  CKEDITOR.on('dialogDefinition', function (ev) {

    // Take the dialog name and its definition from the event data.
    var dialogName = ev.data.name;
    var dialogDefinition = ev.data.definition;

    // Only hide the chkOlderCode element if the YouTube plugin is active.
    // This option does not properly load the embedded video when checked.
    if (dialogName == 'youtube') {

      // Hide the chkOlderCode element when the plugin is loading.
      // getContentElement is CKEditors API function to extract a particular element from
      // the DOM.
      dialogDefinition.onShow = function () {
        this.getContentElement("youtubePlugin", "chkOlderCode").getElement().hide();
      }
    }

    if (dialogName == 'table') {
      // Get a reference to the "Table Info" tab.
      var infoTab = dialogDefinition.getContents('info');
      txtWidth = infoTab.get('txtWidth');
      txtWidth['default'] = "100%";
    }

    // Hide the <popup window> option from the link dialog since it uses
    // javascript that will ultimately get stripped out
    if (dialogName == 'link') {
      var targetTab = dialogDefinition.getContents('target');
      var targetType = targetTab.get('linkTargetType');

      if (targetType && targetType.items) {
        targetType.items = targetType.items.filter(function (item) {
          return (item.length > 1 && item[1] != 'popup');
        });
      }
    }
  });

};
